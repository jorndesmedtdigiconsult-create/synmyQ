# SyncMyQue test credentials
- Guest login: POST /api/auth/guest (no credentials) -> returns session_token. UI button "Doorgaan als gast" (testID guest-login-button). New guests have no name -> welcome screen (welcome-name-input, welcome-continue-button); PATCH /api/auth/me {name}.
- Apple Sign-in: iOS device only, needs real Apple ID (manual test). POST /api/auth/apple with invalid token must 401.
- Auth header: Authorization: Bearer <session_token>
