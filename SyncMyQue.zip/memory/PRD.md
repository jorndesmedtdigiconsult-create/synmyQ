# JynQue — PRD

## Original problem statement (NL)
Simpele mediaplayer "JynQue": liedjes uit de cloud opvragen, inladen en offline bewaren. Alle devices lopen gelijk op UTC (atoomklok). ID-veld: elk liedje heeft een uniek ID (door de app gegenereerd bij upload). Na invoer van ID op elk device drukt slechts 1 device op Start → alle devices spelen. Bij herverbinding synchroniseren door tempo licht aan te passen (niet onderbreken). Stop = terug naar 0:00 zonder herstart. Zwarte achtergrond, witte letters. Vervolg: Apple Sign-in toevoegen.

## Architecture
- Backend FastAPI + MongoDB; Emergent Object Storage for MP3s (path jynque/uploads/{user}/{uuid}.ext)
- Endpoints: /api/time, /api/auth/{apple,guest,me,logout}, /api/songs/upload, /api/songs/{id}, /file (?token= for web), /state, /start (start_at = now+3s), /stop
- Frontend Expo Router: login.tsx, index.tsx (Home), player/[id].tsx; src/clock.ts (NTP-style offset), src/library.ts (offline cache via expo-file-system), src/auth.tsx (Stack.Protected gate)
- Sync engine: target = (utcNow - start_at)/1000; drift corrected with playbackRate ±8% over ~4s; hard seek only >3s; deadband 20ms; state + offset cached for offline

## Implemented (2026-06)
- Apple Sign-in (iOS) + guest login (Android/web)
- Upload MP3 → 6-char ID, share ID; load by ID → offline cache; library list (long-press removes)
- UTC-synced Start (broadcast), Stop & Reset to 0:00; live offset/drift/tempo metrics
- Tested: backend 18/18, frontend flows pass
- 2026-06 iteration 3: 30s subtle sync (±2% tempo, first check 5s), loop (10s gap, default on) + Loop & Pause buttons, control transfer (X-Device-Id, /control, reclaim by uploader), presence + listener counter (/presence). Backend 32/32.
- 2026-06 iteration 4: per-device Auto-sync on/off toggle (persisted); library delete button with confirmation sheet + warning (owner delete stops music for all devices).
- 2026-06 iteration 11: Secure downloads (HMAC signed per-file/per-user links, 30 min, POST /songs/{id}/file-link; ?token= removed; web refreshes links every 10 min). Password rotate (POST /{kind}/{id}/password/rotate) + kick listener (POST /{kind}/{id}/kick: drops membership/presence/control, rotates pw; kicked device shows removed-screen). Backend 103/103 + frontend pass.
- 2026-06 iteration 10: Lock-screen robustness: silent looping keep-alive player (assets/audio/silence.wav, volume 0) during countdown/play/gap/pause on native so locked devices keep syncing and restart in sync. Web regression + code review pass; real lock-screen needs native build.
- 2026-06 iteration 9: SEC-001 fix (control bound to account via controller_user_id; presence device spoof 409); per-session 6-char join password (JoinGate on typed ID, QR carries jynque:ID:PW, password bar for controller/owner, /join with rate limit, /password owner-only, members, migration). Backend 89/89 + frontend pass.
- 2026-06 iteration 8: BUG FIX Start "Vereist netwerk" (act() param shadowed `kind` → wrong URL /api/start/..). Queue ordering: PUT /api/playlists/{pid}/items {order} (move up/down, remove) with seamless re-anchor; engine tracks loaded song by id. Backend 74/74 + frontend pass.
- 2026-06 iteration 7: Fade in/out (1.5s in, 1.2s out on pause/stop/skip, synced via fade_end_ms; soft fade at song end). Shared playlists (7-char ID): generic session API /api/{songs|playlists}/{id}/..., global UTC timeline over all tracks (2s between songs, 10s loop gap), queue panel (prev/next/jump/add by ID), create screen, playlists on home, mutagen durations. Backend 61/61 + frontend pass.
- 2026-06 iteration 6: 5s countdown for start + resume ("HERVAT IN n"), each 30s correction glides over 10s (max ±4%), profile name edit sheet on home, remote volume (POST /volume, no version bump, 10-segment bar), auto-sync OFF keeps last synced setting (no seek/tempo reset). Backend 40/40 + frontend pass.
- 2026-06 iteration 5: name prompt (welcome screen) before app start, PATCH /api/auth/me; greeting "Hallo, <naam>"; device labels use the name.
- 2026-06 iteration 2: QR share sheet (jynque:<ID>) + camera scanner (/scan, full permission flow); background + lock-screen playback (expo-audio, native build only); owner-only Start/Stop (403 for others, listener panel); redesign with custom SVG logo (UTC clock ring + Q tail + equalizer). Tested backend 24/24 + frontend.

## Backlog
- P1: Background/lock-screen playback — implemented, verify on native build
- P1: Playlists / queue per session ID
- P2: Room/session ownership (only uploader may start), song delete in cloud

## Iteratie: Rebrand SyncMyQue + gele accenten (juni 2026)
- App hernoemd naar SyncMyQue (app.json, logo, login, QR-tekst, lockscreen). QR-prefix syncmyque: (oude jynque: QR blijft werken). Opslag-keys ongewijzigd.
- Theme: accent #FFD400 / onAccent / accentSoft. Warning naar oranje #FF9F0A.
- Home: upload + afspeellijst als 2 tegels, sectielabels met gele balk, gele go-knop/teller/beheerder-tag.
- Speler: gele START, voortgangsbalk, volume, wachtwoord.
- Ontvangstscherm: "Zo werkt het" kaart (src/components/how-it-works.tsx, testID how-it-works) met 4 stappen (inloggen, QR scannen, ID+wachtwoord, Start) op login-scherm en op home bij lege bibliotheek.
- App-icoon/adaptive/splash/favicon gegenereerd met /app/frontend/scripts/make_icons.py (zwart/wit/geel logo-mark; splash met SyncMyQue wordmark).
- "Zo werkt het" op home altijd zichtbaar en inklapbaar (how-it-works-toggle); standaard open bij lege bibliotheek, dicht als er nummers zijn.
- Fix: native MP3-upload gaf "Unsupported FormDataPart implementation" (Expo WinterCG fetch). Nu expo-file-system File (kopie onder originele naam in tijdelijke cachemap) in FormData. src/library.ts uploadSong.
- Fix iOS hapering bij 30s-sync: pitch-algoritme werd mid-play omgeschakeld (spectral). Nu iOS "medium" (timeDomain), één keer ingesteld als de speler stil is (primedSong) in use-sync-engine.ts.
- Continue sync: drift-check elke 1s (DRIFT_CHECK_MS) zodra vorige glide klaar is; klok-sync blijft 30s. Auto-sync knop blijft (aan/uit).
- Login: SMQ (Q geel) naast logo, nieuwe tagline, credits Jörn De Smedt + non-profit tekst (testID login-credits).
- Sync zonder 10s-inhaalvenster: proportionele tempo-regeling elke 1s de hele song door (dev = drift/2s, max 4%, deadband 20ms). correctionLeft verwijderd.
- 5s stilte voor elke track (GAP_S=5, TRACK_GAP_S=5, backend+timeline.ts). Loop altijd aan voor alle toestellen (loop-knop verwijderd, indicator "LOOP · 5s STILTE"). SYNC-NOW knop (testID sync-now-button) onder auto-sync: klok her-sync + eenmalige seek naar positie beheerder, werkt ook met auto-sync uit.
- Account verwijderen (DELETE /api/auth/me; profiel-sheet delete-account-button → bevestiging delete-account-confirm-button) wist user, sessies, eigen songs/playlists, presence, lidmaatschappen + lokale bibliotheek.
- Auto-login: sessies 30 dagen sliding; bij geen geldige sessie automatisch gast-login met laatste profielnaam (storage syncmyque_last_name, POST /api/auth/guest {name}).
- OFFLINE MODUS (zonder server): /offline (beheerder kiest lokaal bestand + starttijd → QR "syncmyque-off:" met titel, grootte, UTC-start; luisteraar scant /offline/scan of plakt code, kiest zelfde bestand), /offline/play (eigen klok, timeline met 5s stilte/loop, continue auto-sync toggle, SYNC-NOW, QR delen). src/offline.ts, src/use-offline-engine.ts. Toegang via login (login-offline-button) en home (offline-mode-button). Online functies ongewijzigd.
- Offline A: lokale Play/Pauze/Stop per gsm (Play = exact terug in sync, Stop = 0:00 zonder herstart). Offline B: wifi/hotspot P2P zonder server (src/p2p.ts, react-native-tcp-socket poort 47820, expo-network IP in QR h/p): beheerder bedient Play/Pauze/Stop voor alle gsms, NTP-ping klok-offset t.o.v. beheerder, luisteraarslijst met drift, SYNC-NOW resync. Alleen native build; in Expo Go/web p2pAvailable=false → terugval op vaste starttijd. iOS NSLocalNetworkUsageDescription toegevoegd.
