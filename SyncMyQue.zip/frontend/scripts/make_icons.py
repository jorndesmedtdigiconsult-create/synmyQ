"""Generates SyncMyQue app icon, adaptive icon, splash and favicon (black / white / yellow)."""
import math
from PIL import Image, ImageDraw, ImageFont

WHITE, YELLOW, GREY, BLACK = (255, 255, 255, 255), (255, 212, 0, 255), (72, 72, 74, 255), (0, 0, 0, 255)
SS = 4  # supersampling
OUT = "/app/frontend/assets/images/"
FONT = "/app/frontend/assets/fonts/Rajdhani-Bold.ttf"


def line(d, x1, y1, x2, y2, w, col):
    d.line([(x1, y1), (x2, y2)], fill=col, width=int(w))
    for x, y in ((x1, y1), (x2, y2)):
        d.ellipse([x - w / 2, y - w / 2, x + w / 2, y + w / 2], fill=col)


def draw_mark(d, cx, cy, S):
    for k in range(12):
        a = k * math.pi / 6
        major = k % 3 == 0
        r1, r2 = S * (0.43 if major else 0.45), S * 0.485
        line(d, cx + r1 * math.sin(a), cy - r1 * math.cos(a), cx + r2 * math.sin(a), cy - r2 * math.cos(a),
             S * (0.035 if major else 0.02), WHITE if major else GREY)
    r, st = S * 0.36, S * 0.06
    d.ellipse([cx - r - st / 2, cy - r - st / 2, cx + r + st / 2, cy + r + st / 2], outline=WHITE, width=int(st))
    ta = 3 * math.pi / 4
    line(d, cx + r * 0.55 * math.sin(ta), cy - r * 0.55 * math.cos(ta), cx + S * 0.5 * math.sin(ta), cy - S * 0.5 * math.cos(ta), st, YELLOW)
    hs = [0.32, 0.58, 0.82, 0.58, 0.32]
    bw, gap = S * 0.055, S * 0.035
    x = cx - (5 * bw + 4 * gap) / 2
    for h in hs:
        bh = S * 0.4 * h
        d.rounded_rectangle([x, cy - bh / 2, x + bw, cy + bh / 2], radius=bw / 2, fill=WHITE)
        x += bw + gap


def render(size, mark_frac, bg, path, wordmark=False):
    W = size * SS
    img = Image.new("RGBA", (W, W), bg)
    d = ImageDraw.Draw(img)
    S = W * mark_frac
    cy = W / 2 - (W * 0.09 if wordmark else 0)
    draw_mark(d, W / 2, cy, S)
    if wordmark:
        f = ImageFont.truetype(FONT, int(W * 0.15))
        a, b = "SyncMy", "Que"
        wa, wb = d.textlength(a, font=f), d.textlength(b, font=f)
        x0, y0 = (W - wa - wb) / 2, cy + S / 2 + W * 0.04
        d.text((x0, y0), a, font=f, fill=WHITE)
        d.text((x0 + wa, y0), b, font=f, fill=YELLOW)
    img.resize((size, size), Image.LANCZOS).save(OUT + path)


render(1024, 0.68, BLACK, "icon.png")
render(1024, 0.50, (0, 0, 0, 0), "adaptive-icon.png")
render(1024, 0.48, (0, 0, 0, 0), "splash-image.png", wordmark=True)
render(196, 0.80, BLACK, "favicon.png")
print("done")
