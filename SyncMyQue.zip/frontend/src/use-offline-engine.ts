// Serverless sync engine. Follows a shared SongState (fixed QR start time, or the admin's state
// over Wi-Fi) on a reference clock (own clock, or the admin's clock via offset). Same timeline as
// online (5 s silence before every repeat, always looping) and the same continuous proportional
// tempo correction. Local Play / Pause / Stop only affect this phone; Play re-joins in sync.
import { AudioPlayer, setAudioModeAsync, useAudioPlayer } from "expo-audio";
import { type RefObject, useCallback, useEffect, useRef, useState } from "react";
import { Platform } from "react-native";

import type { SongState } from "@/src/library";
import { type Phase, timeline } from "@/src/timeline";
import { storage } from "@/src/utils/storage";

const AUTO_SYNC_KEY = "syncmyque_offline_auto_sync";
const DEADBAND_S = 0.02;
const MAX_DEV = 0.04;
const RESPONSE_S = 2;
const HARD_SEEK_S = 3;
const PITCH_QUALITY = Platform.OS === "ios" ? "medium" : "high";

export type LocalMode = "sync" | "paused" | "stopped";

export function useOfflineEngine(player: AudioPlayer, state: SongState, offsetRef: RefObject<number>, title: string) {
  const stateRef = useRef(state);
  stateRef.current = state;
  const offsetHolder = useRef(offsetRef);
  offsetHolder.current = offsetRef;
  const [phase, setPhase] = useState<Phase>("countdown");
  const [wait, setWait] = useState(0);
  const [pos, setPos] = useState(0);
  const [drift, setDrift] = useState(0);
  const [rate, setRate] = useState(1);
  const [autoSync, setAutoSync] = useState(true);
  const [localMode, setLocalModeState] = useState<LocalMode>("sync");
  const localRef = useRef<LocalMode>("sync");
  const autoSyncRef = useRef(true);
  const rateRef = useRef(1);
  const seeking = useRef(false);
  const parked = useRef<string | null>(null);
  const startKey = useRef<string | null>(null);
  const startedAt = useRef(0);
  const lastCheck = useRef(0);
  const forceSync = useRef(false);
  const primed = useRef(false);

  // Silent keep-alive so countdowns / loop gaps keep running on a locked screen
  const keepAlive = useAudioPlayer(require("../assets/audio/silence.wav"));
  useEffect(() => {
    if (Platform.OS === "web") return;
    try {
      keepAlive.loop = true;
      keepAlive.volume = 0;
      keepAlive.play();
    } catch {}
    return () => {
      try {
        keepAlive.pause();
      } catch {}
    };
  }, [keepAlive]);

  useEffect(() => {
    setAudioModeAsync({ playsInSilentMode: true, shouldPlayInBackground: true, interruptionMode: "doNotMix" }).catch(() => {});
    storage.getItem(AUTO_SYNC_KEY, true).then((v: unknown) => {
      autoSyncRef.current = v !== false;
      setAutoSync(v !== false);
    });
    try {
      player.shouldCorrectPitch = true;
      player.setActiveForLockScreen(true, { title, artist: "SyncMyQue · offline UTC sync" });
    } catch {}
  }, [player, title]);

  const setTempo = useCallback(
    (r: number) => {
      if (rateRef.current === r) return;
      rateRef.current = r;
      try {
        player.setPlaybackRate(r, PITCH_QUALITY);
      } catch {}
      setRate(r);
    },
    [player],
  );

  const toggleAutoSync = useCallback(() => {
    const on = !autoSyncRef.current;
    autoSyncRef.current = on;
    setAutoSync(on);
    storage.setItem(AUTO_SYNC_KEY, on);
    if (!on) setTempo(1);
  }, [setTempo]);

  /** SYNC-NOW: jump once to the exact shared position. */
  const syncNow = useCallback(() => {
    forceSync.current = true;
  }, []);

  /** This phone only: "sync" = play along (re-joins in sync), "paused", "stopped" (back to 0:00). */
  const setLocalMode = useCallback((m: LocalMode) => {
    localRef.current = m;
    setLocalModeState(m);
    if (m === "sync") startedAt.current = 0;
  }, []);

  useEffect(() => {
    const tick = async () => {
      if (!player.isLoaded || seeking.current) return;
      const dur = player.duration || 0;
      if (!dur) return;
      if (!primed.current && !player.playing) {
        primed.current = true;
        try {
          player.setPlaybackRate(1, PITCH_QUALITY);
        } catch {}
      }
      const s = { ...stateRef.current, durations_ms: [dur * 1000] } as SongState;
      const clock = () => Date.now() + (offsetHolder.current.current ?? 0);
      const now = clock();
      const tl = timeline(s, now, dur);
      const lm = localRef.current;
      setPhase(lm === "stopped" ? "stopped" : lm === "paused" ? "paused" : tl.mode);
      setWait(tl.wait);
      setPos(tl.pos);

      // Stopped / paused (locally or by the admin): silent, parked at the right spot
      if (lm !== "sync" || tl.mode === "stopped" || tl.mode === "paused") {
        if (player.playing) player.pause();
        const stop = lm === "stopped" || (lm === "sync" && tl.mode === "stopped");
        const key = stop ? "stop" : `pause:${s.version}:${lm}`;
        if (parked.current !== key) {
          parked.current = key;
          setTempo(1);
          if (stop) player.seekTo(0).catch(() => {});
          else if (lm === "sync") player.seekTo(tl.pos).catch(() => {});
        }
        startKey.current = null;
        return;
      }

      if (tl.mode === "countdown" || tl.mode === "gap") {
        const key = `${s.version}:${tl.mode === "countdown" ? "c" : `g${tl.cycle}`}`;
        if (parked.current !== key) {
          parked.current = key;
          if (player.playing) player.pause();
          setTempo(1);
          player.seekTo(tl.pos).catch(() => {});
        }
        // Start exactly on time instead of on the next tick
        if (tl.wait < 0.6 && startKey.current !== key) {
          startKey.current = key;
          setTimeout(() => {
            if (localRef.current !== "sync") return;
            player.play();
            startedAt.current = Date.now();
          }, Math.max(0, tl.wait * 1000));
        }
        return;
      }
      if (tl.mode !== "play") return;
      if (Date.now() - startedAt.current < 1200) return; // let playback settle
      if (!player.playing) {
        // Joined in the middle / pressed Play again: seek to the shared position
        seeking.current = true;
        await player.seekTo(timeline(s, clock(), dur).pos).catch(() => {});
        player.play();
        startedAt.current = Date.now();
        seeking.current = false;
        return;
      }
      const d = player.currentTime - tl.pos;
      setDrift(d);
      if (forceSync.current || Math.abs(d) > HARD_SEEK_S) {
        forceSync.current = false;
        seeking.current = true;
        await player.seekTo(timeline(s, clock(), dur).pos).catch(() => {});
        seeking.current = false;
        setTempo(1);
        startedAt.current = Date.now();
        return;
      }
      if (!autoSyncRef.current) return;
      const local = Date.now();
      if (local - lastCheck.current >= 1000) {
        lastCheck.current = local;
        const dev = Math.abs(d) <= DEADBAND_S ? 0 : Math.min(MAX_DEV, Math.abs(d) / RESPONSE_S);
        setTempo(Math.round((d > 0 ? 1 - dev : 1 + dev) * 1000) / 1000);
      }
    };
    const t = setInterval(tick, 100);
    return () => clearInterval(t);
  }, [player, setTempo]);

  // Stop audio when leaving the screen
  useEffect(
    () => () => {
      try {
        player.pause();
        player.setActiveForLockScreen(false);
      } catch {}
    },
    [player],
  );

  return { phase, wait, pos, drift, rate, autoSync, toggleAutoSync, syncNow, localMode, setLocalMode };
}
