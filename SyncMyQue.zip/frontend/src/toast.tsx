import React, { createContext, useCallback, useContext, useRef, useState } from "react";
import { Text, View } from "react-native";
import Animated, { FadeInUp, FadeOutUp } from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { fonts, makeStyles, radius, spacing } from "@/src/theme";

type Kind = "info" | "error" | "success";
type ToastCtx = { show: (msg: string, kind?: Kind) => void };
const Ctx = createContext<ToastCtx>({ show: () => {} });

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const styles = useStyles();
  const insets = useSafeAreaInsets();
  const [toast, setToast] = useState<{ msg: string; kind: Kind; key: number } | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const show = useCallback((msg: string, kind: Kind = "info") => {
    if (timer.current) clearTimeout(timer.current);
    setToast({ msg, kind, key: Date.now() });
    timer.current = setTimeout(() => setToast(null), 3200);
  }, []);

  return (
    <Ctx.Provider value={{ show }}>
      <View style={{ flex: 1 }}>
        {children}
        {toast && (
          <Animated.View
            key={toast.key}
            entering={FadeInUp}
            exiting={FadeOutUp}
            style={[styles.wrap, { top: insets.top + spacing.sm, pointerEvents: "none" }]}
          >
            <View
              testID="toast-message"
              style={[styles.toast, toast.kind === "error" && styles.error, toast.kind === "success" && styles.success]}
            >
              <Text style={[styles.text, toast.kind !== "info" && styles.textOn]}>{toast.msg}</Text>
            </View>
          </Animated.View>
        )}
      </View>
    </Ctx.Provider>
  );
}

export const useToast = () => useContext(Ctx);

const useStyles = makeStyles((c) => ({
  wrap: { position: "absolute", left: spacing.lg, right: spacing.lg, alignItems: "center" },
  toast: {
    backgroundColor: c.surfaceInverse,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    maxWidth: 480,
  },
  error: { backgroundColor: c.error },
  success: { backgroundColor: c.success },
  text: { color: c.onSurfaceInverse, fontFamily: fonts.textMedium, fontSize: 14 },
  textOn: { color: c.onError },
}));
