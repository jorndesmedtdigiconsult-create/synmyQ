import React, { createContext, useCallback, useContext, useEffect, useState } from "react";

import { apiFetch, setApiDeviceId, setApiToken, setUnauthorizedHandler } from "@/src/api";
import { ensureDeviceId } from "@/src/device";
import { clearLocalLibrary } from "@/src/library";
import { storage } from "@/src/utils/storage";

const TOKEN_KEY = "jynque_session_token";
// Last profile name: used to log in again automatically (as guest) when no valid session is left
const LAST_NAME_KEY = "syncmyque_last_name";

export type AuthUser = { user_id: string; email?: string | null; name?: string | null; is_guest: boolean };

type AuthCtx = {
  user: AuthUser | null;
  loading: boolean;
  signInWithApple: (identityToken: string, fullName?: string | null, email?: string | null) => Promise<void>;
  signInAsGuest: () => Promise<void>;
  setName: (name: string) => Promise<void>;
  logout: () => Promise<void>;
  deleteAccount: () => Promise<void>;
};

const Ctx = createContext<AuthCtx | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  const clear = useCallback(async () => {
    await storage.secureRemove(TOKEN_KEY);
    setApiToken(null);
    setUser(null);
  }, []);

  const finish = useCallback(async (token: string) => {
    await storage.secureSet(TOKEN_KEY, token);
    setApiToken(token);
    const me = await apiFetch<AuthUser>("/auth/me");
    setUser(me);
  }, []);

  // Remember the last real profile name for automatic login next time
  useEffect(() => {
    const n = (user?.name ?? "").trim();
    if (user && user.user_id !== "offline" && n && n !== "Gast") storage.setItem(LAST_NAME_KEY, n);
  }, [user]);

  useEffect(() => {
    setUnauthorizedHandler(() => {
      clear();
    });
    (async () => {
      setApiDeviceId(await ensureDeviceId());
      const token = await storage.secureGet(TOKEN_KEY, null);
      let restored = false;
      if (token && typeof token === "string") {
        setApiToken(token);
        try {
          const me = await apiFetch<AuthUser>("/auth/me");
          setUser(me);
          restored = true;
        } catch (e: any) {
          // Offline: keep token, allow offline usage with a placeholder user
          if (e?.status !== 401) {
            setUser({ user_id: "offline", is_guest: true, name: "Offline" });
            restored = true;
          } else await clear();
        }
      }
      if (!restored) {
        // Auto-login with the last profile name the user gave
        const last = await storage.getItem(LAST_NAME_KEY, null);
        if (typeof last === "string" && last.trim()) {
          try {
            const r = await apiFetch<{ session_token: string }>("/auth/guest", {
              method: "POST",
              body: JSON.stringify({ name: last }),
            });
            await finish(r.session_token);
          } catch {}
        }
      }
      setLoading(false);
    })();
    return () => setUnauthorizedHandler(null);
  }, [clear, finish]);

  const signInWithApple = useCallback(
    async (identityToken: string, fullName?: string | null, email?: string | null) => {
      const r = await apiFetch<{ session_token: string }>("/auth/apple", {
        method: "POST",
        body: JSON.stringify({ identity_token: identityToken, full_name: fullName ?? null, email: email ?? null }),
      });
      await finish(r.session_token);
    },
    [finish],
  );

  const signInAsGuest = useCallback(async () => {
    const r = await apiFetch<{ session_token: string }>("/auth/guest", { method: "POST" });
    await finish(r.session_token);
  }, [finish]);

  const setName = useCallback(async (name: string) => {
    const me = await apiFetch<AuthUser>("/auth/me", { method: "PATCH", body: JSON.stringify({ name }) });
    setUser(me);
  }, []);

  const logout = useCallback(async () => {
    try {
      await apiFetch("/auth/logout", { method: "POST" });
    } catch {}
    await clear();
  }, [clear]);

  /** Permanently deletes the account + all its data on the server and on this device. */
  const deleteAccount = useCallback(async () => {
    await apiFetch("/auth/me", { method: "DELETE" });
    await storage.removeItem(LAST_NAME_KEY);
    await clearLocalLibrary();
    await clear();
  }, [clear]);

  return (
    <Ctx.Provider value={{ user, loading, signInWithApple, signInAsGuest, setName, logout, deleteAccount }}>{children}</Ctx.Provider>
  );
}

export function useAuth() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useAuth outside AuthProvider");
  return c;
}

/** A signed-in user still needs to tell us their name (offline placeholder excluded). */
export function needsName(u: AuthUser | null) {
  if (!u || u.user_id === "offline") return false;
  const n = (u.name ?? "").trim();
  return !n || n === "Gast";
}
