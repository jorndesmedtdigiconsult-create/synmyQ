// UTC clock synchronisation (NTP-style) against the JynQue server, whose
// clock is disciplined to UTC atomic time. offset = serverUTC - localClock.
import { API } from "@/src/api";
import { storage } from "@/src/utils/storage";

const OFFSET_KEY = "jynque_clock_offset";

export type ClockInfo = { offsetMs: number; rttMs: number; syncedAt: number; online: boolean };

let info: ClockInfo = { offsetMs: 0, rttMs: 0, syncedAt: 0, online: false };
let loaded = false;

export async function loadCachedOffset() {
  if (loaded) return info;
  loaded = true;
  const cached = await storage.getItem(OFFSET_KEY, null);
  if (typeof cached === "number") info = { ...info, offsetMs: cached };
  return info;
}

export function utcNow() {
  return Date.now() + info.offsetMs;
}

export function getClockInfo() {
  return info;
}

async function sample(): Promise<{ offset: number; rtt: number } | null> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 3000);
  try {
    const t0 = Date.now();
    const res = await fetch(`${API}/time?_=${t0}`, { signal: ctrl.signal, cache: "no-store" });
    const j = await res.json();
    const t1 = Date.now();
    const rtt = t1 - t0;
    return { offset: j.server_ms + rtt / 2 - t1, rtt };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

export async function syncClock(samples = 6): Promise<ClockInfo> {
  await loadCachedOffset();
  const results: { offset: number; rtt: number }[] = [];
  for (let i = 0; i < samples; i++) {
    const s = await sample();
    if (s) results.push(s);
  }
  if (!results.length) {
    info = { ...info, online: false };
    return info;
  }
  // Use the samples with lowest round trip (least network asymmetry)
  results.sort((a, b) => a.rtt - b.rtt);
  const best = results.slice(0, Math.max(1, Math.ceil(results.length / 2)));
  const offset = best.reduce((s, r) => s + r.offset, 0) / best.length;
  info = { offsetMs: Math.round(offset), rttMs: Math.round(best[0].rtt), syncedAt: Date.now(), online: true };
  storage.setItem(OFFSET_KEY, info.offsetMs);
  return info;
}
