import { Platform } from "react-native";

import { storage } from "@/src/utils/storage";

const DEVICE_KEY = "jynque_device_id";
let cached: string | null = null;

/** Stable per-install device id (used for presence + control hand-over). */
export async function ensureDeviceId(): Promise<string> {
  if (cached) return cached;
  const stored = await storage.getItem(DEVICE_KEY, null);
  if (typeof stored === "string" && stored) {
    cached = stored;
  } else {
    cached = `dev_${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36).slice(-4)}`;
    await storage.setItem(DEVICE_KEY, cached);
  }
  return cached;
}

export function getDeviceIdSync() {
  return cached;
}

export function deviceLabel(userName?: string | null, _isGuest?: boolean) {
  const kind = Platform.OS === "ios" ? "iPhone" : Platform.OS === "android" ? "Android" : "Web";
  const tag = (cached ?? "").slice(-4).toUpperCase();
  const who = userName && userName !== "Gast" ? `${userName} · ` : "";
  return `${who}${kind} ${tag}`;
}
