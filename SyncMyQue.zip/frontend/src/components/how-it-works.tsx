import Ionicons from "@react-native-vector-icons/ionicons";
import { Pressable, Text, View } from "react-native";
import Animated, { FadeIn } from "react-native-reanimated";

import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

const STEPS = [
  { icon: "log-in-outline", title: "Log in", text: "Met Apple of als gast, en kies je naam." },
  { icon: "qr-code-outline", title: "Scan de QR-code", text: "Van de beheerder: je zit meteen in de sessie, zonder wachtwoord." },
  { icon: "keypad-outline", title: "Of typ het ID", text: "Zonder QR vraagt de app het wachtwoord van de beheerder." },
  { icon: "play-outline", title: "Beheerder drukt Start", text: "Alle toestellen spelen tegelijk af op UTC-tijd." },
] as const;

/** Step-by-step explainer. Pass `onToggle` to make it collapsible (header becomes a button). */
export function HowItWorks({ open = true, onToggle }: { open?: boolean; onToggle?: () => void }) {
  const styles = useStyles();
  const { colors } = useTheme();
  return (
    <View testID="how-it-works" style={styles.card}>
      {onToggle ? (
        <Pressable testID="how-it-works-toggle" onPress={onToggle} hitSlop={8} style={styles.head}>
          <Text style={[styles.label, { flex: 1 }]}>ZO WERKT HET</Text>
          <Ionicons name={open ? "chevron-up" : "chevron-down"} size={18} color={colors.accent} />
        </Pressable>
      ) : (
        <Text style={styles.label}>ZO WERKT HET</Text>
      )}
      {open && (
        <Animated.View entering={FadeIn} testID="how-it-works-steps" style={{ gap: spacing.md }}>
          {STEPS.map((s, i) => (
            <View key={s.title} style={styles.step}>
              <View style={styles.num}>
                <Text style={styles.numText}>{i + 1}</Text>
              </View>
              <View style={{ flex: 1 }}>
                <View style={styles.titleRow}>
                  <Ionicons name={s.icon} size={15} color={colors.accent} />
                  <Text style={styles.title}>{s.title}</Text>
                </View>
                <Text style={styles.text}>{s.text}</Text>
              </View>
            </View>
          ))}
        </Animated.View>
      )}
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  card: {
    padding: spacing.lg,
    borderRadius: radius.lg,
    backgroundColor: c.surfaceSecondary,
    borderWidth: 1,
    borderColor: c.border,
    gap: spacing.md,
  },
  label: {
    color: c.onSurface,
    fontFamily: fonts.displaySemi,
    fontSize: 13,
    letterSpacing: 2,
    borderLeftWidth: 3,
    borderLeftColor: c.accent,
    paddingLeft: spacing.sm,
  },
  head: { flexDirection: "row", alignItems: "center", minHeight: 28 },
  step: { flexDirection: "row", gap: spacing.md, alignItems: "flex-start" },
  num: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: c.accent,
    alignItems: "center",
    justifyContent: "center",
  },
  numText: { color: c.onAccent, fontFamily: fonts.display, fontSize: 15 },
  titleRow: { flexDirection: "row", alignItems: "center", gap: spacing.xs },
  title: { color: c.onSurface, fontFamily: fonts.textSemi, fontSize: 14 },
  text: { color: c.muted, fontFamily: fonts.text, fontSize: 13, lineHeight: 18 },
}));
