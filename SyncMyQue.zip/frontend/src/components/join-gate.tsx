import Ionicons from "@react-native-vector-icons/ionicons";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import { useState } from "react";
import { ActivityIndicator, Pressable, Text, TextInput, View } from "react-native";
import { KeyboardAvoidingView } from "react-native-keyboard-controller";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { apiFetch } from "@/src/api";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

export const PASSWORD_REQUIRED = "WACHTWOORD_VEREIST";

/** Joins a session with its password. Resolves true on success. */
export async function joinSession(kind: "songs" | "playlists", id: string, password: string) {
  await apiFetch(`/${kind}/${id}/join`, { method: "POST", body: JSON.stringify({ password }) });
  return true;
}

type Props = { kind: "songs" | "playlists"; id: string; onJoined: () => void };

/** Full-screen gate shown when a guest opens a session by typing its ID (not via QR). */
export function JoinGate({ kind, id, onJoined }: Props) {
  const styles = useStyles();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async () => {
    if (pw.trim().length < 4) return;
    setBusy(true);
    setError(null);
    try {
      await joinSession(kind, id, pw.trim().toUpperCase());
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      onJoined();
    } catch (e: any) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      setError(e?.message ?? "Wachtwoord klopt niet");
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView behavior="padding" style={styles.root}>
      <View style={[styles.inner, { paddingTop: insets.top + spacing.sm, paddingBottom: insets.bottom + spacing.xl }]}>
        <Pressable testID="join-back-button" onPress={() => (router.canGoBack() ? router.back() : router.replace("/"))} style={styles.iconBtn}>
          <Ionicons name="chevron-back" size={26} color={colors.onSurface} />
        </Pressable>
        <View style={styles.body}>
          <View style={styles.lock}>
            <Ionicons name="lock-closed" size={30} color={colors.onSurface} />
          </View>
          <Text style={styles.title}>Wachtwoord vereist</Text>
          <Text style={styles.sub}>
            Vraag de beheerder naar het wachtwoord van {kind === "playlists" ? "lijst" : "nummer"} {id}. Het staat bovenaan in zijn speler. Via de QR-code join je zonder wachtwoord.
          </Text>
          <TextInput
            testID="join-password-input"
            value={pw}
            onChangeText={(v) => setPw(v.toUpperCase())}
            placeholder="WACHTWOORD"
            placeholderTextColor={colors.muted}
            autoCapitalize="characters"
            autoCorrect={false}
            autoFocus
            maxLength={12}
            onSubmitEditing={submit}
            style={styles.input}
          />
          {error && (
            <Text testID="join-error" style={styles.error}>
              {error}
            </Text>
          )}
        </View>
        <Pressable
          testID="join-submit-button"
          onPress={submit}
          disabled={busy || pw.trim().length < 4}
          style={[styles.primary, (busy || pw.trim().length < 4) && { opacity: 0.4 }]}
        >
          {busy ? <ActivityIndicator color={colors.onBrandPrimary} /> : <Text style={styles.primaryLabel}>Join sessie</Text>}
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  inner: { flex: 1, paddingHorizontal: spacing.lg },
  iconBtn: { width: 44, height: 44, alignItems: "center", justifyContent: "center", marginLeft: -spacing.sm },
  body: { flex: 1, justifyContent: "center", gap: spacing.md },
  lock: { width: 64, height: 64, borderRadius: 32, borderWidth: 1, borderColor: c.borderStrong, alignItems: "center", justifyContent: "center" },
  title: { color: c.onSurface, fontFamily: fonts.display, fontSize: 36 },
  sub: { color: c.muted, fontFamily: fonts.text, fontSize: 14 },
  input: {
    height: 60,
    borderRadius: radius.md,
    backgroundColor: c.surfaceTertiary,
    borderWidth: 1,
    borderColor: c.border,
    color: c.onSurface,
    paddingHorizontal: spacing.lg,
    fontFamily: fonts.display,
    fontSize: 28,
    letterSpacing: 6,
    marginTop: spacing.sm,
  },
  error: { color: c.error, fontFamily: fonts.textMedium, fontSize: 14 },
  primary: { height: 52, borderRadius: radius.md, backgroundColor: c.brandPrimary, alignItems: "center", justifyContent: "center" },
  primaryLabel: { color: c.onBrandPrimary, fontFamily: fonts.textSemi, fontSize: 16 },
}));
