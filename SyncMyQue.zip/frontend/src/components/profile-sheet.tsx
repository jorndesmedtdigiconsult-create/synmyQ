import Ionicons from "@react-native-vector-icons/ionicons";
import { useEffect, useState } from "react";
import { ActivityIndicator, Modal, Pressable, Text, TextInput, View } from "react-native";
import { KeyboardAvoidingView } from "react-native-keyboard-controller";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAuth } from "@/src/auth";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";
import { useToast } from "@/src/toast";

export function ProfileSheet({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const styles = useStyles();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const { user, setName, deleteAccount } = useAuth();
  const toast = useToast();
  const [name, setNameInput] = useState(user?.name ?? "");
  const [busy, setBusy] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const trimmed = name.trim();

  useEffect(() => {
    if (visible) {
      setNameInput(user?.name ?? "");
      setConfirmDelete(false);
    }
  }, [visible, user?.name]);

  const onDelete = async () => {
    setDeleting(true);
    try {
      await deleteAccount();
      onClose();
      toast.show("Je account en gegevens zijn verwijderd", "success");
    } catch {
      toast.show("Verwijderen mislukt. Controleer je verbinding en probeer opnieuw.", "error");
    } finally {
      setDeleting(false);
    }
  };

  const onSave = async () => {
    if (!trimmed) return;
    setBusy(true);
    try {
      await setName(trimmed);
      toast.show(`Naam bijgewerkt: Hallo, ${trimmed}!`, "success");
      onClose();
    } catch {
      toast.show("Kan niet verbinden met de cloud. Probeer opnieuw.", "error");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <KeyboardAvoidingView behavior="padding" style={{ flex: 1 }}>
        <Pressable testID="profile-sheet-backdrop" style={styles.backdrop} onPress={busy ? undefined : onClose} />
        <View testID="profile-sheet" style={[styles.sheet, { paddingBottom: insets.bottom + spacing.xl }]}>
          <View style={styles.handle} />
          <Text style={styles.label}>PROFIEL</Text>
          <Text style={styles.title}>Je naam</Text>
          <TextInput
            testID="profile-name-input"
            value={name}
            onChangeText={setNameInput}
            placeholder="Je voornaam"
            placeholderTextColor={colors.muted}
            autoCapitalize="words"
            autoCorrect={false}
            maxLength={40}
            returnKeyType="done"
            onSubmitEditing={onSave}
            style={styles.input}
          />
          <Text style={styles.hint}>Andere toestellen zien deze naam in de luisterlijst.</Text>
          <View style={styles.row}>
            <Pressable testID="profile-cancel-button" onPress={onClose} disabled={busy} style={({ pressed }) => [styles.secondary, pressed && styles.pressed]}>
              <Text style={styles.secondaryLabel}>Annuleren</Text>
            </Pressable>
            <Pressable
              testID="profile-save-button"
              onPress={onSave}
              disabled={!trimmed || busy}
              style={({ pressed }) => [styles.primary, (!trimmed || busy) && { opacity: 0.4 }, pressed && styles.pressed]}
            >
              {busy ? <ActivityIndicator color={colors.onBrandPrimary} /> : <Text style={styles.primaryLabel}>Opslaan</Text>}
            </Pressable>
          </View>

          <View style={styles.dangerZone}>
            {!confirmDelete ? (
              <Pressable
                testID="delete-account-button"
                onPress={() => setConfirmDelete(true)}
                disabled={busy}
                style={({ pressed }) => [styles.deleteBtn, pressed && styles.pressed]}
              >
                <Ionicons name="trash-outline" size={18} color={colors.error} />
                <Text style={styles.deleteLabel}>Account verwijderen</Text>
              </Pressable>
            ) : (
              <View testID="delete-account-confirm" style={{ gap: spacing.md }}>
                <Text style={styles.deleteWarn}>
                  Dit verwijdert je account, je geüploade nummers en afspeellijsten definitief. Dit kan niet ongedaan gemaakt worden.
                </Text>
                <View style={styles.row2}>
                  <Pressable
                    testID="delete-account-cancel"
                    onPress={() => setConfirmDelete(false)}
                    disabled={deleting}
                    style={({ pressed }) => [styles.secondary, pressed && styles.pressed]}
                  >
                    <Text style={styles.secondaryLabel}>Toch niet</Text>
                  </Pressable>
                  <Pressable
                    testID="delete-account-confirm-button"
                    onPress={onDelete}
                    disabled={deleting}
                    style={({ pressed }) => [styles.dangerBtn, pressed && styles.pressed]}
                  >
                    {deleting ? <ActivityIndicator color={colors.onSurface} /> : <Text style={styles.dangerLabel}>Definitief verwijderen</Text>}
                  </Pressable>
                </View>
              </View>
            )}
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const useStyles = makeStyles((c) => ({
  backdrop: { flex: 1, backgroundColor: "rgba(0,0,0,0.7)" },
  sheet: {
    backgroundColor: c.surfaceSecondary,
    borderTopLeftRadius: radius.lg,
    borderTopRightRadius: radius.lg,
    borderTopWidth: 1,
    borderColor: c.borderStrong,
    paddingHorizontal: spacing.xl,
    paddingTop: spacing.md,
  },
  handle: { alignSelf: "center", width: 40, height: 4, borderRadius: 2, backgroundColor: c.borderStrong, marginBottom: spacing.lg },
  label: { color: c.muted, fontFamily: fonts.displaySemi, fontSize: 12, letterSpacing: 2 },
  title: { color: c.onSurface, fontFamily: fonts.display, fontSize: 28 },
  input: {
    marginTop: spacing.md,
    height: 56,
    borderRadius: radius.md,
    backgroundColor: c.surfaceTertiary,
    borderWidth: 1,
    borderColor: c.border,
    color: c.onSurface,
    paddingHorizontal: spacing.lg,
    fontFamily: fonts.textMedium,
    fontSize: 18,
  },
  hint: { color: c.muted, fontFamily: fonts.text, fontSize: 13, marginTop: spacing.sm },
  row: { flexDirection: "row", gap: spacing.md, marginTop: spacing.xl },
  secondary: { flex: 1, height: 52, borderRadius: radius.md, backgroundColor: c.brandSecondary, alignItems: "center", justifyContent: "center" },
  secondaryLabel: { color: c.onBrandSecondary, fontFamily: fonts.textSemi, fontSize: 15 },
  primary: { flex: 1, height: 52, borderRadius: radius.md, backgroundColor: c.brandPrimary, alignItems: "center", justifyContent: "center" },
  primaryLabel: { color: c.onBrandPrimary, fontFamily: fonts.textSemi, fontSize: 15 },
  pressed: { opacity: 0.7 },
  dangerZone: { marginTop: spacing.xl, paddingTop: spacing.lg, borderTopWidth: 1, borderTopColor: c.border },
  deleteBtn: { height: 48, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: spacing.sm },
  deleteLabel: { color: c.error, fontFamily: fonts.textSemi, fontSize: 15 },
  deleteWarn: { color: c.onSurface, fontFamily: fonts.text, fontSize: 14, lineHeight: 20 },
  row2: { flexDirection: "row", gap: spacing.md },
  dangerBtn: { flex: 1, height: 52, borderRadius: radius.md, backgroundColor: c.error, alignItems: "center", justifyContent: "center" },
  dangerLabel: { color: c.onSurface, fontFamily: fonts.textSemi, fontSize: 15 },
}));
