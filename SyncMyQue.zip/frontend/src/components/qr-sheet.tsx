import Ionicons from "@react-native-vector-icons/ionicons";
import { useEffect, useState } from "react";
import { Modal, Pressable, Share, Text, View } from "react-native";
import QRCode from "react-native-qrcode-svg";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { apiFetch } from "@/src/api";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

export const QR_PREFIX = "syncmyque:";
const QR_PREFIXES = [QR_PREFIX, "jynque:"]; // keep old QR codes scannable

/** Parses a scanned QR value: "syncmyque:ID:PASSWORD", "syncmyque:ID" or a raw ID. */
export function parseQrValue(raw: string): { id: string; password: string | null } | null {
  const v = raw.trim();
  const prefix = QR_PREFIXES.find((p) => v.toLowerCase().startsWith(p));
  const body = (prefix ? v.slice(prefix.length) : v).toUpperCase();
  const [id, password] = body.split(":");
  if (!/^[A-Z0-9]{4,12}$/.test(id)) return null;
  return { id, password: password && /^[A-Z0-9]{4,12}$/.test(password) ? password : null };
}

type Props = { visible: boolean; songId: string; title: string; onClose: () => void };

export function QrSheet({ visible, songId, title, onClose }: Props) {
  const styles = useStyles();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const [password, setPassword] = useState<string | null>(null);
  const kind = songId.length === 7 ? "playlists" : "songs";

  // Only the owner / controller gets the password; the QR then lets guests join in one scan
  useEffect(() => {
    if (!visible || !songId) return;
    apiFetch<{ password: string }>(`/${kind}/${songId}/password`)
      .then((r) => setPassword(r.password))
      .catch(() => setPassword(null));
  }, [visible, songId, kind]);

  const onShare = async () => {
    try {
      await Share.share({ message: `Speel "${title}" synchroon af in SyncMyQue met ID: ${songId}` });
    } catch {}
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable testID="qr-sheet-backdrop" style={styles.backdrop} onPress={onClose} />
      <View testID="qr-sheet" style={[styles.sheet, { paddingBottom: insets.bottom + spacing.xl }]}>
        <View style={styles.handle} />
        <Text style={styles.label}>SCAN OM TE LADEN</Text>
        <Text style={styles.title} numberOfLines={1}>
          {title}
        </Text>
        <View testID="qr-code" style={styles.qrBox}>
          <QRCode value={`${QR_PREFIX}${songId}${password ? `:${password}` : ""}`} size={220} color="#000000" backgroundColor="#FFFFFF" />
        </View>
        <Text testID="qr-song-id" style={styles.id} selectable>
          {songId}
        </Text>
        {password && (
          <Text testID="qr-password" style={styles.pw} selectable>
            WACHTWOORD {password}
          </Text>
        )}
        <View style={styles.row}>
          <Pressable testID="qr-share-button" onPress={onShare} style={({ pressed }) => [styles.secondary, pressed && styles.pressed]}>
            <Ionicons name="share-outline" size={20} color={colors.onBrandSecondary} />
            <Text style={styles.secondaryLabel}>Deel ID</Text>
          </Pressable>
          <Pressable testID="qr-close-button" onPress={onClose} style={({ pressed }) => [styles.primary, pressed && styles.pressed]}>
            <Text style={styles.primaryLabel}>Sluiten</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const useStyles = makeStyles((c) => ({
  backdrop: { flex: 1, backgroundColor: "rgba(0,0,0,0.7)" },
  sheet: {
    backgroundColor: c.surfaceSecondary,
    borderTopLeftRadius: radius.lg,
    borderTopRightRadius: radius.lg,
    borderTopWidth: 1,
    borderColor: c.borderStrong,
    paddingHorizontal: spacing.xl,
    paddingTop: spacing.md,
    alignItems: "center",
  },
  handle: { width: 40, height: 4, borderRadius: 2, backgroundColor: c.borderStrong, marginBottom: spacing.lg },
  label: { color: c.accent, fontFamily: fonts.displaySemi, fontSize: 13, letterSpacing: 2 },
  title: { color: c.onSurface, fontFamily: fonts.textMedium, fontSize: 16, marginTop: spacing.xs },
  qrBox: { marginTop: spacing.lg, padding: spacing.lg, borderRadius: radius.md, backgroundColor: c.surfaceInverse },
  id: { color: c.onSurface, fontFamily: fonts.display, fontSize: 40, letterSpacing: 8, marginTop: spacing.md },
  pw: { color: c.muted, fontFamily: fonts.displaySemi, fontSize: 16, letterSpacing: 3, marginTop: spacing.xs },
  row: { flexDirection: "row", gap: spacing.md, marginTop: spacing.lg, alignSelf: "stretch" },
  secondary: {
    flex: 1,
    height: 52,
    borderRadius: radius.md,
    backgroundColor: c.brandSecondary,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
  },
  secondaryLabel: { color: c.onBrandSecondary, fontFamily: fonts.textSemi, fontSize: 15 },
  primary: { flex: 1, height: 52, borderRadius: radius.md, backgroundColor: c.accent, alignItems: "center", justifyContent: "center" },
  primaryLabel: { color: c.onAccent, fontFamily: fonts.textSemi, fontSize: 15 },
  pressed: { opacity: 0.7 },
}));
