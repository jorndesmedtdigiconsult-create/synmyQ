import Ionicons from "@react-native-vector-icons/ionicons";
import { useState } from "react";
import { ActivityIndicator, Pressable, Text, TextInput, View } from "react-native";

import type { LibrarySong } from "@/src/library";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

type Props = {
  tracks: LibrarySong[];
  current: number;
  canControl: boolean;
  busy: boolean;
  onSkip: (index: number) => void;
  onAdd?: (songId: string) => Promise<void>;
  onReorder?: (order: number[]) => Promise<void>;
};

export function QueuePanel({ tracks, current, canControl, busy, onSkip, onAdd, onReorder }: Props) {
  const [moving, setMoving] = useState(false);
  const idx = tracks.map((_, i) => i);
  const reorder = async (order: number[]) => {
    if (!onReorder || moving) return;
    setMoving(true);
    try {
      await onReorder(order);
    } finally {
      setMoving(false);
    }
  };
  const move = (i: number, dir: -1 | 1) => {
    const o = [...idx];
    [o[i], o[i + dir]] = [o[i + dir], o[i]];
    reorder(o);
  };
  const styles = useStyles();
  const { colors } = useTheme();
  const [newId, setNewId] = useState("");
  const [adding, setAdding] = useState(false);

  const add = async () => {
    const id = newId.trim().toUpperCase();
    if (!onAdd || id.length < 4) return;
    setAdding(true);
    try {
      await onAdd(id);
      setNewId("");
    } finally {
      setAdding(false);
    }
  };

  return (
    <View testID="queue-panel" style={styles.panel}>
      <View style={styles.head}>
        <Text style={styles.label}>WACHTRIJ · {tracks.length} NUMMERS</Text>
        {canControl && (
          <View style={styles.skipRow}>
            <Pressable testID="queue-prev-button" disabled={busy} onPress={() => onSkip(current - 1 + tracks.length)} style={styles.skipBtn}>
              <Ionicons name="play-skip-back" size={18} color={colors.onSurface} />
            </Pressable>
            <Pressable testID="queue-next-button" disabled={busy} onPress={() => onSkip(current + 1)} style={styles.skipBtn}>
              <Ionicons name="play-skip-forward" size={18} color={colors.onSurface} />
            </Pressable>
          </View>
        )}
      </View>
      {tracks.map((t, i) => (
        <Pressable
          key={`${t.song_id}-${i}`}
          testID={`queue-item-${i}`}
          disabled={!canControl || busy}
          onPress={() => onSkip(i)}
          style={[styles.row, i === current && styles.rowActive]}
        >
          <Text style={[styles.num, i === current && styles.onActive]}>{i + 1}</Text>
          <Text style={[styles.title, i === current && styles.onActive]} numberOfLines={1}>
            {t.title}
          </Text>
          {i === current && <Ionicons name="volume-high" size={16} color={colors.onBrandPrimary} />}
          {canControl && onReorder && (
            <View style={styles.editRow}>
              <Pressable testID={`queue-up-${i}`} disabled={i === 0 || moving} onPress={() => move(i, -1)} style={[styles.editBtn, i === 0 && styles.dim]} hitSlop={4}>
                <Ionicons name="chevron-up" size={18} color={i === current ? colors.onBrandPrimary : colors.onSurface} />
              </Pressable>
              <Pressable
                testID={`queue-down-${i}`}
                disabled={i === tracks.length - 1 || moving}
                onPress={() => move(i, 1)}
                style={[styles.editBtn, i === tracks.length - 1 && styles.dim]}
                hitSlop={4}
              >
                <Ionicons name="chevron-down" size={18} color={i === current ? colors.onBrandPrimary : colors.onSurface} />
              </Pressable>
              <Pressable
                testID={`queue-remove-${i}`}
                disabled={tracks.length < 2 || moving}
                onPress={() => reorder(idx.filter((k) => k !== i))}
                style={[styles.editBtn, tracks.length < 2 && styles.dim]}
                hitSlop={4}
              >
                <Ionicons name="close" size={18} color={i === current ? colors.onBrandPrimary : colors.error} />
              </Pressable>
            </View>
          )}
        </Pressable>
      ))}
      {canControl && onAdd && (
        <View style={styles.addRow}>
          <TextInput
            testID="queue-add-input"
            value={newId}
            onChangeText={(v) => setNewId(v.toUpperCase())}
            placeholder="Nummer ID toevoegen"
            placeholderTextColor={colors.muted}
            autoCapitalize="characters"
            autoCorrect={false}
            maxLength={12}
            onSubmitEditing={add}
            style={styles.input}
          />
          <Pressable testID="queue-add-button" onPress={add} disabled={adding} style={styles.addBtn}>
            {adding ? <ActivityIndicator color={colors.onBrandPrimary} /> : <Ionicons name="add" size={22} color={colors.onBrandPrimary} />}
          </Pressable>
        </View>
      )}
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  panel: { marginTop: spacing.xl, padding: spacing.lg, borderRadius: radius.lg, backgroundColor: c.surfaceSecondary, borderWidth: 1, borderColor: c.border, gap: spacing.xs },
  head: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: spacing.xs },
  label: { color: c.muted, fontFamily: fonts.displaySemi, fontSize: 12, letterSpacing: 1.5 },
  skipRow: { flexDirection: "row", gap: spacing.xs },
  skipBtn: { width: 44, height: 44, borderRadius: radius.md, borderWidth: 1, borderColor: c.borderStrong, alignItems: "center", justifyContent: "center" },
  row: { flexDirection: "row", alignItems: "center", gap: spacing.md, minHeight: 44, paddingHorizontal: spacing.md, borderRadius: radius.md },
  rowActive: { backgroundColor: c.brandPrimary },
  num: { color: c.muted, fontFamily: fonts.display, fontSize: 16, width: 20 },
  title: { flex: 1, color: c.onSurface, fontFamily: fonts.textMedium, fontSize: 14 },
  onActive: { color: c.onBrandPrimary },
  editRow: { flexDirection: "row" },
  editBtn: { width: 36, height: 40, alignItems: "center", justifyContent: "center" },
  dim: { opacity: 0.25 },
  addRow: { flexDirection: "row", gap: spacing.sm, marginTop: spacing.sm },
  input: { flex: 1, minWidth: 0, height: 44, borderRadius: radius.md, backgroundColor: c.surfaceTertiary, borderWidth: 1, borderColor: c.border, color: c.onSurface, paddingHorizontal: spacing.md, fontFamily: fonts.display, fontSize: 17, letterSpacing: 2 },
  addBtn: { width: 44, height: 44, borderRadius: radius.md, backgroundColor: c.brandPrimary, alignItems: "center", justifyContent: "center" },
}));
