import Ionicons from "@react-native-vector-icons/ionicons";
import { Pressable, Text, View } from "react-native";

import type { Listener } from "@/src/library";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

type Props = {
  listeners: Listener[];
  myDeviceId: string | null;
  canTransfer: boolean;
  busyDevice: string | null;
  onTransfer: (l: Listener) => void;
  onKick?: (l: Listener) => void;
};

export function ListenersPanel({ listeners, myDeviceId, canTransfer, busyDevice, onTransfer, onKick }: Props) {
  const styles = useStyles();
  const { colors } = useTheme();
  const playing = listeners.filter((l) => l.playing);
  const synced = playing.filter((l) => l.in_sync).length;

  return (
    <View testID="listeners-panel" style={styles.panel}>
      <View style={styles.head}>
        <View>
          <Text style={styles.label}>VERBONDEN TOESTELLEN</Text>
          <Text testID="listener-count" style={styles.count}>
            {listeners.length}
            <Text style={styles.countSub}>
              {"  "}
              {playing.length ? `${synced}/${playing.length} IN SYNC` : "WACHTEN"}
            </Text>
          </Text>
        </View>
        <Ionicons name="people-outline" size={26} color={colors.onSurface} />
      </View>
      {listeners.map((l) => {
        const me = l.device_id === myDeviceId;
        const dot = !l.playing ? colors.borderStrong : l.in_sync ? colors.success : colors.warning;
        return (
          <View key={l.device_id} testID={`listener-row-${l.device_id}`} style={styles.row}>
            <View style={[styles.dot, { backgroundColor: dot }]} />
            <View style={{ flex: 1 }}>
              <Text style={styles.name} numberOfLines={1}>
                {l.name}
                {me ? " (jij)" : ""}
              </Text>
              <Text style={styles.meta}>
                {l.playing ? `${l.drift_ms >= 0 ? "+" : ""}${l.drift_ms} ms · ${l.in_sync ? "gelijk" : "synchroniseert"}` : "niet aan het spelen"}
              </Text>
            </View>
            {l.is_controller ? (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>BEHEER</Text>
              </View>
            ) : canTransfer && !me ? (
              <Pressable
                testID={`transfer-control-${l.device_id}`}
                onPress={() => onTransfer(l)}
                disabled={!!busyDevice}
                style={({ pressed }) => [styles.giveBtn, (pressed || busyDevice === l.device_id) && { opacity: 0.6 }]}
              >
                <Text style={styles.giveText}>Geef beheer</Text>
              </Pressable>
            ) : null}
            {canTransfer && !me && onKick && !l.is_controller && (
              <Pressable
                testID={`kick-listener-${l.device_id}`}
                onPress={() => onKick(l)}
                disabled={!!busyDevice}
                style={styles.kickBtn}
                hitSlop={4}
              >
                <Ionicons name="person-remove-outline" size={18} color={colors.error} />
              </Pressable>
            )}
          </View>
        );
      })}
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  panel: {
    marginTop: spacing.xl,
    padding: spacing.lg,
    borderRadius: radius.lg,
    backgroundColor: c.surfaceSecondary,
    borderWidth: 1,
    borderColor: c.border,
    gap: spacing.sm,
  },
  head: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: spacing.xs },
  label: { color: c.muted, fontFamily: fonts.displaySemi, fontSize: 12, letterSpacing: 1.5 },
  count: { color: c.onSurface, fontFamily: fonts.display, fontSize: 32 },
  countSub: { color: c.muted, fontFamily: fonts.displaySemi, fontSize: 14, letterSpacing: 1 },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    paddingVertical: spacing.sm,
    borderTopWidth: 1,
    borderTopColor: c.divider,
    minHeight: 52,
  },
  dot: { width: 10, height: 10, borderRadius: 5 },
  name: { color: c.onSurface, fontFamily: fonts.textMedium, fontSize: 14 },
  meta: { color: c.muted, fontFamily: fonts.displayMedium, fontSize: 13 },
  badge: { borderWidth: 1, borderColor: c.success, borderRadius: radius.sm, paddingHorizontal: spacing.sm, paddingVertical: 2 },
  badgeText: { color: c.success, fontFamily: fonts.displaySemi, fontSize: 11, letterSpacing: 1 },
  giveBtn: {
    height: 36,
    paddingHorizontal: spacing.md,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: c.onSurface,
    justifyContent: "center",
  },
  kickBtn: { width: 40, height: 40, alignItems: "center", justifyContent: "center" },
  giveText: { color: c.onSurface, fontFamily: fonts.textSemi, fontSize: 13 },
}));
