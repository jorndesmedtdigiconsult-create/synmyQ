import { useEffect } from "react";
import { Text, View } from "react-native";
import Animated, { useAnimatedStyle, useSharedValue, withDelay, withRepeat, withSequence, withTiming } from "react-native-reanimated";
import Svg, { Circle, Line } from "react-native-svg";

import { fonts, useTheme } from "@/src/theme";

// SyncMyQue mark: a UTC clock ring (12 ticks) whose yellow tail turns it into a "Q",
// with an equalizer inside = music in perfect sync with atomic time.
const BAR_HEIGHTS = [0.32, 0.58, 0.82, 0.58, 0.32];

function Bar({ size, h, i, animated, color }: { size: number; h: number; i: number; animated: boolean; color: string }) {
  const v = useSharedValue(h);
  useEffect(() => {
    if (!animated) return;
    v.value = withDelay(
      i * 90,
      withRepeat(withSequence(withTiming(Math.min(1, h + 0.25), { duration: 420 }), withTiming(Math.max(0.2, h - 0.15), { duration: 420 })), -1, true),
    );
  }, [animated, h, i, v]);
  const st = useAnimatedStyle(() => ({ height: size * 0.4 * v.value }));
  return <Animated.View style={[{ width: size * 0.055, borderRadius: size * 0.03, backgroundColor: color }, st]} />;
}

export function LogoMark({ size = 48, animated = false }: { size?: number; animated?: boolean }) {
  const { colors } = useTheme();
  const c = size / 2;
  const r = size * 0.36;
  const stroke = size * 0.06;
  const ticks = Array.from({ length: 12 }).map((_, k) => {
    const a = (k * Math.PI) / 6;
    const major = k % 3 === 0;
    const r1 = size * (major ? 0.43 : 0.45);
    const r2 = size * 0.485;
    return { x1: c + r1 * Math.sin(a), y1: c - r1 * Math.cos(a), x2: c + r2 * Math.sin(a), y2: c - r2 * Math.cos(a), major };
  });
  const ta = (3 * Math.PI) / 4; // tail at bottom-right
  return (
    <View testID="app-logo-mark" style={{ width: size, height: size }}>
      <Svg width={size} height={size}>
        {ticks.map((t, k) => (
          <Line
            key={k}
            x1={t.x1}
            y1={t.y1}
            x2={t.x2}
            y2={t.y2}
            stroke={t.major ? colors.onSurface : colors.borderStrong}
            strokeWidth={size * (t.major ? 0.035 : 0.02)}
            strokeLinecap="round"
          />
        ))}
        <Circle cx={c} cy={c} r={r} stroke={colors.onSurface} strokeWidth={stroke} fill="none" />
        <Line
          x1={c + r * 0.55 * Math.sin(ta)}
          y1={c - r * 0.55 * Math.cos(ta)}
          x2={c + size * 0.5 * Math.sin(ta)}
          y2={c - size * 0.5 * Math.cos(ta)}
          stroke={colors.accent}
          strokeWidth={stroke}
          strokeLinecap="round"
        />
      </Svg>
      <View
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "center",
          gap: size * 0.035,
        }}
      >
        {BAR_HEIGHTS.map((h, i) => (
          <Bar key={i} size={size} h={h} i={i} animated={animated} color={colors.onSurface} />
        ))}
      </View>
    </View>
  );
}

export function LogoLockup({ size = 40, animated = false, subtitle }: { size?: number; animated?: boolean; subtitle?: string }) {
  const { colors } = useTheme();
  const textSize = size * 0.8;
  return (
    <View testID="app-logo" style={{ flexDirection: "row", alignItems: "center", gap: size * 0.3 }}>
      <LogoMark size={size} animated={animated} />
      <View>
        <Text style={{ fontFamily: fonts.display, fontSize: textSize, lineHeight: textSize * 1.05, color: colors.onSurface, letterSpacing: 0.5 }}>
          SyncMy<Text style={{ color: colors.accent }}>Que</Text>
        </Text>
        {subtitle ? (
          <Text style={{ fontFamily: fonts.displaySemi, fontSize: Math.max(11, size * 0.26), color: colors.muted, letterSpacing: 2 }}>
            {subtitle}
          </Text>
        ) : null}
      </View>
    </View>
  );
}
