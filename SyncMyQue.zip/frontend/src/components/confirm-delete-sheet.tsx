import Ionicons from "@react-native-vector-icons/ionicons";
import { ActivityIndicator, Modal, Pressable, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import type { LibrarySong } from "@/src/library";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

type Props = { song: LibrarySong | null; busy: boolean; onCancel: () => void; onConfirm: () => void };

export function ConfirmDeleteSheet({ song, busy, onCancel, onConfirm }: Props) {
  const styles = useStyles();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const owner = !!song?.isOwner;

  return (
    <Modal visible={!!song} transparent animationType="slide" onRequestClose={onCancel}>
      <Pressable testID="delete-sheet-backdrop" style={styles.backdrop} onPress={busy ? undefined : onCancel} />
      <View testID="delete-confirm-sheet" style={[styles.sheet, { paddingBottom: insets.bottom + spacing.xl }]}>
        <View style={styles.handle} />
        <View style={styles.iconWrap}>
          <Ionicons name="warning-outline" size={28} color={colors.warning} />
        </View>
        <Text style={styles.title}>Nummer verwijderen?</Text>
        <Text style={styles.songTitle} numberOfLines={1}>
          {song?.title} · {song?.song_id}
        </Text>
        <View testID="delete-warning" style={styles.warning}>
          <Text style={styles.warningText}>
            {owner
              ? "Let op: jij bent de beheerder. Als je dit nummer verwijdert, stopt de muziek op ALLE verbonden toestellen."
              : "Let op: als dit nummer nu speelt, stopt de muziek op dit toestel. Andere toestellen spelen gewoon verder."}
          </Text>
          <Text style={styles.warningSub}>
            Het nummer wordt alleen van dit toestel verwijderd. Je kunt het later opnieuw laden met het ID.
          </Text>
        </View>
        <View style={styles.row}>
          <Pressable
            testID="delete-cancel-button"
            onPress={onCancel}
            disabled={busy}
            style={({ pressed }) => [styles.secondary, pressed && styles.pressed]}
          >
            <Text style={styles.secondaryLabel}>Annuleren</Text>
          </Pressable>
          <Pressable
            testID="delete-confirm-button"
            onPress={onConfirm}
            disabled={busy}
            style={({ pressed }) => [styles.danger, pressed && styles.pressed]}
          >
            {busy ? <ActivityIndicator color={colors.onError} /> : <Text style={styles.dangerLabel}>Ja, verwijderen</Text>}
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const useStyles = makeStyles((c) => ({
  backdrop: { flex: 1, backgroundColor: "rgba(0,0,0,0.7)" },
  sheet: {
    backgroundColor: c.surfaceSecondary,
    borderTopLeftRadius: radius.lg,
    borderTopRightRadius: radius.lg,
    borderTopWidth: 1,
    borderColor: c.borderStrong,
    paddingHorizontal: spacing.xl,
    paddingTop: spacing.md,
    alignItems: "center",
  },
  handle: { width: 40, height: 4, borderRadius: 2, backgroundColor: c.borderStrong, marginBottom: spacing.lg },
  iconWrap: {
    width: 56,
    height: 56,
    borderRadius: 28,
    borderWidth: 1,
    borderColor: c.warning,
    alignItems: "center",
    justifyContent: "center",
  },
  title: { color: c.onSurface, fontFamily: fonts.display, fontSize: 28, marginTop: spacing.md },
  songTitle: { color: c.muted, fontFamily: fonts.textMedium, fontSize: 14, marginTop: spacing.xs },
  warning: {
    alignSelf: "stretch",
    marginTop: spacing.lg,
    padding: spacing.lg,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: c.warning,
    gap: spacing.sm,
  },
  warningText: { color: c.onSurface, fontFamily: fonts.textSemi, fontSize: 14 },
  warningSub: { color: c.muted, fontFamily: fonts.text, fontSize: 13 },
  row: { flexDirection: "row", gap: spacing.md, marginTop: spacing.xl, alignSelf: "stretch" },
  secondary: {
    flex: 1,
    height: 52,
    borderRadius: radius.md,
    backgroundColor: c.brandSecondary,
    alignItems: "center",
    justifyContent: "center",
  },
  secondaryLabel: { color: c.onBrandSecondary, fontFamily: fonts.textSemi, fontSize: 15 },
  danger: { flex: 1, height: 52, borderRadius: radius.md, backgroundColor: c.error, alignItems: "center", justifyContent: "center" },
  dangerLabel: { color: c.onError, fontFamily: fonts.textSemi, fontSize: 15 },
  pressed: { opacity: 0.7 },
}));
