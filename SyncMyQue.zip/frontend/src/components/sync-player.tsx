import Ionicons from "@react-native-vector-icons/ionicons";
import { useAudioPlayer, useAudioPlayerStatus } from "expo-audio";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import { ActivityIndicator, Platform, Pressable, ScrollView, Text, View } from "react-native";
import Animated, { useAnimatedStyle, useSharedValue, withRepeat, withSequence, withTiming } from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { apiFetch } from "@/src/api";
import { useAuth } from "@/src/auth";
import { ListenersPanel } from "@/src/components/listeners-panel";
import { QueuePanel } from "@/src/components/queue-panel";
import { LogoMark } from "@/src/components/logo";
import { QrSheet } from "@/src/components/qr-sheet";
import { deviceLabel, getDeviceIdSync } from "@/src/device";
import { audioSourceFor, LibrarySong, prepareTracks, SongState } from "@/src/library";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";
import { useToast } from "@/src/toast";
import { useSyncEngine } from "@/src/use-sync-engine";

function fmt(sec: number) {
  if (!isFinite(sec) || sec < 0) sec = 0;
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

function Bars({ active }: { active: boolean }) {
  const styles = useStyles();
  return (
    <View style={styles.bars}>
      {Array.from({ length: 24 }).map((_, i) => (
        <Bar key={i} i={i} active={active} />
      ))}
    </View>
  );
}

function Bar({ i, active }: { i: number; active: boolean }) {
  const styles = useStyles();
  const h = useSharedValue(0.2);
  useEffect(() => {
    if (active) {
      const d = 300 + ((i * 53) % 400);
      h.value = withRepeat(withSequence(withTiming(0.3 + ((i * 37) % 70) / 100, { duration: d }), withTiming(0.15, { duration: d })), -1, true);
    } else {
      h.value = withTiming(0.12, { duration: 300 });
    }
  }, [active, h, i]);
  const st = useAnimatedStyle(() => ({ height: `${h.value * 100}%` }));
  return <Animated.View style={[styles.bar, st]} />;
}

export function LoadingView({ error, onRetry }: { error: string | null; onRetry: () => void }) {
  const styles = useStyles();
  const { colors } = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.root, styles.center, { paddingTop: insets.top }]}>
      {error ? (
        <View testID="player-load-error" style={styles.errorPanel}>
          <Text style={styles.errorTitle}>Synchronisatiefout</Text>
          <Text style={styles.errorText}>{error}</Text>
          <Pressable testID="player-retry-button" onPress={onRetry} style={styles.retryBtn}>
            <Text style={styles.retryLabel}>Probeer opnieuw</Text>
          </Pressable>
          <Pressable testID="player-back-error-button" onPress={() => (router.canGoBack() ? router.back() : router.replace("/"))} style={styles.retryGhost}>
            <Text style={styles.metaText}>Terug</Text>
          </Pressable>
        </View>
      ) : (
        <>
          <ActivityIndicator color={colors.onSurface} />
          <Text style={[styles.metaText, { marginTop: spacing.md }]}>Audio laden...</Text>
        </>
      )}
    </View>
  );
}

type SyncPlayerProps = {
  kind: "songs" | "playlists";
  sessionId: string;
  title: string;
  tracks: LibrarySong[];
  ownerHint?: boolean;
  onItems?: (items: string[]) => void;
  onAddSong?: (songId: string) => Promise<void>;
  onReorder?: (order: number[]) => Promise<void>;
};

export function SyncPlayer({ kind, sessionId, title, tracks, ownerHint, onItems, onAddSong, onReorder }: SyncPlayerProps) {
  const styles = useStyles();
  const { colors } = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const toast = useToast();

  const player = useAudioPlayer(audioSourceFor(tracks[0]), { updateInterval: 250 });
  const status = useAudioPlayerStatus(player);

  const engine = useSyncEngine(player, kind, sessionId, tracks);
  const {
    state,
    stateRef,
    applyState,
    listeners,
    online,
    clock,
    drift,
    rate,
    phase,
    wait,
    autoSync,
    toggleAutoSync,
    volume,
    setVolumeLocal,
    syncNow,
    currentTrack,
    removed,
  } = engine;
  const song = tracks[currentTrack] ?? tracks[0];
  const [busy, setBusy] = useState<"start" | "pause" | "stop" | "control" | null>(null);
  const [busyDevice, setBusyDevice] = useState<string | null>(null);
  const [qrOpen, setQrOpen] = useState(false);
  const [syncingNow, setSyncingNow] = useState(false);
  const { user } = useAuth();
  const myDeviceId = getDeviceIdSync();
  const isOwner = state?.owner_id ? state.owner_id === user?.user_id : !!ownerHint;

  // Playlist items changed on another device -> let the screen reload the queue
  const itemsKey = state?.items?.join(",") ?? "";
  useEffect(() => {
    if (itemsKey && onItems) onItems(itemsKey.split(","));
  }, [itemsKey, onItems]);

  // Background + lock-screen playback (works in a native build, not in Expo Go)
  useEffect(() => {
    if (!status.isLoaded || Platform.OS === "web") return;
    try {
      player.setActiveForLockScreen(true, { title: song.title, artist: "SyncMyQue · UTC sync" });
    } catch {}
  }, [status.isLoaded, player, song.title]);
  useEffect(
    () => () => {
      try {
        player.clearLockScreenControls();
      } catch {}
    },
    [player],
  );

  const canControl = state?.controller_device_id ? state.controller_device_id === myDeviceId : isOwner;
  const [joinPw, setJoinPw] = useState<string | null>(null);
  const showPw = canControl || isOwner;
  useEffect(() => {
    if (!showPw) return setJoinPw(null);
    apiFetch<{ password: string }>(`/${kind}/${sessionId}/password`)
      .then((r) => setJoinPw(r.password))
      .catch(() => setJoinPw(null));
  }, [showPw, kind, sessionId, state?.version]);

  const act = async (what: "start" | "pause" | "stop", path: string, body?: object) => {
    setBusy(what);
    try {
      const s = await apiFetch<SongState>(`/${kind}/${sessionId}/${path}`, {
        method: "POST",
        body: body ? JSON.stringify(body) : undefined,
      });
      applyState(s);
      return true;
    } catch (e: any) {
      toast.show(e?.status === 403 ? "Je hebt geen beheer over dit nummer" : "Vereist netwerk. Probeer opnieuw.", "error");
      return false;
    } finally {
      setBusy(null);
    }
  };

  const onStart = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    const resumed = state?.status === "paused";
    const ok = await act("start", "start", { duration_ms: Math.round((player.duration || 0) * 1000) || null });
    if (ok) toast.show(resumed ? "Hervatten op alle toestellen" : "Start verzonden naar alle toestellen", "success");
  };

  const onPause = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    await act("pause", "pause"); // every device fades out, then pauses
  };

  const onStop = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const ok = await act("stop", "stop");
    if (!ok) {
      const local: SongState = { song_id: sessionId, status: "stopped", start_at_ms: null, version: stateRef.current?.version ?? 0 };
      stateRef.current = local;
    }
  };

  const onRotate = async () => {
    Haptics.selectionAsync();
    try {
      const r = await apiFetch<{ password: string }>(`/${kind}/${sessionId}/password/rotate`, { method: "POST" });
      setJoinPw(r.password);
      toast.show("Nieuw wachtwoord gemaakt · oude QR-codes werken niet meer", "success");
    } catch {
      toast.show("Wachtwoord vernieuwen mislukt", "error");
    }
  };

  const onKick = async (l: { device_id: string; name: string }) => {
    setBusyDevice(l.device_id);
    try {
      const r = await apiFetch<{ password: string }>(`/${kind}/${sessionId}/kick`, {
        method: "POST",
        body: JSON.stringify({ device_id: l.device_id }),
      });
      setJoinPw(r.password);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
      toast.show(`${l.name} verwijderd · nieuw wachtwoord ${r.password}`, "success");
    } catch (e: any) {
      toast.show(e?.message ?? "Verwijderen mislukt", "error");
    } finally {
      setBusyDevice(null);
    }
  };

  // Web streams via short-lived signed links: refresh them regularly
  useEffect(() => {
    const t = setInterval(() => prepareTracks(tracks), 10 * 60 * 1000);
    return () => clearInterval(t);
  }, [tracks]);

  const onSkip = async (index: number) => {
    Haptics.selectionAsync();
    setBusy("start");
    try {
      applyState(await apiFetch<SongState>(`/playlists/${sessionId}/skip`, { method: "POST", body: JSON.stringify({ index }) }));
    } catch (e: any) {
      toast.show(e?.status === 403 ? "Je hebt geen beheer over deze lijst" : "Vereist netwerk. Probeer opnieuw.", "error");
    } finally {
      setBusy(null);
    }
  };

  const transfer = async (deviceId: string, name: string) => {
    setBusy("control");
    setBusyDevice(deviceId);
    try {
      const s = await apiFetch<SongState>(`/${kind}/${sessionId}/control`, {
        method: "POST",
        body: JSON.stringify({ device_id: deviceId, name }),
      });
      applyState(s);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      toast.show(deviceId === myDeviceId ? "Je hebt het beheer terug" : `Beheer gegeven aan ${name}`, "success");
    } catch (e: any) {
      toast.show(e?.status === 403 ? "Je mag het beheer niet doorgeven" : "Vereist netwerk. Probeer opnieuw.", "error");
    } finally {
      setBusy(null);
      setBusyDevice(null);
    }
  };

  if (removed) {
    return (
      <View testID="removed-screen" style={[styles.root, styles.center, { paddingTop: insets.top }]}>
        <View style={styles.errorPanel}>
          <Text style={styles.errorTitle}>Verwijderd uit sessie</Text>
          <Text style={styles.errorText}>De beheerder heeft je uit deze sessie verwijderd. Vraag een nieuw wachtwoord of QR-code om opnieuw te joinen.</Text>
          <Pressable testID="removed-home-button" onPress={() => router.replace("/")} style={styles.retryBtn}>
            <Text style={styles.retryLabel}>Terug naar start</Text>
          </Pressable>
        </View>
      </View>
    );
  }
  const volPct = Math.round(volume * 100);

  const onVolume = async (v: number) => {
    const nv = Math.max(0, Math.min(1, Math.round(v * 10) / 10));
    Haptics.selectionAsync();
    setVolumeLocal(nv);
    try {
      await apiFetch(`/${kind}/${sessionId}/volume`, { method: "POST", body: JSON.stringify({ volume: nv }) });
    } catch (e: any) {
      toast.show(e?.status === 403 ? "Je hebt geen beheer over dit nummer" : "Volume niet verzonden (geen netwerk)", "error");
    }
  };
  const pos = status.currentTime || 0;
  const dur = status.duration || 0;
  const progress = dur > 0 ? Math.min(1, pos / dur) : 0;
  const driftMs = Math.round(drift * 1000);
  const inSync = phase === "play" && Math.abs(drift) <= 0.05;
  const syncLabel =
    phase === "stopped"
      ? "GEREED · 0:00"
      : phase === "paused"
        ? "GEPAUZEERD"
        : phase === "countdown"
          ? `${state?.paused_pos_ms || (state?.resume_at_ms && state?.start_at_ms && state.resume_at_ms !== state.start_at_ms) ? "HERVAT" : "START"} IN ${Math.ceil(wait)}`
          : phase === "gap"
            ? `HERSTART IN ${Math.ceil(wait)}`
            : phase === "ended"
              ? "AFGELOPEN"
              : !autoSync
                ? "VRIJ · GEEN SYNC"
                : rate < 1
                ? "VERTRAGEN"
                : rate > 1
                  ? "INHALEN"
                  : inSync
                    ? "IN SYNC"
                    : "SYNCHRONISEREN";
  const syncColor = phase !== "play" ? colors.onSurface : inSync && rate === 1 ? colors.success : colors.warning;
  const isPlaying = phase === "play" || phase === "countdown" || phase === "gap";

  return (
    <View style={styles.root}>
      <View style={[styles.topBar, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable testID="player-back-button" onPress={() => (router.canGoBack() ? router.back() : router.replace("/"))} style={styles.iconBtn} hitSlop={8}>
          <Ionicons name="chevron-back" size={26} color={colors.onSurface} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text testID="player-song-title" style={styles.title} numberOfLines={1}>
            {title}
          </Text>
          <Text testID="player-song-id" style={styles.metaText} numberOfLines={1}>
            {kind === "playlists"
              ? `LIJST ${sessionId} · ${currentTrack + 1}/${tracks.length} · ${song.title}`
              : `ID ${sessionId} · ${song.localUri ? "OFFLINE OPGESLAGEN" : "STREAM"}`}
          </Text>
        </View>
        <Pressable testID="player-qr-button" onPress={() => setQrOpen(true)} style={styles.iconBtn} hitSlop={8}>
          <Ionicons name="qr-code-outline" size={22} color={colors.onSurface} />
        </Pressable>
        <View testID="network-status" style={[styles.netPill, { borderColor: online ? colors.success : colors.warning }]}>
          <View style={[styles.netDot, { backgroundColor: online ? colors.success : colors.warning }]} />
          <Text style={styles.netText}>{online ? "ONLINE" : "OFFLINE"}</Text>
        </View>
      </View>
      {showPw && joinPw && (
        <View testID="session-password-bar" style={styles.pwBar}>
          <Ionicons name="key-outline" size={16} color={colors.onSurface} />
          <Text style={styles.pwLabel}>WACHTWOORD OM TE JOINEN</Text>
          <Text testID="session-password" style={styles.pwValue} selectable>
            {joinPw}
          </Text>
          <Pressable testID="rotate-password-button" onPress={onRotate} style={styles.rotateBtn} hitSlop={6}>
            <Ionicons name="refresh" size={18} color={colors.onSurface} />
          </Pressable>
        </View>
      )}

      <ScrollView contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + spacing.lg }]} bounces={false}>
        <View style={styles.visual}>
          <View style={styles.visualLogo}>
            <LogoMark size={28} />
          </View>
          <View testID="loop-indicator" style={styles.loopTag}>
            <Ionicons name="repeat" size={14} color={colors.accent} />
            <Text style={styles.loopTagText}>LOOP · 5s STILTE</Text>
          </View>
          {!status.isLoaded ? <ActivityIndicator color={colors.onSurface} /> : <Bars active={status.playing} />}
        </View>

        <Text testID="sync-status-label" style={[styles.syncLabel, { color: syncColor }]}>
          {syncLabel}
        </Text>

        <View style={styles.metrics}>
          <Metric testID="metric-offset" label="UTC OFFSET" value={`${clock.offsetMs >= 0 ? "+" : ""}${clock.offsetMs}`} unit="ms" />
          <Metric testID="metric-drift" label="DRIFT" value={`${driftMs >= 0 ? "+" : ""}${phase === "play" ? driftMs : 0}`} unit="ms" />
          <Metric testID="metric-rate" label="TEMPO" value={`${(rate * 100).toFixed(1)}`} unit="%" />
        </View>
        <Text testID="metric-rtt" style={styles.rtt}>
          RTT {clock.rttMs} ms · {clock.online ? "UTC-klok gesynchroniseerd" : "laatst bekende offset"}
          {!autoSync ? " · auto-sync uit" : " · continue sync"}
        </Text>

        <Pressable
          testID="auto-sync-button"
          onPress={() => {
            Haptics.selectionAsync();
            toggleAutoSync();
            toast.show(autoSync ? "Auto-sync uit op dit toestel" : "Auto-sync aan op dit toestel", autoSync ? "info" : "success");
          }}
          style={({ pressed }) => [styles.syncToggle, autoSync && styles.syncToggleOn, pressed && styles.pressed]}
        >
          <Ionicons name={autoSync ? "sync" : "sync-outline"} size={20} color={autoSync ? colors.onSuccess : colors.onSurface} />
          <Text style={[styles.syncToggleLabel, autoSync && { color: colors.onSuccess }]}>
            {autoSync ? "AUTO-SYNC AAN" : "AUTO-SYNC UIT"}
          </Text>
          <View style={[styles.switchTrack, autoSync && styles.switchTrackOn]}>
            <View style={[styles.switchKnob, autoSync && styles.switchKnobOn]} />
          </View>
        </Pressable>

        <Pressable
          testID="sync-now-button"
          onPress={async () => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
            setSyncingNow(true);
            await syncNow();
            setSyncingNow(false);
            toast.show("Gesynchroniseerd met de beheerder", "success");
          }}
          disabled={syncingNow}
          style={({ pressed }) => [styles.syncNowBtn, (pressed || syncingNow) && styles.pressed]}
        >
          {syncingNow ? (
            <ActivityIndicator color={colors.onAccent} />
          ) : (
            <Ionicons name="flash" size={18} color={colors.onAccent} />
          )}
          <Text style={styles.syncNowLabel}>SYNC-NOW</Text>
        </Pressable>

        <View style={styles.progressWrap}>
          <View style={styles.track}>
            <View testID="player-progress-bar" style={[styles.fill, { width: `${progress * 100}%` }]} />
          </View>
          <View style={styles.times}>
            <Text testID="player-position" style={styles.time}>
              {fmt(pos)}
            </Text>
            <Text style={styles.time}>{fmt(dur)}</Text>
          </View>
        </View>

        {canControl ? (
          <>
            <View style={styles.controls}>
              <Pressable
                testID="start-button"
                onPress={onStart}
                disabled={busy !== null || !status.isLoaded}
                style={({ pressed }) => [styles.startBtn, (pressed || busy === "start") && styles.pressed, !status.isLoaded && { opacity: 0.4 }]}
              >
                {busy === "start" ? (
                  <ActivityIndicator color={colors.onAccent} />
                ) : (
                  <Ionicons name="play" size={30} color={colors.onAccent} />
                )}
                <Text style={styles.startLabel}>{state?.status === "paused" ? "HERVAT" : "START"}</Text>
              </Pressable>
              <Pressable
                testID="pause-button"
                onPress={onPause}
                disabled={busy !== null || !isPlaying}
                style={({ pressed }) => [styles.stopBtn, (pressed || busy === "pause") && styles.pressed, !isPlaying && { opacity: 0.4 }]}
              >
                <Ionicons name="pause" size={26} color={colors.onSurface} />
                <Text style={styles.stopLabel}>PAUZE</Text>
              </Pressable>
              <Pressable
                testID="stop-button"
                onPress={onStop}
                disabled={busy !== null}
                style={({ pressed }) => [styles.stopBtn, (pressed || busy === "stop") && styles.pressed]}
              >
                <Ionicons name="stop" size={26} color={colors.onSurface} />
                <Text style={styles.stopLabel}>STOP</Text>
              </Pressable>
            </View>
            <View testID="volume-panel" style={styles.volPanel}>
              <View style={styles.volHead}>
                <Text style={styles.volLabel}>VOLUME ALLE TOESTELLEN</Text>
                <Text testID="volume-value" style={styles.volValue}>
                  {volPct}%
                </Text>
              </View>
              <View style={styles.volRow}>
                <Pressable testID="volume-down-button" onPress={() => onVolume(volume - 0.1)} style={styles.volBtn} hitSlop={6}>
                  <Ionicons name="volume-low" size={20} color={colors.onSurface} />
                </Pressable>
                <View style={styles.volBar}>
                  {Array.from({ length: 10 }).map((_, i) => (
                    <Pressable
                      key={i}
                      testID={`volume-seg-${i + 1}`}
                      onPress={() => onVolume((i + 1) / 10)}
                      style={[styles.volSeg, i < Math.round(volume * 10) && styles.volSegOn]}
                    />
                  ))}
                </View>
                <Pressable testID="volume-up-button" onPress={() => onVolume(volume + 0.1)} style={styles.volBtn} hitSlop={6}>
                  <Ionicons name="volume-high" size={20} color={colors.onSurface} />
                </Pressable>
              </View>
            </View>
          </>
        ) : (
          <View testID="listener-panel" style={styles.listener}>
            <Ionicons name="radio-outline" size={28} color={colors.onSurface} />
            <View style={{ flex: 1 }}>
              <Text style={styles.listenerTitle}>LUISTERAAR</Text>
              <Text testID="controller-name" style={styles.listenerText}>
                Beheer bij: {state?.controller_name ?? "de uploader"}. Dit toestel volgt automatisch op UTC-tijd.
              </Text>
              <Text testID="listener-volume" style={styles.listenerText}>
                Volume (door beheerder): {volPct}%
              </Text>
              {isOwner && (
                <Pressable
                  testID="reclaim-control-button"
                  onPress={() => myDeviceId && transfer(myDeviceId, deviceLabel(user?.name, user?.is_guest))}
                  disabled={busy !== null}
                  style={({ pressed }) => [styles.reclaimBtn, pressed && styles.pressed]}
                >
                  <Text style={styles.reclaimText}>Beheer terugnemen</Text>
                </Pressable>
              )}
            </View>
          </View>
        )}

        {kind === "playlists" && (
          <QueuePanel
            tracks={tracks}
            current={currentTrack}
            canControl={canControl || isOwner}
            busy={busy !== null}
            onSkip={onSkip}
            onAdd={onAddSong}
            onReorder={onReorder}
          />
        )}

        {(canControl || isOwner) && (
          <ListenersPanel
            listeners={listeners}
            myDeviceId={myDeviceId}
            canTransfer={canControl || isOwner}
            busyDevice={busyDevice}
            onTransfer={(l) => transfer(l.device_id, l.name)}
            onKick={onKick}
          />
        )}

        <Text style={styles.hint}>
          {canControl
            ? "Jij hebt het beheer — alle toestellen met dit ID volgen jouw Start, Pauze en Stop op UTC-tijd."
            : "Wacht op de beheerder…"}
          {Platform.OS === "web" ? " (Web: streamen, geen offline opslag)" : ""}
        </Text>
      </ScrollView>
      <QrSheet visible={qrOpen} songId={sessionId} title={title} onClose={() => setQrOpen(false)} />
    </View>
  );
}

function Metric({ label, value, unit, testID }: { label: string; value: string; unit: string; testID: string }) {
  const styles = useStyles();
  return (
    <View style={styles.metric}>
      <Text style={styles.metricLabel}>{label}</Text>
      <Text testID={testID} style={styles.metricValue} numberOfLines={1} adjustsFontSizeToFit>
        {value}
        <Text style={styles.metricUnit}> {unit}</Text>
      </Text>
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  center: { alignItems: "center", justifyContent: "center", paddingHorizontal: spacing.xl },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    paddingHorizontal: spacing.sm,
    paddingBottom: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: c.divider,
  },
  iconBtn: { width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  title: { color: c.onSurface, fontFamily: fonts.textSemi, fontSize: 17 },
  metaText: { color: c.muted, fontFamily: fonts.displaySemi, fontSize: 13, letterSpacing: 1 },
  netPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.xs,
    borderWidth: 1,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.sm,
    height: 28,
    marginRight: spacing.sm,
  },
  netDot: { width: 6, height: 6, borderRadius: 3 },
  netText: { color: c.onSurface, fontFamily: fonts.displaySemi, fontSize: 12, letterSpacing: 1 },
  content: { paddingHorizontal: spacing.lg, paddingTop: spacing.lg },
  visual: {
    height: 160,
    borderRadius: radius.lg,
    backgroundColor: c.surfaceSecondary,
    borderWidth: 1,
    borderColor: c.border,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
  },
  visualLogo: { position: "absolute", top: spacing.md, left: spacing.md, opacity: 0.9 },
  listener: {
    marginTop: spacing.xl,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    padding: spacing.lg,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: c.borderStrong,
    backgroundColor: c.surfaceSecondary,
  },
  listenerTitle: { color: c.onSurface, fontFamily: fonts.display, fontSize: 18, letterSpacing: 2 },
  listenerText: { color: c.muted, fontFamily: fonts.text, fontSize: 13 },
  reclaimBtn: {
    marginTop: spacing.sm,
    alignSelf: "flex-start",
    height: 36,
    paddingHorizontal: spacing.md,
    borderRadius: radius.pill,
    backgroundColor: c.accent,
    justifyContent: "center",
  },
  reclaimText: { color: c.onAccent, fontFamily: fonts.textSemi, fontSize: 13 },
  pwBar: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    height: 40,
    backgroundColor: c.surfaceSecondary,
    borderBottomWidth: 1,
    borderBottomColor: c.divider,
  },
  pwLabel: { flex: 1, color: c.muted, fontFamily: fonts.displaySemi, fontSize: 12, letterSpacing: 1.5 },
  rotateBtn: { width: 36, height: 36, alignItems: "center", justifyContent: "center" },
  pwValue: { color: c.accent, fontFamily: fonts.display, fontSize: 20, letterSpacing: 4 },
  loopTag: {
    position: "absolute",
    top: spacing.md,
    right: spacing.md,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.xs,
    borderWidth: 1,
    borderColor: c.borderStrong,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.sm,
    height: 24,
  },
  loopTagText: { color: c.onSurface, fontFamily: fonts.displaySemi, fontSize: 11, letterSpacing: 1 },
  syncNowBtn: {
    marginTop: spacing.sm,
    height: 48,
    borderRadius: radius.md,
    backgroundColor: c.accent,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
  },
  syncNowLabel: { color: c.onAccent, fontFamily: fonts.displaySemi, fontSize: 16, letterSpacing: 2 },
  volPanel: {
    marginTop: spacing.md,
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: c.border,
    backgroundColor: c.surfaceSecondary,
    gap: spacing.sm,
  },
  volHead: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  volLabel: { color: c.muted, fontFamily: fonts.displaySemi, fontSize: 12, letterSpacing: 1.5 },
  volValue: { color: c.accent, fontFamily: fonts.display, fontSize: 20 },
  volRow: { flexDirection: "row", alignItems: "center", gap: spacing.sm },
  volBtn: { width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  volBar: { flex: 1, flexDirection: "row", gap: 4, height: 32, alignItems: "stretch" },
  volSeg: { flex: 1, borderRadius: 3, backgroundColor: c.brandSecondary },
  volSegOn: { backgroundColor: c.accent },
  syncToggle: {
    marginTop: spacing.md,
    height: 48,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: c.borderStrong,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: spacing.lg,
    gap: spacing.sm,
  },
  syncToggleOn: { backgroundColor: c.success, borderColor: c.success },
  syncToggleLabel: { flex: 1, color: c.onSurface, fontFamily: fonts.displaySemi, fontSize: 15, letterSpacing: 1 },
  switchTrack: { width: 40, height: 22, borderRadius: 11, backgroundColor: c.brandSecondary, padding: 2, justifyContent: "center" },
  switchTrackOn: { backgroundColor: c.onSuccess },
  switchKnob: { width: 18, height: 18, borderRadius: 9, backgroundColor: c.onSurface },
  switchKnobOn: { alignSelf: "flex-end", backgroundColor: c.success },
  bars: { flexDirection: "row", alignItems: "center", height: "80%", gap: 4 },
  bar: { width: 6, borderRadius: 3, backgroundColor: c.onSurface },
  syncLabel: { fontFamily: fonts.display, fontSize: 34, letterSpacing: 3, marginTop: spacing.lg },
  metrics: { flexDirection: "row", marginTop: spacing.sm, borderTopWidth: 1, borderBottomWidth: 1, borderColor: c.divider },
  metric: { flex: 1, paddingVertical: spacing.md, gap: 2 },
  metricLabel: { color: c.muted, fontFamily: fonts.displaySemi, fontSize: 12, letterSpacing: 1.5 },
  metricValue: { color: c.onSurface, fontFamily: fonts.display, fontSize: 30 },
  metricUnit: { color: c.muted, fontFamily: fonts.displayMedium, fontSize: 14 },
  rtt: { color: c.muted, fontFamily: fonts.text, fontSize: 12, marginTop: spacing.sm },
  progressWrap: { marginTop: spacing.xl },
  track: { height: 4, borderRadius: 2, backgroundColor: c.brandSecondary, overflow: "hidden" },
  fill: { height: 4, backgroundColor: c.accent },
  times: { flexDirection: "row", justifyContent: "space-between", marginTop: spacing.xs },
  time: { color: c.onSurface, fontFamily: fonts.displayMedium, fontSize: 15 },
  controls: { flexDirection: "row", gap: spacing.md, marginTop: spacing.xl },
  startBtn: {
    flex: 1.5,
    height: 110,
    borderRadius: radius.lg,
    backgroundColor: c.accent,
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.xs,
  },
  startLabel: { color: c.onAccent, fontFamily: fonts.display, fontSize: 24, letterSpacing: 3 },
  stopBtn: {
    flex: 1,
    height: 110,
    borderRadius: radius.lg,
    backgroundColor: c.surface,
    borderWidth: 2,
    borderColor: c.onSurface,
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.xs,
  },
  stopLabel: { color: c.onSurface, fontFamily: fonts.display, fontSize: 17, letterSpacing: 1.5 },
  hint: { color: c.muted, fontFamily: fonts.text, fontSize: 12, marginTop: spacing.lg, textAlign: "center" },
  pressed: { opacity: 0.7, transform: [{ scale: 0.98 }] },
  errorPanel: {
    width: "100%",
    borderWidth: 1,
    borderColor: c.error,
    borderRadius: radius.md,
    padding: spacing.xl,
    gap: spacing.sm,
    alignItems: "center",
  },
  errorTitle: { color: c.error, fontFamily: fonts.display, fontSize: 24 },
  errorText: { color: c.onSurface, fontFamily: fonts.text, fontSize: 14, textAlign: "center" },
  retryBtn: {
    marginTop: spacing.sm,
    height: 48,
    paddingHorizontal: spacing.xl,
    borderRadius: radius.md,
    backgroundColor: c.brandPrimary,
    justifyContent: "center",
  },
  retryLabel: { color: c.onBrandPrimary, fontFamily: fonts.textSemi, fontSize: 15 },
  retryGhost: { height: 44, justifyContent: "center" },
}));
