import { AudioPlayer, setAudioModeAsync, useAudioPlayer } from "expo-audio";
import { useCallback, useEffect, useRef, useState } from "react";
import { AppState, Platform } from "react-native";

import { apiFetch } from "@/src/api";
import { useAuth } from "@/src/auth";
import { getClockInfo, loadCachedOffset, syncClock, utcNow } from "@/src/clock";
import { deviceLabel, getDeviceIdSync } from "@/src/device";
import { audioSourceFor, cacheState, getCachedState, LibrarySong, Listener, SongState } from "@/src/library";
import { Phase, timeline } from "@/src/timeline";
import { storage } from "@/src/utils/storage";

const AUTO_SYNC_KEY = "jynque_auto_sync";

// Sync tuning: continuous for the whole song (when auto-sync is on). The tempo follows the
// drift proportionally every second and never interrupts the audio.
const DRIFT_CHECK_MS = 1000;
const CLOCK_SYNC_MS = 30000;
const FIRST_CHECK_MS = 5000; // first check shortly after (re)start to absorb start-up latency
const DEADBAND_S = 0.02; // ≤20 ms counts as in sync
const MAX_DEV = 0.04; // max ±4% tempo change
const RESPONSE_S = 2; // tempo deviation = drift / 2 s (e.g. 40 ms drift → 2%)
const HARD_SEEK_S = 3; // only after a long offline period
const PRESENCE_MS = 1500;
const FADE_MS = 1200; // fade-out for pause / stop / skip
const FADE_IN_MS = 1500;
const END_FADE_S = 1.5;
// iOS: changing AVPlayerItem.audioTimePitchAlgorithm while playing rebuilds the audio pipeline
// (audible hiccup). Use timeDomain ("medium") and set it while paused, so corrections only change the rate.
const PITCH_QUALITY = Platform.OS === "ios" ? "medium" : "high";

type PresenceResponse = SongState & { listeners: Listener[] };

export function useSyncEngine(player: AudioPlayer, kind: string, songId: string, tracks: LibrarySong[]) {
  const tracksRef = useRef(tracks);
  tracksRef.current = tracks;
  const loadedSongId = useRef(tracks[0]?.song_id);
  const currentTrackRef = useRef(0);
  const switchingUntil = useRef(0);
  const [currentTrack, setCurrentTrack] = useState(0);
  // Fader: gain (0..1) multiplies the remote volume
  const gain = useRef(1);
  const fade = useRef<{ from: number; to: number; start: number; dur: number; done?: () => void } | null>(null);
  const fadingOut = useRef(false);
  const endFaded = useRef(false);
  const { user } = useAuth();
  const [state, setState] = useState<SongState | null>(null);
  const stateRef = useRef<SongState | null>(null);
  const [listeners, setListeners] = useState<Listener[]>([]);
  const [online, setOnline] = useState(true);
  const [removed, setRemoved] = useState(false);
  const [clock, setClock] = useState(getClockInfo());
  const [drift, setDrift] = useState(0);
  const driftRef = useRef(0);
  const [rate, setRate] = useState(1);
  const rateRef = useRef(1);
  const [phase, setPhase] = useState<Phase>("stopped");
  // Keep-alive: a silent looping player keeps the app awake on a locked screen during
  // countdowns, loop gaps, gaps between songs and pauses, so restarts stay in sync.
  const keepAlive = useAudioPlayer(require("../assets/audio/silence.wav"));
  const sessionActive = phase !== "stopped" && phase !== "ended";
  useEffect(() => {
    if (Platform.OS === "web") return;
    try {
      keepAlive.loop = true;
      keepAlive.volume = 0;
      if (sessionActive) keepAlive.play();
      else keepAlive.pause();
    } catch {}
  }, [sessionActive, keepAlive]);
  const phaseRef = useRef<Phase>("stopped");
  const [wait, setWait] = useState(0);

  const seeking = useRef(false);
  const primedSong = useRef<string | null>(null);
  const parkedKey = useRef<string | null>(null);
  const startTimer = useRef<{ key: string; t: ReturnType<typeof setTimeout> } | null>(null);
  const playStartedAt = useRef(0);
  const lastCheck = useRef(0);
  const forceSync = useRef(false);
  // Per-device switch: automatic drift correction on/off (persisted)
  const [autoSync, setAutoSync] = useState(true);
  const autoSyncRef = useRef(true);

  useEffect(() => {
    storage.getItem(AUTO_SYNC_KEY, true).then((v) => {
      const on = v !== false;
      autoSyncRef.current = on;
      setAutoSync(on);
    });
  }, []);

  // Remote volume (set by the controller for all devices)
  const [volume, setVolume] = useState(1);
  const volumeRef = useRef(1);
  const localVolumeAt = useRef(0);

  const applyVolume = useCallback(
    (v: number) => {
      if (volumeRef.current === v) return;
      volumeRef.current = v;
      setVolume(v);
      try {
        player.volume = v * gain.current;
      } catch {}
    },
    [player],
  );

  /** Controller: change volume immediately on this device (server broadcast is done by the caller). */
  const setVolumeLocal = useCallback(
    (v: number) => {
      localVolumeAt.current = Date.now();
      applyVolume(v);
    },
    [applyVolume],
  );

  const applyState = useCallback(
    (s: SongState) => {
      stateRef.current = s;
      setState(s);
      cacheState(s);
      if (typeof s.volume === "number" && Date.now() - localVolumeAt.current > 3000) applyVolume(s.volume);
    },
    [applyVolume],
  );

  const setTempo = useCallback(
    (r: number) => {
      if (rateRef.current === r) return;
      rateRef.current = r;
      try {
        player.setPlaybackRate(r, PITCH_QUALITY);
      } catch {}
      setRate(r);
    },
    [player],
  );

  const toggleAutoSync = useCallback(() => {
    const on = !autoSyncRef.current;
    autoSyncRef.current = on;
    setAutoSync(on);
    storage.setItem(AUTO_SYNC_KEY, on);
    // Turning OFF: back to exactly 100% and free-run (no seek). Turning ON: follow the drift again.
    if (on) lastCheck.current = Date.now();
    else setTempo(1);
  }, [setTempo]);

  /** SYNC-NOW: refresh the UTC clock, then jump once to the controller's exact position. */
  const syncNow = useCallback(async () => {
    const c = await syncClock();
    setClock({ ...c });
    forceSync.current = true;
  }, []);

  // Audio mode + offline cache
  useEffect(() => {
    setAudioModeAsync({ playsInSilentMode: true, shouldPlayInBackground: true, interruptionMode: "doNotMix" }).catch(() => {});
    loadCachedOffset().then((c) => setClock({ ...c }));
    getCachedState(songId).then((s) => {
      if (s && !stateRef.current) applyState(s);
    });
    try {
      player.shouldCorrectPitch = true;
    } catch {}
  }, [songId, player, applyState]);

  // UTC clock sync: every 30 s and on foreground
  useEffect(() => {
    let alive = true;
    const run = async () => {
      const c = await syncClock();
      if (alive) setClock({ ...c });
    };
    run();
    const t = setInterval(run, CLOCK_SYNC_MS);
    const sub = AppState.addEventListener("change", (s) => s === "active" && run());
    return () => {
      alive = false;
      clearInterval(t);
      sub.remove();
    };
  }, []);

  // Presence heartbeat: reports this device, returns shared state + listeners
  useEffect(() => {
    let alive = true;
    const beat = async () => {
      try {
        const r = await apiFetch<PresenceResponse>(
          `/${kind}/${songId}/presence`,
          {
            method: "POST",
            body: JSON.stringify({
              device_id: getDeviceIdSync(),
              name: deviceLabel(user?.name, user?.is_guest),
              drift_ms: Math.round(driftRef.current * 1000),
              in_sync: phaseRef.current !== "play" || Math.abs(driftRef.current) <= 0.05,
              playing: phaseRef.current === "play",
            }),
          },
          4000,
        );
        if (!alive) return;
        setOnline(true);
        setListeners(r.listeners ?? []);
        if (typeof r.volume === "number" && Date.now() - localVolumeAt.current > 3000) applyVolume(r.volume);
        const { listeners: _l, ...s } = r;
        if (!stateRef.current || s.version !== stateRef.current.version) applyState(s);
      } catch (e: any) {
        if (!alive) return;
        if (e?.message === "WACHTWOORD_VEREIST") {
          // Removed from the session by the controller
          setRemoved(true);
          try {
            player.pause();
          } catch {}
        } else setOnline(false);
      }
    };
    beat();
    const t = setInterval(beat, PRESENCE_MS);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [kind, songId, applyState, applyVolume, user?.name, user?.is_guest, player]);

  // Sync engine
  useEffect(() => {
    const clearTimer = () => {
      if (startTimer.current) {
        clearTimeout(startTimer.current.t);
        startTimer.current = null;
      }
    };
    const applyGain = (g: number) => {
      gain.current = g;
      try {
        player.volume = volumeRef.current * g;
      } catch {}
    };
    const startFade = (to: number, ms: number, done?: () => void) => {
      fade.current = { from: gain.current, to, start: Date.now(), dur: Math.max(1, ms), done };
    };
    const playWithFade = () => {
      fade.current = null;
      applyGain(0);
      player.play();
      startFade(1, FADE_IN_MS);
    };
    const fader = setInterval(() => {
      const f = fade.current;
      if (!f) return;
      const p = Math.min(1, (Date.now() - f.start) / f.dur);
      applyGain(f.from + (f.to - f.from) * p * p * (3 - 2 * p));
      if (p >= 1) {
        fade.current = null;
        f.done?.();
      }
    }, 40);
    const markStarted = () => {
      endFaded.current = false;
      playStartedAt.current = Date.now();
      lastCheck.current = Date.now() + FIRST_CHECK_MS - DRIFT_CHECK_MS;
      parkedKey.current = null;
    };

    const tick = async () => {
      if (!player.isLoaded || seeking.current) return;
      // Set the pitch algorithm once per loaded song while silent (never mid-play on iOS)
      if (!player.playing && primedSong.current !== loadedSongId.current) {
        primedSong.current = loadedSongId.current ?? null;
        try {
          player.setPlaybackRate(rateRef.current, PITCH_QUALITY);
        } catch {}
      }
      const s = stateRef.current;
      const now = utcNow();
      const tl = timeline(s, now, player.duration || 0);
      if (phaseRef.current !== tl.mode) {
        phaseRef.current = tl.mode;
        setPhase(tl.mode);
      }
      setWait(tl.wait);
      const key = `${s?.version ?? -1}-${tl.mode}-${tl.cycle}-${tl.track}`;

      // Queue changed on the server but not reloaded here yet: leave the audio untouched
      if (s?.items && s.items.join(",") !== tracksRef.current.map((x) => x.song_id).join(",")) return;
      const want = tracksRef.current[tl.track];
      if (want && want.song_id === loadedSongId.current && currentTrackRef.current !== tl.track) {
        currentTrackRef.current = tl.track; // same song moved in the queue: no reload, no interruption
        setCurrentTrack(tl.track);
      }
      // Playlist: load the right track (between songs, after the fade-out)
      if (want && want.song_id !== loadedSongId.current && !fadingOut.current && !(player.playing && tl.mode !== "play")) {
        const next = want;
        if (next) {
          loadedSongId.current = next.song_id;
          currentTrackRef.current = tl.track;
          setCurrentTrack(tl.track);
          player.replace(audioSourceFor(next));
          parkedKey.current = null;
          switchingUntil.current = Date.now() + 700;
          return;
        }
      }
      if (Date.now() < switchingUntil.current) return;

      if (tl.mode !== "play") {
        if (rateRef.current !== 1) setTempo(1);
        driftRef.current = 0;
        setDrift(0);
        if (startTimer.current && startTimer.current.key !== key) clearTimer();
        if (player.playing || fadingOut.current) {
          // Fade out softly (synchronised via fade_end_ms), then pause and park
          if (!fadingOut.current) {
            fadingOut.current = true;
            const left = s?.fade_end_ms ? s.fade_end_ms - utcNow() : 600;
            const ms = tl.mode === "gap" || tl.mode === "ended" ? 300 : Math.min(FADE_MS, Math.max(250, left));
            startFade(0, ms, () => {
              player.pause();
              fadingOut.current = false;
              parkedKey.current = null;
            });
          }
          return;
        }
        if (parkedKey.current !== key) {
          parkedKey.current = key;
          seeking.current = true;
          await player.seekTo(tl.pos).catch(() => {});
          seeking.current = false;
        }
        // Precise scheduled (re)start for countdown and loop gap
        if ((tl.mode === "countdown" || tl.mode === "gap") && tl.wait <= 1.2 && !startTimer.current) {
          const startKey = key;
          startTimer.current = {
            key,
            t: setTimeout(() => {
              startTimer.current = null;
              if (parkedKey.current !== startKey) return;
              playWithFade();
              markStarted();
            }, Math.max(0, tl.wait * 1000)),
          };
        }
        return;
      }

      const dur = player.duration || 0;
      if (!player.playing) {
        if (Date.now() - playStartedAt.current < 1500) return; // just started
        if (dur && tl.pos > dur - 0.4) return; // finishing naturally
        if (!autoSyncRef.current) {
          // Auto-sync off: continue from where this device is, never jump.
          playWithFade();
          playStartedAt.current = Date.now();
          return;
        }
        // Joining mid-song (late device / after reconnect)
        seeking.current = true;
        await player.seekTo(timeline(s, utcNow(), dur).pos + 0.05).catch(() => {});
        seeking.current = false;
        playWithFade();
        markStarted();
        return;
      }

      const d = player.currentTime - tl.pos; // positive = ahead
      driftRef.current = d;
      // Soft fade-out at the end of each song
      if (dur && dur - tl.pos < END_FADE_S && !endFaded.current && !fade.current) {
        endFaded.current = true;
        startFade(0, Math.max(200, (dur - tl.pos) * 1000));
      }
      setDrift(d);
      const local = Date.now();
      if (!autoSyncRef.current && !forceSync.current) return; // free-running: no corrections
      if (forceSync.current || Math.abs(d) > HARD_SEEK_S) {
        // SYNC-NOW (manual, also with auto-sync off) or long offline period: jump to the controller's position
        forceSync.current = false;
        seeking.current = true;
        await player.seekTo(timeline(s, utcNow(), dur).pos).catch(() => {});
        seeking.current = false;
        setTempo(1);
        markStarted();
        return;
      }
      // Continuous for the whole song: every second the tempo follows the drift
      // proportionally (no fixed catch-up window), back to exactly 100% inside the deadband.
      if (local - lastCheck.current >= DRIFT_CHECK_MS) {
        lastCheck.current = local;
        const dev = Math.abs(d) <= DEADBAND_S ? 0 : Math.min(MAX_DEV, Math.abs(d) / RESPONSE_S);
        setTempo(Math.round((d > 0 ? 1 - dev : 1 + dev) * 1000) / 1000);
      }
    };
    const t = setInterval(tick, 250);
    return () => {
      clearInterval(t);
      clearInterval(fader);
      clearTimer();
    };
  }, [player, setTempo]);

  return {
    state,
    stateRef,
    applyState,
    listeners,
    online,
    clock,
    drift,
    rate,
    phase,
    wait,
    autoSync,
    toggleAutoSync,
    volume,
    setVolumeLocal,
    syncNow,
    currentTrack,
    removed,
  };
}
