export const BASE_URL = process.env.EXPO_PUBLIC_BACKEND_URL as string;
export const API = `${BASE_URL}/api`;

let sessionToken: string | null = null;
let deviceId: string | null = null;
let onUnauthorized: (() => void) | null = null;

export function setApiDeviceId(id: string) {
  deviceId = id;
}

export function setApiToken(t: string | null) {
  sessionToken = t;
}
export function getApiToken() {
  return sessionToken;
}
export function setUnauthorizedHandler(fn: (() => void) | null) {
  onUnauthorized = fn;
}

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export async function apiFetch<T = any>(path: string, init: RequestInit = {}, timeoutMs = 15000): Promise<T> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  const headers: Record<string, string> = { ...(init.headers as Record<string, string>) };
  if (sessionToken) headers.Authorization = `Bearer ${sessionToken}`;
  if (deviceId) headers["X-Device-Id"] = deviceId;
  if (init.body && !(init.body instanceof FormData) && !headers["Content-Type"]) {
    headers["Content-Type"] = "application/json";
  }
  try {
    const res = await fetch(`${API}${path}`, { ...init, headers, signal: ctrl.signal });
    if (res.status === 401) onUnauthorized?.();
    if (!res.ok) {
      let msg = `Fout ${res.status}`;
      try {
        const j = await res.json();
        if (j?.detail) msg = typeof j.detail === "string" ? j.detail : msg;
      } catch {}
      throw new ApiError(res.status, msg);
    }
    return (await res.json()) as T;
  } finally {
    clearTimeout(timer);
  }
}

// Short-lived, per-file signed stream links (web). The session token is never put in a URL.
const links = new Map<string, { url: string; exp: number }>();

export async function prepareStreamLinks(songIds: string[]) {
  const now = Date.now();
  await Promise.all(
    songIds
      .filter((id) => (links.get(id)?.exp ?? 0) - now < 5 * 60 * 1000)
      .map(async (id) => {
        try {
          const r = await apiFetch<{ path: string; expires_at_ms: number }>(`/songs/${id}/file-link`, { method: "POST" });
          links.set(id, { url: `${BASE_URL}${r.path}`, exp: r.expires_at_ms });
        } catch {}
      }),
  );
}

export function streamUrl(songId: string) {
  return links.get(songId)?.url ?? "";
}
