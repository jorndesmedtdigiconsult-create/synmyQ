// Offline mode: no server at all. The QR code carries the song check (title + size) and the
// UTC start time; every phone plays its own local copy on its own (network-synced) clock.
import * as DocumentPicker from "expo-document-picker";
import { Directory, File, Paths } from "expo-file-system";
import { Platform } from "react-native";

import { storage } from "@/src/utils/storage";

export const OFFLINE_PREFIX = "syncmyque-off:";
const SESSION_KEY = "syncmyque_offline_session";

export type OfflineCode = { title: string; size: number; at: number; host?: string; port?: number };
export type OfflineSession = OfflineCode & { uri: string; role: "admin" | "listener" };

export function encodeOffline(c: OfflineCode) {
  const o: Record<string, unknown> = { v: 1, t: c.title, s: c.size, at: c.at };
  if (c.host && c.port) Object.assign(o, { h: c.host, p: c.port });
  return OFFLINE_PREFIX + encodeURIComponent(JSON.stringify(o));
}

export function decodeOffline(raw: string): OfflineCode | null {
  const v = raw.trim();
  if (!v.toLowerCase().startsWith(OFFLINE_PREFIX)) return null;
  try {
    const o = JSON.parse(decodeURIComponent(v.slice(OFFLINE_PREFIX.length)));
    if (typeof o?.at !== "number" || typeof o?.t !== "string") return null;
    const wifi = typeof o.h === "string" && typeof o.p === "number" ? { host: o.h, port: o.p } : {};
    return { title: o.t, size: Number(o.s) || 0, at: o.at, ...wifi };
  } catch {
    return null;
  }
}

export async function saveOfflineSession(s: OfflineSession) {
  await storage.setItem(SESSION_KEY, JSON.stringify(s));
}

export async function getOfflineSession(): Promise<OfflineSession | null> {
  const raw = await storage.getItem(SESSION_KEY, null);
  if (typeof raw !== "string") return null;
  try {
    return JSON.parse(raw) as OfflineSession;
  } catch {
    return null;
  }
}

export async function clearOfflineSession() {
  await storage.removeItem(SESSION_KEY);
}

/** Lets the user pick an MP3 from the phone (or iCloud / Google Drive) and keeps a copy in the app. */
export async function pickLocalSong(): Promise<{ uri: string; title: string; size: number } | null> {
  const res = await DocumentPicker.getDocumentAsync({ type: ["audio/*"], copyToCacheDirectory: true });
  if (res.canceled || !res.assets?.length) return null;
  const a = res.assets[0];
  const title = a.name.replace(/\.[^.]+$/, "") || "Nummer";
  if (Platform.OS === "web") return { uri: a.uri, title, size: a.size ?? 0 };
  const dir = new Directory(Paths.document, "offline");
  if (!dir.exists) dir.create();
  const dest = new File(dir, a.name.replace(/[\\/]/g, "_"));
  if (dest.exists) dest.delete();
  new File(a.uri).copy(dest);
  return { uri: dest.uri, title, size: a.size ?? dest.size ?? 0 };
}

export function fmtClock(ms: number, utc = false) {
  const d = new Date(ms);
  const p = (n: number) => String(n).padStart(2, "0");
  return utc
    ? `${p(d.getUTCHours())}:${p(d.getUTCMinutes())}:${p(d.getUTCSeconds())}`
    : `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}
