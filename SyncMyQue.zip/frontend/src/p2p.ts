// Direct phone-to-phone control on the same Wi-Fi / hotspot, without any server or third party.
// The admin's phone runs a tiny TCP server; listeners connect with the address from the QR code.
// Protocol: newline-delimited JSON (hello / ping-pong clock sync / state broadcast / drift report).
// Needs a native build (react-native-tcp-socket); in Expo Go / web `p2pAvailable` is false.
import { useCallback, useEffect, useRef, useState } from "react";
import { NativeModules, Platform } from "react-native";

import type { SongState } from "@/src/library";

export const P2P_PORT = 47820;
export const p2pAvailable = Platform.OS !== "web" && !!NativeModules.TcpSockets;
// Lazy require: never touch the native module in Expo Go / web
// eslint-disable-next-line @typescript-eslint/no-require-imports
const tcp = () => require("react-native-tcp-socket").default;

export type Peer = { id: string; name: string; drift_ms: number; sizeOk: boolean };

function lineReader(onMsg: (m: any) => void) {
  let buf = "";
  return (data: any) => {
    buf += typeof data === "string" ? data : data.toString("utf8");
    let i;
    while ((i = buf.indexOf("\n")) >= 0) {
      const line = buf.slice(0, i);
      buf = buf.slice(i + 1);
      try {
        onMsg(JSON.parse(line));
      } catch {}
    }
  };
}

const send = (sock: any, m: object) => {
  try {
    sock.write(JSON.stringify(m) + "\n");
  } catch {}
};

/** Admin side: serve the shared state to every listener and answer clock pings. */
export function useP2PHost(enabled: boolean, state: SongState, size: number) {
  const [peers, setPeers] = useState<Peer[]>([]);
  const [error, setError] = useState<string | null>(null);
  const socks = useRef(new Map<string, any>());
  const stateRef = useRef(state);
  stateRef.current = state;

  useEffect(() => {
    if (!enabled || !p2pAvailable) return;
    const map = socks.current;
    let n = 0;
    const server = tcp().createServer((sock: any) => {
      const id = `p${++n}`;
      map.set(id, sock);
      sock.on(
        "data",
        lineReader((m) => {
          if (m.type === "ping") send(sock, { type: "pong", t0: m.t0, t1: Date.now() });
          else if (m.type === "hello") {
            const peer = { id, name: String(m.name || "Luisteraar").slice(0, 40), drift_ms: 0, sizeOk: !size || !m.size || m.size === size };
            setPeers((p) => [...p.filter((x) => x.id !== id), peer]);
            send(sock, { type: "state", state: stateRef.current });
          } else if (m.type === "report") {
            setPeers((p) => p.map((x) => (x.id === id ? { ...x, drift_ms: Number(m.drift_ms) || 0 } : x)));
          }
        }),
      );
      const drop = () => {
        map.delete(id);
        setPeers((p) => p.filter((x) => x.id !== id));
      };
      sock.on("close", drop);
      sock.on("error", drop);
    });
    server.on("error", (e: any) => setError(String(e?.message ?? e)));
    server.listen({ port: P2P_PORT, host: "0.0.0.0", reuseAddress: true });
    return () => {
      map.forEach((s) => {
        try {
          s.destroy();
        } catch {}
      });
      map.clear();
      try {
        server.close();
      } catch {}
    };
  }, [enabled, size]);

  // Broadcast every change (play / pause / stop) immediately
  useEffect(() => {
    socks.current.forEach((s) => send(s, { type: "state", state }));
  }, [state]);

  return { peers, error };
}

/** Listener side: follow the admin's state and clock (NTP-style, best round trip wins). */
export function useP2PClient(host: string | undefined, port: number | undefined, name: string, size: number) {
  const [connected, setConnected] = useState(false);
  const [state, setState] = useState<SongState | null>(null);
  const [offsetMs, setOffsetMs] = useState(0);
  const offset = useRef(0); // admin clock - my clock (ms)
  const samples = useRef<{ rtt: number; off: number }[]>([]);
  const sockRef = useRef<any>(null);

  const ping = useCallback(() => {
    if (sockRef.current) send(sockRef.current, { type: "ping", t0: Date.now() });
  }, []);

  /** Fresh burst of pings → new clock offset (used by SYNC-NOW). */
  const resync = useCallback(() => {
    samples.current = [];
    for (let i = 0; i < 5; i++) setTimeout(ping, i * 150);
  }, [ping]);

  const report = useCallback((drift_ms: number) => {
    if (sockRef.current) send(sockRef.current, { type: "report", drift_ms });
  }, []);

  useEffect(() => {
    if (!host || !port || !p2pAvailable) return;
    let alive = true;
    let retry: ReturnType<typeof setTimeout> | undefined;
    const connect = () => {
      const sock = tcp().createConnection({ host, port }, () => {
        sockRef.current = sock;
        setConnected(true);
        send(sock, { type: "hello", name, size });
        resync();
      });
      sock.on(
        "data",
        lineReader((m) => {
          if (m.type === "pong") {
            const t3 = Date.now();
            samples.current = [...samples.current, { rtt: t3 - m.t0, off: m.t1 - (m.t0 + t3) / 2 }].slice(-8);
            const best = samples.current.reduce((a, x) => (x.rtt < a.rtt ? x : a));
            offset.current = best.off;
            setOffsetMs(Math.round(best.off));
          } else if (m.type === "state" && m.state) setState(m.state);
        }),
      );
      sock.on("error", () => {
        try {
          sock.destroy();
        } catch {}
      });
      sock.on("close", () => {
        if (sockRef.current === sock) sockRef.current = null;
        setConnected(false);
        if (alive) {
          clearTimeout(retry);
          retry = setTimeout(connect, 3000);
        }
      });
    };
    connect();
    const t = setInterval(ping, 5000);
    return () => {
      alive = false;
      clearTimeout(retry);
      clearInterval(t);
      try {
        sockRef.current?.destroy();
      } catch {}
      sockRef.current = null;
    };
  }, [host, port, name, size, ping, resync]);

  return { connected, state, offset, offsetMs, resync, report };
}
