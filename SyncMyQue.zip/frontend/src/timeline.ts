import type { SongState } from "@/src/library";

/** 5 s silence before every (re)start of the song / queue (seconds). */
export const GAP_S = 5;

export type Phase = "stopped" | "paused" | "countdown" | "play" | "gap" | "ended";

/** 5 s silence before every next song of a playlist (seconds). */
export const TRACK_GAP_S = 5;

export type Timeline = {
  mode: Phase;
  /** Position (s) inside the current track. */
  pos: number;
  /** Seconds until playback (re)starts in countdown / gap. */
  wait: number;
  /** Loop repetition index. */
  cycle: number;
  /** Index of the track in the playlist (0 for a single song). */
  track: number;
};

/** Pure UTC timeline over one song or a whole playlist: every device computes the same result. */
export function timeline(s: SongState | null, nowMs: number, localDur: number): Timeline {
  const none: Timeline = { mode: "stopped", pos: 0, wait: 0, cycle: 0, track: 0 };
  if (!s || s.status === "stopped") return none;
  let durs = (s.durations_ms ?? []).map((d) => d / 1000);
  if (!durs.length && localDur) durs = [localDur];
  const known = durs.length > 0 && durs.every((d) => d > 0);
  const offsets: number[] = [];
  let total = 0;
  durs.forEach((d, i) => {
    offsets.push(total);
    total += d + (i < durs.length - 1 ? TRACK_GAP_S : 0);
  });
  const locate = (g: number) => {
    for (let i = 0; i < durs.length; i++) if (g < offsets[i] + durs[i]) return { track: i, pos: Math.max(0, g - offsets[i]) };
    return { track: 0, pos: 0 };
  };
  if (s.status === "paused") {
    let g = (s.paused_pos_ms ?? 0) / 1000;
    if (known && g >= total) g = 0;
    return { mode: "paused", wait: 0, cycle: 0, ...(known ? locate(g) : { track: 0, pos: g }) };
  }
  if (!s.start_at_ms) return none;
  const resumeAt = s.resume_at_ms ?? s.start_at_ms;
  if (nowMs < resumeAt) {
    const g = (resumeAt - s.start_at_ms) / 1000;
    return { mode: "countdown", wait: (resumeAt - nowMs) / 1000, cycle: 0, ...(known ? locate(g) : { track: 0, pos: g }) };
  }
  const elapsed = (nowMs - s.start_at_ms) / 1000;
  if (!known) return { mode: "play", pos: elapsed, wait: 0, cycle: 0, track: 0 };
  let g = elapsed;
  let cycle = 0;
  // Always loops, on every device, automatically
  const c = total + GAP_S;
  cycle = Math.floor(elapsed / c);
  g = elapsed - cycle * c;
  if (g >= total) return { mode: "gap", pos: 0, wait: c - g, cycle, track: 0 };
  for (let i = 0; i < durs.length; i++) {
    if (g < offsets[i]) return { mode: "gap", pos: 0, wait: offsets[i] - g, cycle, track: i };
    if (g < offsets[i] + durs[i]) return { mode: "play", pos: g - offsets[i], wait: 0, cycle, track: i };
  }
  return { ...none, mode: "ended" };
}
