import { Platform } from "react-native";
import { Directory, File, Paths } from "expo-file-system";

import { apiFetch, getApiToken, API, prepareStreamLinks, streamUrl } from "@/src/api";
import { storage } from "@/src/utils/storage";

const LIB_KEY = "jynque_library";

export type LibrarySong = {
  song_id: string;
  title: string;
  size: number;
  localUri: string | null; // null on web (streamed)
  cachedAt: number;
  isOwner?: boolean;
};

type SongMeta = { song_id: string; title: string; size: number; is_owner: boolean };

/** Refresh ownership info for a cached song (online only). */
export async function refreshSongMeta(songId: string): Promise<boolean | null> {
  try {
    const meta = await apiFetch<SongMeta>(`/songs/${songId}`, {}, 5000);
    const list = await getLibrary();
    const item = list.find((s) => s.song_id === songId);
    if (item && item.isOwner !== meta.is_owner) {
      item.isOwner = meta.is_owner;
      await saveLibrary(list);
    }
    return meta.is_owner;
  } catch {
    return null;
  }
}

export type SongState = {
  song_id: string;
  status: "playing" | "paused" | "stopped";
  start_at_ms: number | null;
  resume_at_ms?: number | null;
  paused_pos_ms?: number;
  loop?: boolean;
  duration_ms?: number | null;
  version: number;
  owner_id?: string;
  controller_device_id?: string | null;
  controller_name?: string | null;
  volume?: number;
  kind?: "songs" | "playlists";
  title?: string;
  durations_ms?: number[];
  items?: string[] | null;
  fade_end_ms?: number | null;
};

export type LocalPlaylist = { playlist_id: string; title: string; count: number };
const PL_KEY = "jynque_playlists";

export async function getPlaylists(): Promise<LocalPlaylist[]> {
  const raw = await storage.getItem(PL_KEY, "[]");
  try {
    return JSON.parse(String(raw)) as LocalPlaylist[];
  } catch {
    return [];
  }
}

export async function upsertPlaylist(p: LocalPlaylist) {
  const list = (await getPlaylists()).filter((x) => x.playlist_id !== p.playlist_id);
  await storage.setItem(PL_KEY, JSON.stringify([p, ...list]));
}

export async function removePlaylist(id: string) {
  await storage.setItem(PL_KEY, JSON.stringify((await getPlaylists()).filter((x) => x.playlist_id !== id)));
}

export type Listener = {
  device_id: string;
  name: string;
  drift_ms: number;
  in_sync: boolean;
  playing: boolean;
  is_controller: boolean;
};

export async function getLibrary(): Promise<LibrarySong[]> {
  const raw = await storage.getItem(LIB_KEY, "[]");
  try {
    return JSON.parse(String(raw)) as LibrarySong[];
  } catch {
    return [];
  }
}

async function saveLibrary(list: LibrarySong[]) {
  await storage.setItem(LIB_KEY, JSON.stringify(list));
}

/** Account deletion: forget the offline library, cached audio files and playlists on this device. */
export async function clearLocalLibrary() {
  if (Platform.OS !== "web") {
    for (const s of await getLibrary()) {
      try {
        if (s.localUri) new File(s.localUri).delete();
      } catch {}
    }
  }
  await storage.removeItem(LIB_KEY);
  await storage.removeItem(PL_KEY);
}

export async function upsertLibrary(song: LibrarySong) {
  const list = (await getLibrary()).filter((s) => s.song_id !== song.song_id);
  await saveLibrary([song, ...list]);
}

export async function removeFromLibrary(songId: string) {
  const list = await getLibrary();
  const item = list.find((s) => s.song_id === songId);
  if (item?.localUri && Platform.OS !== "web") {
    try {
      const f = new File(item.localUri);
      if (f.exists) f.delete();
    } catch {}
  }
  await saveLibrary(list.filter((s) => s.song_id !== songId));
}

export async function getLibrarySong(songId: string) {
  return (await getLibrary()).find((s) => s.song_id === songId) ?? null;
}

function localFile(songId: string) {
  return new File(Paths.document, `jynque_${songId}.mp3`);
}

/** Fetch song meta by ID and store the audio on the device for offline use. */
export async function fetchAndCacheSong(songIdRaw: string): Promise<LibrarySong> {
  const songId = songIdRaw.trim().toUpperCase();
  const meta = await apiFetch<SongMeta>(`/songs/${songId}`);
  let localUri: string | null = null;
  if (Platform.OS !== "web") {
    const dest = localFile(meta.song_id);
    if (!dest.exists) {
      const f = await File.downloadFileAsync(`${API}/songs/${meta.song_id}/file`, dest, {
        headers: { Authorization: `Bearer ${getApiToken()}` },
        idempotent: true,
      });
      localUri = f.uri;
    } else {
      localUri = dest.uri;
    }
  }
  const song: LibrarySong = { song_id: meta.song_id, title: meta.title, size: meta.size, localUri, cachedAt: Date.now(), isOwner: meta.is_owner };
  await upsertLibrary(song);
  return song;
}

/** Upload a picked MP3. Keeps a local copy so it is immediately available offline. */
export async function uploadSong(asset: { uri: string; name: string; mimeType?: string | null; file?: any }) {
  const form = new FormData();
  let tmpDir: Directory | null = null;
  if (Platform.OS === "web") {
    const blob = asset.file ?? (await (await fetch(asset.uri)).blob());
    form.append("file", blob, asset.name);
  } else {
    // Expo's WinterCG fetch only accepts Blob-like parts; expo-file-system's File implements that.
    // The picker's cache copy may have a random name, so copy it under the original filename (= song title).
    tmpDir = new Directory(Paths.cache, `upload_${Date.now()}`);
    tmpDir.create();
    const named = new File(tmpDir, asset.name.replace(/[\\/]/g, "_") || "nummer.mp3");
    new File(asset.uri).copy(named);
    form.append("file", named as any);
  }
  let meta: SongMeta;
  try {
    meta = await apiFetch<SongMeta>("/songs/upload", { method: "POST", body: form }, 180000);
  } finally {
    try {
      tmpDir?.delete();
    } catch {}
  }
  let localUri: string | null = null;
  if (Platform.OS !== "web") {
    try {
      const dest = localFile(meta.song_id);
      new File(asset.uri).copy(dest);
      localUri = dest.uri;
    } catch {
      localUri = null;
    }
  }
  const song: LibrarySong = { song_id: meta.song_id, title: meta.title, size: meta.size, localUri, cachedAt: Date.now(), isOwner: true };
  await upsertLibrary(song);
  return song;
}

export function audioSourceFor(song: LibrarySong) {
  if (song.localUri) return { uri: song.localUri };
  return { uri: streamUrl(song.song_id) };
}

/** Fetch signed stream links for tracks that are not stored on the device (web). */
export async function prepareTracks(tracks: LibrarySong[]) {
  await prepareStreamLinks(tracks.filter((t) => !t.localUri).map((t) => t.song_id));
}

const stateKey = (id: string) => `jynque_state_${id}`;

export async function getCachedState(songId: string): Promise<SongState | null> {
  const raw = await storage.getItem(stateKey(songId), null);
  if (!raw) return null;
  try {
    return JSON.parse(String(raw)) as SongState;
  } catch {
    return null;
  }
}

export async function cacheState(s: SongState) {
  await storage.setItem(stateKey(s.song_id), JSON.stringify(s));
}
