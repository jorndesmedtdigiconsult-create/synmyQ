import Ionicons from "@react-native-vector-icons/ionicons";
import * as DocumentPicker from "expo-document-picker";
import * as Haptics from "expo-haptics";
import { useFocusEffect, useRouter } from "expo-router";
import { useCallback, useState } from "react";
import { ActivityIndicator, FlatList, Keyboard, Pressable, RefreshControl, Text, TextInput, View } from "react-native";
import Animated, { FadeInDown } from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { apiFetch } from "@/src/api";
import { useAuth } from "@/src/auth";
import { ConfirmDeleteSheet } from "@/src/components/confirm-delete-sheet";
import { HowItWorks } from "@/src/components/how-it-works";
import { LogoLockup } from "@/src/components/logo";
import { ProfileSheet } from "@/src/components/profile-sheet";
import { QrSheet } from "@/src/components/qr-sheet";
import { fetchAndCacheSong, getLibrary, getPlaylists, LibrarySong, LocalPlaylist, removeFromLibrary, uploadSong } from "@/src/library";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";
import { useToast } from "@/src/toast";

function formatSize(b: number) {
  return `${(b / (1024 * 1024)).toFixed(1)} MB`;
}

export default function Home() {
  const styles = useStyles();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const toast = useToast();
  const { logout, user } = useAuth();
  const [profileOpen, setProfileOpen] = useState(false);
  const [songId, setSongId] = useState("");
  const [loadingId, setLoadingId] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [library, setLibrary] = useState<LibrarySong[] | null>(null);
  const [lastUpload, setLastUpload] = useState<LibrarySong | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [qrSong, setQrSong] = useState<LibrarySong | null>(null);
  const [playlists, setPlaylists] = useState<LocalPlaylist[]>([]);
  // null = follow default (open while the library is empty)
  const [helpOpen, setHelpOpen] = useState<boolean | null>(null);

  const reload = useCallback(async () => {
    setLibrary(await getLibrary());
    setPlaylists(await getPlaylists());
  }, []);

  useFocusEffect(
    useCallback(() => {
      reload();
    }, [reload]),
  );

  const onLoadId = async () => {
    const id = songId.trim().toUpperCase();
    if (id.length < 4) {
      toast.show("Voer een geldig nummer ID in", "error");
      return;
    }
    Keyboard.dismiss();
    if (id.length === 7) {
      setSongId("");
      router.push(`/playlist/${id}`);
      return;
    }
    setLoadingId(true);
    try {
      const s = await fetchAndCacheSong(id);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setSongId("");
      await reload();
      router.push(`/player/${s.song_id}`);
    } catch (e: any) {
      if (e?.message === "WACHTWOORD_VEREIST") {
        setSongId("");
        router.push(`/player/${id}`);
        return;
      }
      toast.show(e?.status === 404 ? "Nummer niet gevonden" : "Kan niet verbinden met de cloud.", "error");
    } finally {
      setLoadingId(false);
    }
  };

  const onUpload = async () => {
    try {
      const res = await DocumentPicker.getDocumentAsync({ type: ["audio/*"], copyToCacheDirectory: true });
      if (res.canceled || !res.assets?.length) return;
      const a = res.assets[0];
      setUploading(true);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      const s = await uploadSong({ uri: a.uri, name: a.name, mimeType: a.mimeType, file: (a as any).file });
      setLastUpload(s);
      await reload();
      toast.show(`Geüpload! ID: ${s.song_id}`, "success");
    } catch (e: any) {
      toast.show(e?.message ?? "Upload mislukt", "error");
    } finally {
      setUploading(false);
    }
  };

  const [deleteSong, setDeleteSong] = useState<LibrarySong | null>(null);
  const [deleting, setDeleting] = useState(false);

  const onConfirmDelete = async () => {
    const s = deleteSong;
    if (!s) return;
    setDeleting(true);
    let stoppedAll = false;
    if (s.isOwner) {
      try {
        await apiFetch(`/songs/${s.song_id}/stop`, { method: "POST" });
        stoppedAll = true;
      } catch {}
    }
    await removeFromLibrary(s.song_id);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    setDeleting(false);
    setDeleteSong(null);
    if (lastUpload?.song_id === s.song_id) setLastUpload(null);
    toast.show(
      stoppedAll ? `${s.title} verwijderd · muziek gestopt op alle toestellen` : `${s.title} verwijderd van dit toestel`,
      "info",
    );
    reload();
  };

  const header = (
    <View style={styles.headerBlock}>
      <View style={styles.panel}>
      <Text style={styles.sectionLabel}>NUMMER LADEN</Text>
      <View style={styles.idRow}>
        <TextInput
          testID="song-id-input"
          value={songId}
          onChangeText={(t) => setSongId(t.toUpperCase())}
          placeholder="bv. K7PX2M"
          placeholderTextColor={colors.muted}
          autoCapitalize="characters"
          autoCorrect={false}
          maxLength={12}
          returnKeyType="go"
          onSubmitEditing={onLoadId}
          style={styles.input}
        />
        <Pressable
          testID="song-id-submit-button"
          onPress={onLoadId}
          disabled={loadingId}
          style={({ pressed }) => [styles.goBtn, pressed && styles.pressed]}
        >
          {loadingId ? (
            <ActivityIndicator color={colors.onAccent} />
          ) : (
            <Ionicons name="arrow-forward" size={22} color={colors.onAccent} />
          )}
        </Pressable>
      </View>
      <Pressable
        testID="scan-qr-button"
        onPress={() => router.push("/scan")}
        style={({ pressed }) => [styles.scanBtn, pressed && styles.pressed]}
      >
        <Ionicons name="qr-code-outline" size={18} color={colors.onSurface} />
        <Text style={styles.scanLabel}>Scan QR-code</Text>
      </Pressable>
      </View>

      <View style={styles.tileRow}>
        <Pressable
          testID="upload-mp3-button"
          onPress={onUpload}
          disabled={uploading}
          style={({ pressed }) => [styles.tile, pressed && styles.pressed]}
        >
          <View style={styles.tileIcon}>
            {uploading ? (
              <ActivityIndicator color={colors.accent} />
            ) : (
              <Ionicons name="cloud-upload-outline" size={22} color={colors.accent} />
            )}
          </View>
          <Text style={styles.tileLabel}>{uploading ? "Uploaden..." : "Upload MP3"}</Text>
          <Text style={styles.tileSub}>Deel een nummer</Text>
        </Pressable>
        <Pressable
          testID="new-playlist-button"
          onPress={() => router.push("/playlist-new")}
          style={({ pressed }) => [styles.tile, pressed && styles.pressed]}
        >
          <View style={styles.tileIcon}>
            <Ionicons name="list" size={22} color={colors.accent} />
          </View>
          <Text style={styles.tileLabel}>Afspeellijst</Text>
          <Text style={styles.tileSub}>Gedeelde wachtrij</Text>
        </Pressable>
      </View>

      <Pressable
        testID="offline-mode-button"
        onPress={() => router.push("/offline")}
        style={({ pressed }) => [styles.offlineBtn, pressed && styles.pressed]}
      >
        <Ionicons name="airplane-outline" size={20} color={colors.accent} />
        <View style={{ flex: 1 }}>
          <Text style={styles.tileLabel}>Offline modus</Text>
          <Text style={styles.tileSub}>Zonder server · eigen bestanden · alleen UTC-tijd</Text>
        </View>
        <Ionicons name="chevron-forward" size={18} color={colors.muted} />
      </Pressable>

      {playlists.length > 0 && (
        <View style={{ marginTop: spacing.xl, gap: spacing.sm }}>
          <Text style={[styles.sectionLabel, { marginBottom: 0 }]}>AFSPEELLIJSTEN</Text>
          {playlists.map((p) => (
            <Pressable
              key={p.playlist_id}
              testID={`playlist-item-${p.playlist_id}`}
              onPress={() => router.push(`/playlist/${p.playlist_id}`)}
              style={({ pressed }) => [styles.row, pressed && styles.pressed]}
            >
              <View style={styles.rowIcon}>
                <Ionicons name="albums-outline" size={18} color={colors.accent} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.rowTitle} numberOfLines={1}>
                  {p.title}
                </Text>
                <Text style={styles.rowMeta}>
                  {p.playlist_id} · {p.count} nummers
                </Text>
              </View>
              <Pressable
                testID={`playlist-qr-${p.playlist_id}`}
                onPress={() => setQrSong({ song_id: p.playlist_id, title: p.title, size: 0, localUri: null, cachedAt: 0 })}
                style={styles.iconBtn}
              >
                <Ionicons name="qr-code-outline" size={20} color={colors.onSurface} />
              </Pressable>
            </Pressable>
          ))}
        </View>
      )}

      {lastUpload && (
        <Animated.View entering={FadeInDown} testID="last-upload-card" style={styles.uploadCard}>
          <View style={{ flex: 1 }}>
            <Text style={styles.cardLabel}>UNIEK ID — DEEL MET ANDERE TOESTELLEN</Text>
            <Text testID="last-upload-id" style={styles.bigId} selectable>
              {lastUpload.song_id}
            </Text>
            <Text style={styles.cardTitle} numberOfLines={1}>
              {lastUpload.title}
            </Text>
          </View>
          <Pressable testID="share-upload-id-button" onPress={() => setQrSong(lastUpload)} style={styles.qrBtn} hitSlop={8}>
            <Ionicons name="qr-code" size={22} color={colors.onAccent} />
          </Pressable>
        </Animated.View>
      )}

      <View style={{ marginTop: spacing.md }}>
        <HowItWorks open={helpOpen ?? library?.length === 0} onToggle={() => setHelpOpen(!(helpOpen ?? library?.length === 0))} />
      </View>

      <View style={styles.libHeader}>
        <Text style={[styles.sectionLabel, { marginBottom: 0 }]}>OFFLINE BIBLIOTHEEK</Text>
        <Text testID="library-count" style={styles.count}>
          {library?.length ?? 0}
        </Text>
      </View>
    </View>
  );

  return (
    <View style={styles.root}>
      <View style={[styles.topBar, { paddingTop: insets.top + spacing.sm }]}>
        <LogoLockup size={40} subtitle={user?.name ? `HALLO, ${user.name.toUpperCase()}` : "UTC SYNC PLAYER"} />
        <View style={{ flexDirection: "row" }}>
          <Pressable testID="edit-profile-button" onPress={() => setProfileOpen(true)} style={styles.iconBtn} hitSlop={8}>
            <Ionicons name="person-circle-outline" size={26} color={colors.onSurface} />
          </Pressable>
          <Pressable testID="logout-button" onPress={logout} style={styles.iconBtn} hitSlop={8}>
            <Ionicons name="log-out-outline" size={22} color={colors.onSurface} />
          </Pressable>
        </View>
      </View>

      <FlatList
        testID="library-list"
        data={library ?? []}
        keyExtractor={(i) => i.song_id}
        keyboardShouldPersistTaps="handled"
        ListHeaderComponent={header}
        contentContainerStyle={{ paddingHorizontal: spacing.lg, paddingBottom: insets.bottom + spacing.xl }}
        refreshControl={
          <RefreshControl
            tintColor={colors.onSurface}
            refreshing={refreshing}
            onRefresh={async () => {
              setRefreshing(true);
              await reload();
              setRefreshing(false);
            }}
          />
        }
        ItemSeparatorComponent={() => <View style={{ height: spacing.sm }} />}
        ListEmptyComponent={
          library === null ? (
            <View style={{ gap: spacing.sm }}>
              {[0, 1, 2].map((k) => (
                <View key={k} style={styles.skeleton} />
              ))}
            </View>
          ) : (
            <View testID="library-empty" style={styles.empty}>
              <Text style={styles.emptyText}>Nog geen nummers. Scan een QR-code of voer een ID in.</Text>
            </View>
          )
        }
        renderItem={({ item, index }) => (
          <Animated.View entering={FadeInDown.delay(index * 40)}>
            <Pressable
              testID={`library-item-${item.song_id}`}
              onPress={() => router.push(`/player/${item.song_id}`)}
              onLongPress={() => setDeleteSong(item)}
              style={({ pressed }) => [styles.row, pressed && styles.pressed]}
            >
              <View style={styles.rowIcon}>
                <Ionicons name="musical-notes" size={18} color={colors.onSurface} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.rowTitle} numberOfLines={1}>
                  {item.title}
                </Text>
                <View style={styles.rowMetaLine}>
                  <Text style={styles.rowId}>{item.song_id}</Text>
                  <Text style={styles.rowMeta}>
                    {formatSize(item.size)} · {item.localUri ? "offline" : "stream"}
                  </Text>
                  {item.isOwner && (
                    <View style={styles.ownerTag}>
                      <Text style={styles.ownerTagText}>BEHEERDER</Text>
                    </View>
                  )}
                </View>
              </View>
              <Pressable testID={`share-${item.song_id}`} onPress={() => setQrSong(item)} style={styles.iconBtn} hitSlop={6}>
                <Ionicons name="qr-code-outline" size={20} color={colors.onSurface} />
              </Pressable>
              <Pressable
                testID={`delete-${item.song_id}`}
                onPress={() => setDeleteSong(item)}
                style={styles.iconBtn}
                hitSlop={6}
              >
                <Ionicons name="trash-outline" size={20} color={colors.error} />
              </Pressable>
              <View style={styles.playCircle}>
                <Ionicons name="play" size={18} color={colors.onBrandPrimary} />
              </View>
            </Pressable>
          </Animated.View>
        )}
      />
      <QrSheet
        visible={!!qrSong}
        songId={qrSong?.song_id ?? ""}
        title={qrSong?.title ?? ""}
        onClose={() => setQrSong(null)}
      />
      <ConfirmDeleteSheet
        song={deleteSong}
        busy={deleting}
        onCancel={() => setDeleteSong(null)}
        onConfirm={onConfirmDelete}
      />
      <ProfileSheet visible={profileOpen} onClose={() => setProfileOpen(false)} />
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: c.divider,
  },
  headerBlock: { paddingTop: spacing.lg, paddingBottom: spacing.md },
  panel: {
    padding: spacing.lg,
    borderRadius: radius.lg,
    backgroundColor: c.surfaceSecondary,
    borderWidth: 1,
    borderColor: c.border,
  },
  scanBtn: {
    marginTop: spacing.md,
    height: 44,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: c.borderStrong,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
  },
  scanLabel: { color: c.onSurface, fontFamily: fonts.textMedium, fontSize: 15 },
  qrBtn: {
    width: 48,
    height: 48,
    borderRadius: radius.md,
    backgroundColor: c.accent,
    alignItems: "center",
    justifyContent: "center",
  },
  libHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: spacing.xl,
  },
  count: {
    color: c.onAccent,
    backgroundColor: c.accent,
    fontFamily: fonts.display,
    fontSize: 14,
    minWidth: 26,
    textAlign: "center",
    paddingHorizontal: spacing.sm,
    borderRadius: radius.pill,
    overflow: "hidden",
  },
  rowIcon: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    backgroundColor: c.surfaceTertiary,
    alignItems: "center",
    justifyContent: "center",
  },
  rowMetaLine: { flexDirection: "row", alignItems: "center", gap: spacing.sm, marginTop: 2 },
  rowId: { color: c.onSurface, fontFamily: fonts.display, fontSize: 15, letterSpacing: 2 },
  ownerTag: { borderWidth: 1, borderColor: c.accent, borderRadius: radius.sm, paddingHorizontal: spacing.xs },
  ownerTagText: { color: c.accent, fontFamily: fonts.displaySemi, fontSize: 10, letterSpacing: 1 },
  sectionLabel: {
    color: c.onSurface,
    fontFamily: fonts.displaySemi,
    fontSize: 13,
    letterSpacing: 2,
    marginBottom: spacing.sm,
    borderLeftWidth: 3,
    borderLeftColor: c.accent,
    paddingLeft: spacing.sm,
  },
  idRow: { flexDirection: "row", gap: spacing.sm },
  input: {
    flex: 1,
    minWidth: 0,
    height: 52,
    borderRadius: radius.md,
    backgroundColor: c.surfaceTertiary,
    borderWidth: 1,
    borderColor: c.border,
    color: c.onSurface,
    paddingHorizontal: spacing.lg,
    fontFamily: fonts.display,
    fontSize: 22,
    letterSpacing: 4,
  },
  goBtn: {
    width: 52,
    height: 52,
    borderRadius: radius.md,
    backgroundColor: c.accent,
    alignItems: "center",
    justifyContent: "center",
  },
  tileRow: { flexDirection: "row", gap: spacing.md, marginTop: spacing.md },
  offlineBtn: {
    marginTop: spacing.md,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    padding: spacing.lg,
    borderRadius: radius.lg,
    backgroundColor: c.surfaceSecondary,
    borderWidth: 1,
    borderColor: c.border,
  },
  tile: {
    flex: 1,
    padding: spacing.lg,
    borderRadius: radius.lg,
    backgroundColor: c.surfaceSecondary,
    borderWidth: 1,
    borderColor: c.border,
    gap: 2,
  },
  tileIcon: {
    width: 40,
    height: 40,
    borderRadius: radius.md,
    backgroundColor: c.accentSoft,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: spacing.sm,
  },
  tileLabel: { color: c.onSurface, fontFamily: fonts.textSemi, fontSize: 15 },
  tileSub: { color: c.muted, fontFamily: fonts.text, fontSize: 12 },
  uploadCard: {
    marginTop: spacing.md,
    padding: spacing.lg,
    borderRadius: radius.lg,
    backgroundColor: c.accentSoft,
    borderWidth: 1,
    borderColor: c.accent,
    flexDirection: "row",
    alignItems: "center",
  },
  cardLabel: { color: c.accent, fontFamily: fonts.displaySemi, fontSize: 11, letterSpacing: 1.5 },
  bigId: { color: c.onSurface, fontFamily: fonts.display, fontSize: 40, letterSpacing: 6, lineHeight: 46 },
  cardTitle: { color: c.onSurface, fontFamily: fonts.text, fontSize: 13 },
  iconBtn: { width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    padding: spacing.md,
    minHeight: 68,
    borderRadius: radius.md,
    backgroundColor: c.surfaceSecondary,
    borderWidth: 1,
    borderColor: c.border,
  },
  rowTitle: { color: c.onSurface, fontFamily: fonts.textMedium, fontSize: 16 },
  rowMeta: { color: c.muted, fontFamily: fonts.displayMedium, fontSize: 13, letterSpacing: 0.5 },
  playCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: c.brandPrimary,
    alignItems: "center",
    justifyContent: "center",
  },
  sep: { height: 1, backgroundColor: c.divider },
  skeleton: { height: 56, borderRadius: radius.md, backgroundColor: c.surfaceSecondary },
  empty: { paddingVertical: spacing.xl, gap: spacing.md },
  emptyText: { color: c.muted, fontFamily: fonts.text, fontSize: 14, textAlign: "center" },
  pressed: { opacity: 0.7 },
}));
