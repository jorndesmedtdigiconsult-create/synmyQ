import Ionicons from "@react-native-vector-icons/ionicons";
import { CameraView, useCameraPermissions } from "expo-camera";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import { useRef, useState } from "react";
import { ActivityIndicator, Linking, Pressable, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { joinSession, PASSWORD_REQUIRED } from "@/src/components/join-gate";
import { parseQrValue } from "@/src/components/qr-sheet";
import { fetchAndCacheSong } from "@/src/library";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";
import { useToast } from "@/src/toast";

export default function Scan() {
  const styles = useStyles();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const toast = useToast();
  const [permission, requestPermission] = useCameraPermissions();
  const [loading, setLoading] = useState(false);
  const handled = useRef(false);

  const onScanned = async ({ data }: { data: string }) => {
    if (handled.current) return;
    const parsed = parseQrValue(data);
    if (!parsed) return;
    const { id, password } = parsed;
    handled.current = true;
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setLoading(true);
    try {
      if (password) {
        // QR join: the password travels inside the code, so no typing needed
        await joinSession(id.length === 7 ? "playlists" : "songs", id, password).catch(() => {});
      }
      if (id.length === 7) {
        router.replace(`/playlist/${id}`);
        return;
      }
      const s = await fetchAndCacheSong(id).catch((e) => {
        if (e?.message === PASSWORD_REQUIRED) return null;
        throw e;
      });
      if (!s) return router.replace(`/player/${id}`);
      router.replace(`/player/${s.song_id}`);
    } catch (e: any) {
      toast.show(e?.status === 404 ? "Nummer niet gevonden" : "Kan niet verbinden met de cloud.", "error");
      setLoading(false);
      setTimeout(() => (handled.current = false), 1500);
    }
  };

  const header = (
    <View style={[styles.topBar, { paddingTop: insets.top + spacing.sm }]}>
      <Pressable testID="scan-back-button" onPress={() => router.back()} style={styles.iconBtn} hitSlop={8}>
        <Ionicons name="chevron-back" size={26} color={colors.onSurface} />
      </Pressable>
      <Text style={styles.title}>Scan QR-code</Text>
    </View>
  );

  if (!permission) {
    return (
      <View style={styles.root}>
        {header}
        <View style={styles.center}>
          <ActivityIndicator color={colors.onSurface} />
        </View>
      </View>
    );
  }

  if (!permission.granted) {
    const blocked = permission.status === "denied" && !permission.canAskAgain;
    return (
      <View style={styles.root}>
        {header}
        <View testID="camera-permission-panel" style={[styles.center, { paddingBottom: insets.bottom + spacing.xl }]}>
          <Ionicons name="qr-code-outline" size={56} color={colors.onSurface} />
          <Text style={styles.permTitle}>Camera nodig om te scannen</Text>
          <Text style={styles.permText}>
            Scan de QR-code op een ander toestel om het nummer meteen te laden en synchroon af te spelen. De camera
            wordt alleen gebruikt voor het scannen.
          </Text>
          {blocked ? (
            <Pressable testID="open-settings-button" onPress={() => Linking.openSettings()} style={styles.primary}>
              <Text style={styles.primaryLabel}>Open Instellingen</Text>
            </Pressable>
          ) : (
            <Pressable testID="allow-camera-button" onPress={requestPermission} style={styles.primary}>
              <Text style={styles.primaryLabel}>{permission.status === "denied" ? "Opnieuw toestaan" : "Camera toestaan"}</Text>
            </Pressable>
          )}
          <Pressable testID="scan-cancel-button" onPress={() => router.back()} style={styles.ghost}>
            <Text style={styles.ghostLabel}>Liever ID typen</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.root}>
      {header}
      <View style={styles.cameraWrap}>
        <CameraView
          testID="qr-camera"
          style={{ flex: 1 }}
          facing="back"
          barcodeScannerSettings={{ barcodeTypes: ["qr"] }}
          onBarcodeScanned={loading ? undefined : onScanned}
        />
        <View style={[styles.overlay, { pointerEvents: "none" }]}>
          <View style={styles.frame} />
          <Text style={styles.overlayText}>{loading ? "Nummer laden..." : "Richt op de SyncMyQue QR-code"}</Text>
          {loading && <ActivityIndicator color={colors.onSurface} style={{ marginTop: spacing.md }} />}
        </View>
      </View>
      <View style={{ height: insets.bottom }} />
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    paddingHorizontal: spacing.sm,
    paddingBottom: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: c.divider,
  },
  iconBtn: { width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  title: { color: c.onSurface, fontFamily: fonts.display, fontSize: 24 },
  center: { flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: spacing.xl, gap: spacing.md },
  permTitle: { color: c.onSurface, fontFamily: fonts.display, fontSize: 26, textAlign: "center" },
  permText: { color: c.muted, fontFamily: fonts.text, fontSize: 14, textAlign: "center" },
  primary: {
    alignSelf: "stretch",
    height: 52,
    borderRadius: radius.md,
    backgroundColor: c.brandPrimary,
    alignItems: "center",
    justifyContent: "center",
    marginTop: spacing.md,
  },
  primaryLabel: { color: c.onBrandPrimary, fontFamily: fonts.textSemi, fontSize: 16 },
  ghost: { height: 48, justifyContent: "center" },
  ghostLabel: { color: c.onSurface, fontFamily: fonts.textMedium, fontSize: 15 },
  cameraWrap: { flex: 1, overflow: "hidden" },
  overlay: { ...{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }, alignItems: "center", justifyContent: "center" },
  frame: { width: 240, height: 240, borderRadius: radius.lg, borderWidth: 3, borderColor: c.onSurface },
  overlayText: { color: c.onSurface, fontFamily: fonts.textSemi, fontSize: 15, marginTop: spacing.lg },
}));
