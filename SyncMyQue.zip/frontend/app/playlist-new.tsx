import Ionicons from "@react-native-vector-icons/ionicons";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import { ActivityIndicator, FlatList, Pressable, Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { apiFetch } from "@/src/api";
import { getLibrary, LibrarySong, upsertPlaylist } from "@/src/library";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";
import { useToast } from "@/src/toast";

export default function NewPlaylist() {
  const styles = useStyles();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const toast = useToast();
  const [library, setLibrary] = useState<LibrarySong[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [title, setTitle] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    getLibrary().then(setLibrary);
  }, []);

  const toggle = (id: string) => {
    Haptics.selectionAsync();
    setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));
  };

  const create = async () => {
    if (!selected.length) return toast.show("Kies minstens één nummer", "error");
    setBusy(true);
    try {
      const p = await apiFetch<{ playlist_id: string; title: string; items: unknown[] }>("/playlists", {
        method: "POST",
        body: JSON.stringify({ title: title.trim() || "Afspeellijst", items: selected }),
      });
      await upsertPlaylist({ playlist_id: p.playlist_id, title: p.title, count: p.items.length });
      toast.show(`Afspeellijst klaar · ID ${p.playlist_id}`, "success");
      router.replace(`/playlist/${p.playlist_id}`);
    } catch (e: any) {
      toast.show(e?.message ?? "Aanmaken mislukt", "error");
      setBusy(false);
    }
  };

  return (
    <View style={styles.root}>
      <View style={[styles.top, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable testID="new-playlist-back-button" onPress={() => router.back()} style={styles.iconBtn}>
          <Ionicons name="chevron-back" size={26} color={colors.onSurface} />
        </Pressable>
        <Text style={styles.h1}>Nieuwe afspeellijst</Text>
      </View>
      <FlatList
        data={library}
        keyExtractor={(i) => i.song_id}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ padding: spacing.lg, gap: spacing.sm, paddingBottom: insets.bottom + 96 }}
        ListHeaderComponent={
          <View style={{ gap: spacing.sm, marginBottom: spacing.sm }}>
            <TextInput
              testID="playlist-title-input"
              value={title}
              onChangeText={setTitle}
              placeholder="Naam van de lijst"
              placeholderTextColor={colors.muted}
              maxLength={60}
              style={styles.input}
            />
            <Text style={styles.label}>TIK NUMMERS IN DE VOLGORDE VAN AFSPELEN</Text>
          </View>
        }
        ListEmptyComponent={<Text style={styles.empty}>Laad eerst nummers in je offline bibliotheek.</Text>}
        renderItem={({ item }) => {
          const n = selected.indexOf(item.song_id);
          return (
            <Pressable testID={`pick-${item.song_id}`} onPress={() => toggle(item.song_id)} style={[styles.row, n >= 0 && styles.rowOn]}>
              <View style={[styles.badge, n >= 0 && styles.badgeOn]}>
                <Text style={[styles.badgeText, n >= 0 && { color: colors.onBrandPrimary }]}>{n >= 0 ? n + 1 : ""}</Text>
              </View>
              <Text style={styles.rowTitle} numberOfLines={1}>
                {item.title}
              </Text>
              <Text style={styles.rowId}>{item.song_id}</Text>
            </Pressable>
          );
        }}
      />
      <View style={[styles.footer, { paddingBottom: insets.bottom + spacing.md }]}>
        <Pressable testID="create-playlist-button" onPress={create} disabled={busy || !selected.length} style={[styles.primary, (!selected.length || busy) && { opacity: 0.4 }]}>
          {busy ? <ActivityIndicator color={colors.onBrandPrimary} /> : <Text style={styles.primaryLabel}>Maak lijst ({selected.length})</Text>}
        </Pressable>
      </View>
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  top: { flexDirection: "row", alignItems: "center", gap: spacing.sm, paddingHorizontal: spacing.sm, paddingBottom: spacing.md, borderBottomWidth: 1, borderBottomColor: c.divider },
  iconBtn: { width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  h1: { color: c.onSurface, fontFamily: fonts.display, fontSize: 24 },
  input: { height: 52, borderRadius: radius.md, backgroundColor: c.surfaceTertiary, borderWidth: 1, borderColor: c.border, color: c.onSurface, paddingHorizontal: spacing.lg, fontFamily: fonts.textMedium, fontSize: 16 },
  label: { color: c.muted, fontFamily: fonts.displaySemi, fontSize: 12, letterSpacing: 1.5 },
  empty: { color: c.muted, fontFamily: fonts.text, fontSize: 14, textAlign: "center", marginTop: spacing.xl },
  row: { flexDirection: "row", alignItems: "center", gap: spacing.md, padding: spacing.md, minHeight: 56, borderRadius: radius.md, backgroundColor: c.surfaceSecondary, borderWidth: 1, borderColor: c.border },
  rowOn: { borderColor: c.onSurface },
  badge: { width: 28, height: 28, borderRadius: 14, borderWidth: 1, borderColor: c.borderStrong, alignItems: "center", justifyContent: "center" },
  badgeOn: { backgroundColor: c.brandPrimary, borderColor: c.brandPrimary },
  badgeText: { color: c.onSurface, fontFamily: fonts.display, fontSize: 15 },
  rowTitle: { flex: 1, color: c.onSurface, fontFamily: fonts.textMedium, fontSize: 15 },
  rowId: { color: c.muted, fontFamily: fonts.display, fontSize: 14, letterSpacing: 2 },
  footer: { position: "absolute", left: 0, right: 0, bottom: 0, paddingHorizontal: spacing.lg, paddingTop: spacing.md, backgroundColor: c.surface, borderTopWidth: 1, borderTopColor: c.divider },
  primary: { height: 52, borderRadius: radius.md, backgroundColor: c.brandPrimary, alignItems: "center", justifyContent: "center" },
  primaryLabel: { color: c.onBrandPrimary, fontFamily: fonts.textSemi, fontSize: 16 },
}));
