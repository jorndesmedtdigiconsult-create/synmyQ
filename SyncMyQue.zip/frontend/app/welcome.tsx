import * as Haptics from "expo-haptics";
import { useState } from "react";
import { ActivityIndicator, Pressable, Text, TextInput, View } from "react-native";
import { KeyboardAvoidingView } from "react-native-keyboard-controller";
import Animated, { FadeInDown } from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAuth } from "@/src/auth";
import { LogoMark } from "@/src/components/logo";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";
import { useToast } from "@/src/toast";

export default function Welcome() {
  const styles = useStyles();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const { setName, logout } = useAuth();
  const toast = useToast();
  const [name, setNameInput] = useState("");
  const [busy, setBusy] = useState(false);
  const trimmed = name.trim();

  const onSave = async () => {
    if (!trimmed) return;
    setBusy(true);
    try {
      await setName(trimmed);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      toast.show(`Hallo, ${trimmed}!`, "success");
    } catch {
      toast.show("Kan niet verbinden met de cloud. Probeer opnieuw.", "error");
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView behavior="padding" style={styles.root}>
      <View style={[styles.inner, { paddingTop: insets.top + spacing.xxxl, paddingBottom: insets.bottom + spacing.xl }]}>
        <Animated.View entering={FadeInDown.duration(500)} style={{ gap: spacing.sm }}>
          <LogoMark size={72} animated />
          <Text style={styles.title}>Hoe heet je?</Text>
          <Text style={styles.sub}>
            Zo begroeten we je persoonlijk en zien de andere toestellen wie er meeluistert.
          </Text>
          <TextInput
            testID="welcome-name-input"
            value={name}
            onChangeText={setNameInput}
            placeholder="Je voornaam"
            placeholderTextColor={colors.muted}
            autoFocus
            autoCapitalize="words"
            autoCorrect={false}
            maxLength={40}
            returnKeyType="done"
            onSubmitEditing={onSave}
            style={styles.input}
          />
          {trimmed ? (
            <Text testID="welcome-preview" style={styles.preview}>
              Hallo, {trimmed}
            </Text>
          ) : null}
        </Animated.View>

        <View style={{ gap: spacing.sm }}>
          <Pressable
            testID="welcome-continue-button"
            onPress={onSave}
            disabled={!trimmed || busy}
            style={({ pressed }) => [styles.primary, (!trimmed || busy) && { opacity: 0.4 }, pressed && { opacity: 0.7 }]}
          >
            {busy ? <ActivityIndicator color={colors.onAccent} /> : <Text style={styles.primaryLabel}>Doorgaan</Text>}
          </Pressable>
          <Pressable testID="welcome-back-button" onPress={logout} disabled={busy} style={styles.ghost}>
            <Text style={styles.ghostLabel}>Terug naar aanmelden</Text>
          </Pressable>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  inner: { flex: 1, paddingHorizontal: spacing.xl, justifyContent: "space-between" },
  title: { color: c.onSurface, fontFamily: fonts.display, fontSize: 44, marginTop: spacing.xl, borderLeftWidth: 4, borderLeftColor: c.accent, paddingLeft: spacing.md },
  sub: { color: c.muted, fontFamily: fonts.text, fontSize: 15 },
  input: {
    marginTop: spacing.lg,
    height: 56,
    borderRadius: radius.md,
    backgroundColor: c.surfaceTertiary,
    borderWidth: 1,
    borderColor: c.border,
    color: c.onSurface,
    paddingHorizontal: spacing.lg,
    fontFamily: fonts.textMedium,
    fontSize: 18,
  },
  preview: { color: c.onSurface, fontFamily: fonts.displaySemi, fontSize: 22, marginTop: spacing.sm },
  primary: { height: 52, borderRadius: radius.md, backgroundColor: c.accent, alignItems: "center", justifyContent: "center" },
  primaryLabel: { color: c.onAccent, fontFamily: fonts.textSemi, fontSize: 16 },
  ghost: { height: 48, alignItems: "center", justifyContent: "center" },
  ghostLabel: { color: c.onSurface, fontFamily: fonts.textMedium, fontSize: 15 },
}));
