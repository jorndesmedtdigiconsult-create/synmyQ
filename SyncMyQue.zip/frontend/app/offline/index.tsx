import Ionicons from "@react-native-vector-icons/ionicons";
import * as Haptics from "expo-haptics";
import * as Network from "expo-network";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useEffect, useState } from "react";
import { Platform, Pressable, Text, TextInput, View } from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-controller";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { decodeOffline, fmtClock, type OfflineCode, pickLocalSong, saveOfflineSession } from "@/src/offline";
import { P2P_PORT, p2pAvailable } from "@/src/p2p";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";
import { useToast } from "@/src/toast";

const DELAYS = [
  { label: "30 s", s: 30 },
  { label: "1 min", s: 60 },
  { label: "2 min", s: 120 },
  { label: "5 min", s: 300 },
];

/** "20:00" → next moment (today or tomorrow) with that local time. */
function atLocalTime(hhmm: string): number | null {
  const m = /^(\d{1,2})[:.h](\d{2})$/.exec(hhmm.trim());
  if (!m || +m[1] > 23 || +m[2] > 59) return null;
  const d = new Date();
  d.setHours(+m[1], +m[2], 0, 0);
  if (d.getTime() < Date.now() + 10000) d.setDate(d.getDate() + 1);
  return d.getTime();
}

export default function OfflineHome() {
  const styles = useStyles();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const toast = useToast();
  const params = useLocalSearchParams<{ code?: string }>();
  const [now, setNow] = useState(Date.now());
  const [song, setSong] = useState<{ uri: string; title: string; size: number } | null>(null);
  const [delay, setDelay] = useState(60);
  const [time, setTime] = useState("");
  const [codeText, setCodeText] = useState("");
  const [code, setCode] = useState<OfflineCode | null>(null);

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (params.code) setCode(decodeOffline(String(params.code)));
  }, [params.code]);

  const pick = async () => {
    try {
      return await pickLocalSong();
    } catch {
      toast.show("Kan het bestand niet openen", "error");
      return null;
    }
  };

  const onPickAdmin = async () => {
    const s = await pick();
    if (s) setSong(s);
  };

  const onCreate = async () => {
    if (!song) return;
    let at: number | null = Math.ceil((Date.now() + delay * 1000) / 1000) * 1000;
    if (time.trim()) {
      at = atLocalTime(time);
      if (!at) return toast.show("Gebruik het formaat UU:MM, bijv. 20:00", "error");
    }
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    // Same Wi-Fi / hotspot: put this phone's address in the QR so listeners can be controlled directly
    let wifi = {};
    if (p2pAvailable) {
      const ip = await Network.getIpAddressAsync().catch(() => "");
      if (ip && ip !== "0.0.0.0" && !ip.startsWith("127.")) wifi = { host: ip, port: P2P_PORT };
    }
    await saveOfflineSession({ ...song, at, role: "admin", ...wifi });
    router.push("/offline/play");
  };

  const onUseCode = () => {
    const c = decodeOffline(codeText);
    if (!c) return toast.show("Ongeldige offline code", "error");
    setCode(c);
  };

  const onPickListener = async () => {
    if (!code) return;
    const s = await pick();
    if (!s) return;
    if (code.size && s.size && code.size !== s.size) {
      toast.show("Let op: dit bestand verschilt van dat van de beheerder. De sync kan afwijken.", "error");
    }
    await saveOfflineSession({ ...code, uri: s.uri, role: "listener" });
    router.push("/offline/play");
  };

  return (
    <View style={styles.root}>
      <View style={[styles.topBar, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable testID="offline-back-button" onPress={() => (router.canGoBack() ? router.back() : router.replace("/"))} style={styles.iconBtn} hitSlop={8}>
          <Ionicons name="chevron-back" size={26} color={colors.onSurface} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>Offline modus</Text>
          <Text style={styles.sub}>Zonder server · alleen UTC-tijd</Text>
        </View>
      </View>

      <KeyboardAwareScrollView contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + spacing.xxl }]} keyboardShouldPersistTaps="handled">
        <View testID="offline-clock" style={styles.clock}>
          <Text style={styles.clockLabel}>JOUW KLOK</Text>
          <Text style={styles.clockValue}>{fmtClock(now, true)} UTC</Text>
          <Text style={styles.hint}>Zet {"\u201C"}Automatische datum en tijd{"\u201D"} aan op elke gsm, zo lopen alle klokken gelijk.</Text>
        </View>

        {!code && (
          <View style={styles.card}>
            <Text style={styles.cardLabel}>IK BEN BEHEERDER</Text>
            <Pressable testID="offline-pick-admin" onPress={onPickAdmin} style={({ pressed }) => [styles.pick, pressed && styles.pressed]}>
              <Ionicons name={song ? "musical-note" : "folder-open-outline"} size={20} color={colors.accent} />
              <Text style={styles.pickLabel} numberOfLines={1}>
                {song ? song.title : "Kies nummer van je gsm of cloud"}
              </Text>
            </Pressable>
            <Text style={styles.small}>Start over</Text>
            <View style={styles.chips}>
              {DELAYS.map((d) => {
                const on = !time.trim() && delay === d.s;
                return (
                  <Pressable
                    key={d.s}
                    testID={`offline-delay-${d.s}`}
                    onPress={() => {
                      setDelay(d.s);
                      setTime("");
                    }}
                    style={[styles.chip, on && styles.chipOn]}
                  >
                    <Text style={[styles.chipLabel, on && { color: colors.onAccent }]}>{d.label}</Text>
                  </Pressable>
                );
              })}
            </View>
            <Text style={styles.small}>Of om een vast tijdstip (jouw tijd)</Text>
            <TextInput
              testID="offline-time-input"
              value={time}
              onChangeText={setTime}
              placeholder="bv. 20:00"
              placeholderTextColor={colors.muted}
              keyboardType={Platform.OS === "ios" ? "numbers-and-punctuation" : "default"}
              maxLength={5}
              style={styles.input}
            />
            <Pressable
              testID="offline-create-button"
              onPress={onCreate}
              disabled={!song}
              style={({ pressed }) => [styles.primary, !song && { opacity: 0.4 }, pressed && styles.pressed]}
            >
              <Ionicons name="qr-code" size={20} color={colors.onAccent} />
              <Text style={styles.primaryLabel}>Maak QR-code & start</Text>
            </Pressable>
          </View>
        )}

        <View style={styles.card}>
          <Text style={styles.cardLabel}>IK BEN LUISTERAAR</Text>
          {code ? (
            <View testID="offline-code-ok" style={{ gap: spacing.sm }}>
              <Text style={styles.codeTitle} numberOfLines={2}>
                {code.title}
              </Text>
              <Text style={styles.hint}>
                Start om {fmtClock(code.at)} ({fmtClock(code.at, true)} UTC). Kies nu hetzelfde nummer op je gsm.
              </Text>
              <Pressable testID="offline-pick-listener" onPress={onPickListener} style={({ pressed }) => [styles.primary, pressed && styles.pressed]}>
                <Ionicons name="folder-open-outline" size={20} color={colors.onAccent} />
                <Text style={styles.primaryLabel}>Kies hetzelfde nummer</Text>
              </Pressable>
              <Pressable testID="offline-code-reset" onPress={() => setCode(null)} style={styles.ghost}>
                <Text style={styles.ghostLabel}>Andere code</Text>
              </Pressable>
            </View>
          ) : (
            <>
              <Pressable testID="offline-scan-button" onPress={() => router.push("/offline/scan")} style={({ pressed }) => [styles.pick, pressed && styles.pressed]}>
                <Ionicons name="scan" size={20} color={colors.accent} />
                <Text style={styles.pickLabel}>Scan de offline QR-code</Text>
              </Pressable>
              <Text style={styles.small}>Of plak de code die je kreeg</Text>
              <View style={styles.row}>
                <TextInput
                  testID="offline-code-input"
                  value={codeText}
                  onChangeText={setCodeText}
                  placeholder="syncmyque-off:..."
                  placeholderTextColor={colors.muted}
                  autoCapitalize="none"
                  autoCorrect={false}
                  style={[styles.input, { flex: 1, marginTop: 0 }]}
                />
                <Pressable testID="offline-code-go" onPress={onUseCode} disabled={!codeText.trim()} style={[styles.goBtn, !codeText.trim() && { opacity: 0.4 }]}>
                  <Ionicons name="arrow-forward" size={22} color={colors.onAccent} />
                </Pressable>
              </View>
            </>
          )}
        </View>

        <Text style={styles.note}>
          In de offline modus gaat er niets via een server: elke gsm speelt zijn eigen bestand af op de afgesproken UTC-tijd en blijft zelf in sync. Zitten alle gsm{"'"}s op hetzelfde wifi of de hotspot van de beheerder, dan bedient de beheerder Play, Pauze en Stop rechtstreeks voor iedereen (alleen in de geïnstalleerde app, niet in Expo Go).
        </Text>
      </KeyboardAwareScrollView>
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    paddingHorizontal: spacing.sm,
    paddingBottom: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: c.divider,
  },
  iconBtn: { width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  title: { color: c.onSurface, fontFamily: fonts.display, fontSize: 24 },
  sub: { color: c.accent, fontFamily: fonts.displaySemi, fontSize: 12, letterSpacing: 1 },
  content: { padding: spacing.lg, gap: spacing.lg },
  clock: { alignItems: "center", gap: 2 },
  clockLabel: { color: c.muted, fontFamily: fonts.displaySemi, fontSize: 11, letterSpacing: 2 },
  clockValue: { color: c.onSurface, fontFamily: fonts.display, fontSize: 36, letterSpacing: 2 },
  hint: { color: c.muted, fontFamily: fonts.text, fontSize: 13, lineHeight: 18, textAlign: "center" },
  card: {
    padding: spacing.lg,
    borderRadius: radius.lg,
    backgroundColor: c.surfaceSecondary,
    borderWidth: 1,
    borderColor: c.border,
    gap: spacing.sm,
  },
  cardLabel: {
    color: c.onSurface,
    fontFamily: fonts.displaySemi,
    fontSize: 13,
    letterSpacing: 2,
    borderLeftWidth: 3,
    borderLeftColor: c.accent,
    paddingLeft: spacing.sm,
    marginBottom: spacing.xs,
  },
  pick: {
    height: 52,
    borderRadius: radius.md,
    backgroundColor: c.surfaceTertiary,
    borderWidth: 1,
    borderColor: c.border,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
  },
  pickLabel: { flex: 1, color: c.onSurface, fontFamily: fonts.textSemi, fontSize: 15 },
  small: { color: c.muted, fontFamily: fonts.text, fontSize: 12, marginTop: spacing.xs },
  chips: { flexDirection: "row", gap: spacing.sm },
  chip: {
    flex: 1,
    height: 40,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: c.borderStrong,
    alignItems: "center",
    justifyContent: "center",
  },
  chipOn: { backgroundColor: c.accent, borderColor: c.accent },
  chipLabel: { color: c.onSurface, fontFamily: fonts.textSemi, fontSize: 14 },
  input: {
    marginTop: 0,
    height: 52,
    borderRadius: radius.md,
    backgroundColor: c.surfaceTertiary,
    borderWidth: 1,
    borderColor: c.border,
    color: c.onSurface,
    paddingHorizontal: spacing.lg,
    fontFamily: fonts.textMedium,
    fontSize: 16,
  },
  primary: {
    marginTop: spacing.sm,
    height: 52,
    borderRadius: radius.md,
    backgroundColor: c.accent,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
  },
  primaryLabel: { color: c.onAccent, fontFamily: fonts.textSemi, fontSize: 16 },
  ghost: { height: 44, alignItems: "center", justifyContent: "center" },
  ghostLabel: { color: c.onSurface, fontFamily: fonts.textMedium, fontSize: 14 },
  row: { flexDirection: "row", gap: spacing.sm },
  goBtn: { width: 52, height: 52, borderRadius: radius.md, backgroundColor: c.accent, alignItems: "center", justifyContent: "center" },
  codeTitle: { color: c.onSurface, fontFamily: fonts.display, fontSize: 24 },
  note: { color: c.muted, fontFamily: fonts.text, fontSize: 12, lineHeight: 17, textAlign: "center" },
  pressed: { opacity: 0.7 },
}));
