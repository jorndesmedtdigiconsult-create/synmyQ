import Ionicons from "@react-native-vector-icons/ionicons";
import { CameraView, useCameraPermissions } from "expo-camera";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import { useRef } from "react";
import { ActivityIndicator, Linking, Pressable, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { decodeOffline } from "@/src/offline";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";
import { useToast } from "@/src/toast";

export default function OfflineScan() {
  const styles = useStyles();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const toast = useToast();
  const [permission, requestPermission] = useCameraPermissions();
  const handled = useRef(false);
  const warned = useRef(false);

  const onScanned = ({ data }: { data: string }) => {
    if (handled.current) return;
    if (!decodeOffline(data)) {
      if (!warned.current) {
        warned.current = true;
        toast.show("Dit is geen offline QR-code van SyncMyQue", "error");
      }
      return;
    }
    handled.current = true;
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    router.replace({ pathname: "/offline", params: { code: data } });
  };

  const header = (
    <View style={[styles.topBar, { paddingTop: insets.top + spacing.sm }]}>
      <Pressable testID="offline-scan-back" onPress={() => router.back()} style={styles.iconBtn} hitSlop={8}>
        <Ionicons name="chevron-back" size={26} color={colors.onSurface} />
      </Pressable>
      <Text style={styles.title}>Scan offline QR</Text>
    </View>
  );

  if (!permission) {
    return (
      <View style={styles.root}>
        {header}
        <View style={styles.center}>
          <ActivityIndicator color={colors.onSurface} />
        </View>
      </View>
    );
  }

  if (!permission.granted) {
    const blocked = permission.status === "denied" && !permission.canAskAgain;
    return (
      <View style={styles.root}>
        {header}
        <View testID="offline-camera-permission" style={[styles.center, { paddingBottom: insets.bottom + spacing.xl }]}>
          <Ionicons name="qr-code-outline" size={56} color={colors.accent} />
          <Text style={styles.permTitle}>Camera nodig om te scannen</Text>
          <Text style={styles.permText}>Scan de offline QR-code van de beheerder om de starttijd over te nemen.</Text>
          {blocked ? (
            <Pressable testID="offline-open-settings" onPress={() => Linking.openSettings()} style={styles.primary}>
              <Text style={styles.primaryLabel}>Open Instellingen</Text>
            </Pressable>
          ) : (
            <Pressable testID="offline-allow-camera" onPress={requestPermission} style={styles.primary}>
              <Text style={styles.primaryLabel}>{permission.status === "denied" ? "Opnieuw toestaan" : "Camera toestaan"}</Text>
            </Pressable>
          )}
          <Pressable onPress={() => router.back()} style={styles.ghost}>
            <Text style={styles.ghostLabel}>Liever de code plakken</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.root}>
      {header}
      <View style={{ flex: 1, overflow: "hidden" }}>
        <CameraView style={{ flex: 1 }} facing="back" barcodeScannerSettings={{ barcodeTypes: ["qr"] }} onBarcodeScanned={onScanned} />
        <View style={[styles.overlay, { pointerEvents: "none" }]}>
          <View style={styles.frame} />
          <Text style={styles.overlayText}>Richt op de offline QR-code</Text>
        </View>
      </View>
      <View style={{ height: insets.bottom }} />
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    paddingHorizontal: spacing.sm,
    paddingBottom: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: c.divider,
  },
  iconBtn: { width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  title: { color: c.onSurface, fontFamily: fonts.display, fontSize: 24 },
  center: { flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: spacing.xl, gap: spacing.md },
  permTitle: { color: c.onSurface, fontFamily: fonts.display, fontSize: 26, textAlign: "center" },
  permText: { color: c.muted, fontFamily: fonts.text, fontSize: 14, textAlign: "center" },
  primary: {
    alignSelf: "stretch",
    height: 52,
    borderRadius: radius.md,
    backgroundColor: c.accent,
    alignItems: "center",
    justifyContent: "center",
    marginTop: spacing.md,
  },
  primaryLabel: { color: c.onAccent, fontFamily: fonts.textSemi, fontSize: 16 },
  ghost: { height: 48, justifyContent: "center" },
  ghostLabel: { color: c.onSurface, fontFamily: fonts.textMedium, fontSize: 15 },
  overlay: { position: "absolute", top: 0, left: 0, right: 0, bottom: 0, alignItems: "center", justifyContent: "center" },
  frame: { width: 240, height: 240, borderRadius: radius.lg, borderWidth: 3, borderColor: c.accent },
  overlayText: { color: c.onSurface, fontFamily: fonts.textSemi, fontSize: 15, marginTop: spacing.lg },
}));
