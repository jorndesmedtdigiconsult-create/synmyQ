import Ionicons from "@react-native-vector-icons/ionicons";
import { useAudioPlayer } from "expo-audio";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import { useEffect, useRef, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, Share, Text, View } from "react-native";
import QRCode from "react-native-qrcode-svg";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import type { SongState } from "@/src/library";
import { clearOfflineSession, encodeOffline, fmtClock, getOfflineSession, type OfflineSession } from "@/src/offline";
import { p2pAvailable, useP2PClient, useP2PHost } from "@/src/p2p";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";
import { timeline } from "@/src/timeline";
import { type LocalMode, useOfflineEngine } from "@/src/use-offline-engine";
import { storage } from "@/src/utils/storage";

const fmt = (s: number) => {
  const t = Math.max(0, Math.floor(s));
  return `${Math.floor(t / 60)}:${String(t % 60).padStart(2, "0")}`;
};

export default function OfflinePlayScreen() {
  const { colors } = useTheme();
  const router = useRouter();
  const [session, setSession] = useState<OfflineSession | null>(null);
  const [name, setName] = useState("Luisteraar");

  useEffect(() => {
    storage.getItem("syncmyque_last_name", null).then((n: unknown) => typeof n === "string" && n && setName(n));
    getOfflineSession().then((s) => {
      setSession(s);
      if (!s) router.replace("/offline");
    });
  }, [router]);

  if (!session) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.surface, alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color={colors.onSurface} />
      </View>
    );
  }
  return <OfflinePlayer session={session} name={name} />;
}

function OfflinePlayer({ session, name }: { session: OfflineSession; name: string }) {
  const styles = useStyles();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const player = useAudioPlayer({ uri: session.uri }, { updateInterval: 250 });
  const isAdmin = session.role === "admin";
  const wifi = !!session.host && !!session.port && p2pAvailable;

  // Shared state: fixed QR start time; over Wi-Fi the admin changes it for everyone
  const [shared, setShared] = useState<SongState>(() => ({
    song_id: "offline",
    status: "playing",
    start_at_ms: session.at,
    resume_at_ms: session.at,
    version: 1,
  }));
  const host = useP2PHost(isAdmin && wifi, shared, session.size);
  const client = useP2PClient(!isAdmin && wifi ? session.host : undefined, session.port, name, session.size);
  const zero = useRef(0);
  const following = !isAdmin && client.connected && !!client.state;
  const state = following ? client.state! : shared;
  const remote = isAdmin && wifi; // admin buttons control every phone

  const { phase, wait, pos, drift, rate, autoSync, toggleAutoSync, syncNow, localMode, setLocalMode } = useOfflineEngine(
    player,
    state,
    following ? client.offset : zero,
    session.title,
  );
  const dur = player.duration || 0;
  const driftMs = Math.round(drift * 1000);

  // Listeners tell the admin how tight they are
  const lastReport = useRef(0);
  useEffect(() => {
    if (!client.connected || Date.now() - lastReport.current < 2000) return;
    lastReport.current = Date.now();
    client.report(driftMs);
  }, [driftMs, client]);

  const adminAct = (what: "play" | "pause" | "stop") => {
    const now = Date.now();
    setShared((prev) => {
      const v = prev.version + 1;
      if (what === "pause") {
        if (prev.status !== "playing") return prev;
        const tl = timeline({ ...prev, durations_ms: [dur * 1000] }, now, dur);
        return { ...prev, status: "paused", paused_pos_ms: Math.round(tl.pos * 1000), version: v };
      }
      if (what === "stop") return { ...prev, status: "stopped", paused_pos_ms: 0, version: v };
      if (prev.status === "playing") return prev;
      const p = prev.status === "paused" ? (prev.paused_pos_ms ?? 0) : 0;
      const resume = now + (prev.status === "paused" ? 3000 : 5000); // 5 s silence before a fresh start
      return { ...prev, status: "playing", start_at_ms: resume - p, resume_at_ms: resume, version: v };
    });
  };

  const onControl = (what: "play" | "pause" | "stop") => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    if (remote) {
      adminAct(what);
      setLocalMode("sync");
    } else setLocalMode(({ play: "sync", pause: "paused", stop: "stopped" } as Record<string, LocalMode>)[what]);
  };

  const onSyncNow = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    if (following) client.resync();
    if (localMode !== "sync") setLocalMode("sync");
    syncNow();
  };

  const onLeave = async () => {
    Haptics.selectionAsync();
    try {
      player.pause();
    } catch {}
    await clearOfflineSession();
    router.replace("/offline");
  };

  const code = encodeOffline(session);
  const status =
    phase === "stopped"
      ? "GESTOPT"
      : phase === "paused"
        ? "GEPAUZEERD"
        : phase === "countdown"
          ? `START OVER ${fmt(wait)}`
          : phase === "gap"
            ? `STILTE · ${Math.ceil(wait)}s`
            : rate < 1
              ? "VERTRAGEN"
              : rate > 1
                ? "INHALEN"
                : "IN SYNC";
  const playingNow = (remote ? state.status === "playing" : localMode === "sync") && phase !== "stopped" && phase !== "paused";

  const connLabel = isAdmin
    ? wifi
      ? `WIFI-BEHEER · ${host.peers.length} luisteraar${host.peers.length === 1 ? "" : "s"}`
      : "VASTE STARTTIJD · geen wifi-bediening"
    : wifi
      ? client.connected
        ? `VERBONDEN MET BEHEERDER · klok ${client.offsetMs > 0 ? "+" : ""}${client.offsetMs} ms`
        : "WIFI · zoekt beheerder… (vaste starttijd)"
      : "VASTE STARTTIJD";

  return (
    <View style={styles.root}>
      <View style={[styles.topBar, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable testID="offline-play-back" onPress={() => router.back()} style={styles.iconBtn} hitSlop={8}>
          <Ionicons name="chevron-back" size={26} color={colors.onSurface} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={styles.kicker}>OFFLINE · {isAdmin ? "BEHEERDER" : "LUISTERAAR"}</Text>
          <Text style={styles.title} numberOfLines={1}>
            {session.title}
          </Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + spacing.xxl }]}>
        <View testID="offline-connection" style={styles.conn}>
          <Ionicons
            name={wifi ? "wifi" : "time-outline"}
            size={16}
            color={wifi && (isAdmin || client.connected) ? colors.success : colors.accent}
          />
          <Text style={styles.connText}>{connLabel}</Text>
        </View>

        <View testID="offline-status-card" style={styles.card}>
          <Text testID="offline-status" style={[styles.status, phase === "play" && rate === 1 && { color: colors.success }]}>
            {status}
          </Text>
          <Text style={styles.time}>
            {fmt(phase === "play" ? pos : 0)} <Text style={{ color: colors.muted }}>/ {dur ? fmt(dur) : "--:--"}</Text>
          </Text>
          <View style={styles.track}>
            <View style={[styles.fill, { width: `${dur && phase === "play" ? Math.min(100, (pos / dur) * 100) : 0}%` }]} />
          </View>
          <View style={styles.metaRow}>
            <Text style={styles.meta}>
              Start {fmtClock(session.at)} · {fmtClock(session.at, true)} UTC
            </Text>
            <Text style={styles.meta}>{phase === "play" ? `${driftMs > 0 ? "+" : ""}${driftMs} ms` : "LOOP · 5s STILTE"}</Text>
          </View>
        </View>

        <Text style={styles.ctrlLabel}>{remote ? "BEDIENT ALLE GSM'S" : "ALLEEN DEZE GSM"}</Text>
        <View style={styles.controls}>
          <Pressable
            testID="offline-play-button"
            onPress={() => onControl("play")}
            style={({ pressed }) => [styles.ctrl, playingNow && styles.ctrlOn, pressed && styles.pressed]}
          >
            <Ionicons name="play" size={24} color={playingNow ? colors.onAccent : colors.onSurface} />
            <Text style={[styles.ctrlText, playingNow && { color: colors.onAccent }]}>PLAY</Text>
          </Pressable>
          <Pressable testID="offline-pause-button" onPress={() => onControl("pause")} style={({ pressed }) => [styles.ctrl, pressed && styles.pressed]}>
            <Ionicons name="pause" size={24} color={colors.onSurface} />
            <Text style={styles.ctrlText}>PAUZE</Text>
          </Pressable>
          <Pressable testID="offline-stop-button" onPress={() => onControl("stop")} style={({ pressed }) => [styles.ctrl, pressed && styles.pressed]}>
            <Ionicons name="stop" size={24} color={colors.onSurface} />
            <Text style={styles.ctrlText}>STOP</Text>
          </Pressable>
        </View>
        {!remote && (
          <Text style={styles.metaCenter}>Play stapt weer exact in sync in. Stop zet het nummer op 0:00 zonder te herstarten.</Text>
        )}

        <Pressable testID="offline-autosync-toggle" onPress={toggleAutoSync} style={styles.switchRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.switchLabel}>Continue auto-sync</Text>
            <Text style={styles.meta}>{autoSync ? "Tempo volgt de gedeelde tijd de hele song door" : "Uit: vrij afspelen zonder correcties"}</Text>
          </View>
          <View style={[styles.switchTrack, autoSync && styles.switchTrackOn]}>
            <View style={[styles.switchKnob, autoSync && styles.switchKnobOn]} />
          </View>
        </Pressable>
        <Pressable testID="offline-sync-now" onPress={onSyncNow} style={({ pressed }) => [styles.syncNow, pressed && styles.pressed]}>
          <Ionicons name="flash" size={18} color={colors.onAccent} />
          <Text style={styles.syncNowLabel}>SYNC-NOW</Text>
        </Pressable>

        {isAdmin && wifi && host.peers.length > 0 && (
          <View testID="offline-peers" style={styles.card}>
            <Text style={styles.cardLabel}>LUISTERAARS OP WIFI</Text>
            {host.peers.map((p) => (
              <View key={p.id} style={styles.peerRow}>
                <Text style={styles.peerName} numberOfLines={1}>
                  {p.name}
                </Text>
                {!p.sizeOk && <Text style={[styles.meta, { color: colors.error }]}>ander bestand</Text>}
                <Text style={[styles.meta, Math.abs(p.drift_ms) <= 20 && { color: colors.success }]}>
                  {p.drift_ms > 0 ? "+" : ""}
                  {p.drift_ms} ms
                </Text>
              </View>
            ))}
          </View>
        )}
        {isAdmin && wifi && host.error && <Text style={[styles.metaCenter, { color: colors.error }]}>Wifi-bediening: {host.error}</Text>}
        {!p2pAvailable && (
          <Text style={styles.metaCenter}>Bediening van alle gsm{"'"}s via wifi werkt alleen in de geïnstalleerde app (niet in Expo Go of de preview).</Text>
        )}

        <View testID="offline-qr-card" style={styles.card}>
          <Text style={styles.cardLabel}>DEEL MET LUISTERAARS</Text>
          <View style={styles.qrWrap}>
            <QRCode value={code} size={200} color="#000000" backgroundColor="#FFFFFF" />
          </View>
          <Text style={styles.meta}>
            Luisteraars scannen dit in de offline modus en kiezen hetzelfde nummer op hun gsm.
            {wifi ? " Zelfde wifi of hotspot = bediening door de beheerder." : ""}
          </Text>
          <Pressable
            testID="offline-share-code"
            onPress={() => Share.share({ message: code }).catch(() => {})}
            style={({ pressed }) => [styles.secondary, pressed && styles.pressed]}
          >
            <Ionicons name="share-outline" size={18} color={colors.onSurface} />
            <Text style={styles.secondaryLabel}>Deel code als tekst</Text>
          </Pressable>
          <Text testID="offline-code-text" selectable style={styles.codeText} numberOfLines={3}>
            {code}
          </Text>
        </View>

        <Pressable testID="offline-stop" onPress={onLeave} style={({ pressed }) => [styles.leave, pressed && styles.pressed]}>
          <Ionicons name="exit-outline" size={18} color={colors.error} />
          <Text style={styles.leaveLabel}>Sessie verlaten</Text>
        </Pressable>
      </ScrollView>
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    paddingHorizontal: spacing.sm,
    paddingBottom: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: c.divider,
  },
  iconBtn: { width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  kicker: { color: c.accent, fontFamily: fonts.displaySemi, fontSize: 12, letterSpacing: 1.5 },
  title: { color: c.onSurface, fontFamily: fonts.display, fontSize: 22 },
  content: { padding: spacing.lg, gap: spacing.md },
  conn: { flexDirection: "row", alignItems: "center", gap: spacing.sm, justifyContent: "center" },
  connText: { color: c.onSurface, fontFamily: fonts.displaySemi, fontSize: 12, letterSpacing: 1 },
  card: {
    padding: spacing.lg,
    borderRadius: radius.lg,
    backgroundColor: c.surfaceSecondary,
    borderWidth: 1,
    borderColor: c.border,
    gap: spacing.sm,
  },
  status: { color: c.accent, fontFamily: fonts.display, fontSize: 28, letterSpacing: 1 },
  time: { color: c.onSurface, fontFamily: fonts.display, fontSize: 44 },
  track: { height: 4, borderRadius: 2, backgroundColor: c.border, overflow: "hidden" },
  fill: { height: 4, backgroundColor: c.accent },
  metaRow: { flexDirection: "row", justifyContent: "space-between", gap: spacing.sm },
  meta: { color: c.muted, fontFamily: fonts.text, fontSize: 12 },
  metaCenter: { color: c.muted, fontFamily: fonts.text, fontSize: 12, textAlign: "center", lineHeight: 17 },
  ctrlLabel: { color: c.muted, fontFamily: fonts.displaySemi, fontSize: 11, letterSpacing: 2, textAlign: "center", marginTop: spacing.xs },
  controls: { flexDirection: "row", gap: spacing.sm },
  ctrl: {
    flex: 1,
    height: 72,
    borderRadius: radius.lg,
    backgroundColor: c.surfaceSecondary,
    borderWidth: 1,
    borderColor: c.borderStrong,
    alignItems: "center",
    justifyContent: "center",
    gap: 2,
  },
  ctrlOn: { backgroundColor: c.accent, borderColor: c.accent },
  ctrlText: { color: c.onSurface, fontFamily: fonts.displaySemi, fontSize: 13, letterSpacing: 1.5 },
  switchRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    padding: spacing.lg,
    borderRadius: radius.lg,
    backgroundColor: c.surfaceSecondary,
    borderWidth: 1,
    borderColor: c.border,
  },
  switchLabel: { color: c.onSurface, fontFamily: fonts.textSemi, fontSize: 15 },
  switchTrack: { width: 48, height: 28, borderRadius: 14, backgroundColor: c.borderStrong, padding: 3 },
  switchTrackOn: { backgroundColor: c.accent },
  switchKnob: { width: 22, height: 22, borderRadius: 11, backgroundColor: c.onSurface },
  switchKnobOn: { transform: [{ translateX: 20 }], backgroundColor: c.onAccent },
  syncNow: {
    height: 48,
    borderRadius: radius.md,
    backgroundColor: c.accent,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
  },
  syncNowLabel: { color: c.onAccent, fontFamily: fonts.displaySemi, fontSize: 16, letterSpacing: 2 },
  cardLabel: {
    color: c.onSurface,
    fontFamily: fonts.displaySemi,
    fontSize: 13,
    letterSpacing: 2,
    borderLeftWidth: 3,
    borderLeftColor: c.accent,
    paddingLeft: spacing.sm,
  },
  peerRow: { flexDirection: "row", alignItems: "center", gap: spacing.sm },
  peerName: { flex: 1, color: c.onSurface, fontFamily: fonts.textMedium, fontSize: 14 },
  qrWrap: { alignSelf: "center", padding: spacing.md, backgroundColor: "#FFFFFF", borderRadius: radius.md, marginVertical: spacing.sm },
  secondary: {
    height: 48,
    borderRadius: radius.md,
    backgroundColor: c.surfaceTertiary,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
  },
  secondaryLabel: { color: c.onSurface, fontFamily: fonts.textSemi, fontSize: 15 },
  codeText: { color: c.muted, fontFamily: fonts.text, fontSize: 11 },
  leave: { height: 48, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: spacing.sm },
  leaveLabel: { color: c.error, fontFamily: fonts.textSemi, fontSize: 15 },
  pressed: { opacity: 0.7 },
}));
