import { useLocalSearchParams } from "expo-router";
import { useCallback, useEffect, useState } from "react";

import { apiFetch } from "@/src/api";
import { JoinGate, PASSWORD_REQUIRED } from "@/src/components/join-gate";
import { LoadingView, SyncPlayer } from "@/src/components/sync-player";
import { fetchAndCacheSong, getLibrarySong, LibrarySong, prepareTracks } from "@/src/library";

export default function Player() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const songId = String(id).toUpperCase();
  const [song, setSong] = useState<LibrarySong | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [needPassword, setNeedPassword] = useState(false);

  const load = useCallback(async () => {
    setLoadError(null);
    setNeedPassword(false);
    const local = await getLibrarySong(songId);
    // Check access online first (password gate); offline we fall back to the local copy
    try {
      await apiFetch(`/songs/${songId}`, {}, 6000);
    } catch (e: any) {
      if (e?.message === PASSWORD_REQUIRED) return setNeedPassword(true);
      if (!local) return setLoadError(e?.status === 404 ? "Nummer niet gevonden" : "Kan niet verbinden met de cloud.");
    }
    if (local) {
      await prepareTracks([local]);
      return setSong(local);
    }
    try {
      const s = await fetchAndCacheSong(songId);
      await prepareTracks([s]);
      setSong(s);
    } catch (e: any) {
      setLoadError(e?.status === 404 ? "Nummer niet gevonden" : "Kan niet verbinden met de cloud.");
    }
  }, [songId]);

  useEffect(() => {
    load();
  }, [load]);

  if (needPassword) return <JoinGate kind="songs" id={songId} onJoined={load} />;
  if (!song) return <LoadingView error={loadError} onRetry={load} />;
  return <SyncPlayer kind="songs" sessionId={song.song_id} title={song.title} tracks={[song]} ownerHint={song.isOwner} />;
}
