import { useLocalSearchParams } from "expo-router";
import { useCallback, useEffect, useRef, useState } from "react";

import { apiFetch } from "@/src/api";
import { JoinGate, PASSWORD_REQUIRED } from "@/src/components/join-gate";
import { LoadingView, SyncPlayer } from "@/src/components/sync-player";
import { fetchAndCacheSong, getLibrarySong, LibrarySong, prepareTracks, upsertPlaylist } from "@/src/library";
import { useToast } from "@/src/toast";

type PlaylistMeta = { playlist_id: string; title: string; is_owner: boolean; items: { song_id: string }[] };

export default function PlaylistScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const pid = String(id).toUpperCase();
  const toast = useToast();
  const [meta, setMeta] = useState<PlaylistMeta | null>(null);
  const [tracks, setTracks] = useState<LibrarySong[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const itemsRef = useRef("");
  const [needPassword, setNeedPassword] = useState(false);

  const load = useCallback(async () => {
    setError(null);
    setNeedPassword(false);
    try {
      const m = await apiFetch<PlaylistMeta>(`/playlists/${pid}`);
      // Download every song so the whole queue also plays offline
      const list: LibrarySong[] = [];
      for (const it of m.items) list.push((await getLibrarySong(it.song_id)) ?? (await fetchAndCacheSong(it.song_id)));
      itemsRef.current = m.items.map((i) => i.song_id).join(",");
      await upsertPlaylist({ playlist_id: m.playlist_id, title: m.title, count: list.length });
      await prepareTracks(list);
      setMeta(m);
      setTracks(list);
    } catch (e: any) {
      if (e?.message === PASSWORD_REQUIRED) return setNeedPassword(true);
      setError(e?.status === 404 ? "Afspeellijst niet gevonden" : "Kan niet verbinden met de cloud.");
    }
  }, [pid]);

  useEffect(() => {
    load();
  }, [load]);

  const onItems = useCallback(
    (items: string[]) => {
      if (items.join(",") !== itemsRef.current) load();
    },
    [load],
  );

  const onAddSong = useCallback(
    async (songId: string) => {
      try {
        await apiFetch(`/playlists/${pid}/items`, { method: "POST", body: JSON.stringify({ song_id: songId }) });
        toast.show(`${songId} toegevoegd aan de wachtrij`, "success");
        await load();
      } catch (e: any) {
        toast.show(e?.status === 404 ? "Nummer niet gevonden" : e?.message ?? "Toevoegen mislukt", "error");
      }
    },
    [pid, load, toast],
  );

  const onReorder = useCallback(
    async (order: number[]) => {
      try {
        await apiFetch(`/playlists/${pid}/items`, { method: "PUT", body: JSON.stringify({ order }) });
        await load();
      } catch (e: any) {
        toast.show(e?.status === 403 ? "Je hebt geen beheer over deze lijst" : e?.message ?? "Wijzigen mislukt", "error");
      }
    },
    [pid, load, toast],
  );

  if (needPassword) return <JoinGate kind="playlists" id={pid} onJoined={load} />;
  if (!meta || !tracks?.length) return <LoadingView error={error} onRetry={load} />;
  return (
    <SyncPlayer
      kind="playlists"
      sessionId={meta.playlist_id}
      title={meta.title}
      tracks={tracks}
      ownerHint={meta.is_owner}
      onItems={onItems}
      onAddSong={onAddSong}
      onReorder={onReorder}
    />
  );
}
