import * as AppleAuthentication from "expo-apple-authentication";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import { ActivityIndicator, Platform, Pressable, Text, View } from "react-native";
import Animated, { FadeInDown } from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAuth } from "@/src/auth";
import { HowItWorks } from "@/src/components/how-it-works";
import { LogoMark } from "@/src/components/logo";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";
import { useToast } from "@/src/toast";

export default function Login() {
  const styles = useStyles();
  const { colors } = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { signInWithApple, signInAsGuest } = useAuth();
  const toast = useToast();
  const [appleAvailable, setAppleAvailable] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (Platform.OS === "ios") {
      AppleAuthentication.isAvailableAsync().then(setAppleAvailable).catch(() => setAppleAvailable(false));
    }
  }, []);

  const onApple = async () => {
    setError(null);
    try {
      const cred = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });
      if (!cred.identityToken) throw new Error("Geen token ontvangen");
      setBusy(true);
      const fullName = [cred.fullName?.givenName, cred.fullName?.familyName].filter(Boolean).join(" ") || null;
      await signInWithApple(cred.identityToken, fullName, cred.email);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (e: any) {
      if (e?.code === "ERR_REQUEST_CANCELED") return;
      setError("Aanmelden mislukt. Probeer opnieuw.");
      toast.show(e?.message ?? "Aanmelden mislukt", "error");
    } finally {
      setBusy(false);
    }
  };

  const onGuest = async () => {
    setError(null);
    setBusy(true);
    try {
      await signInAsGuest();
      Haptics.selectionAsync();
    } catch {
      setError("Kan niet verbinden met de cloud. Probeer opnieuw.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <View style={[styles.root, { paddingTop: insets.top + spacing.xl, paddingBottom: insets.bottom + spacing.lg }]}>
      <Animated.View entering={FadeInDown.duration(500)} style={styles.brand}>
        <View style={styles.markRow}>
          <LogoMark size={88} animated />
          <Text testID="login-abbr" style={styles.abbr}>
            SM<Text style={{ color: colors.accent }}>Q</Text>
          </Text>
        </View>
        <Text testID="login-wordmark" style={styles.wordmark}>
          SyncMy<Text style={{ color: colors.accent }}>Que</Text>
        </Text>
        <Text style={styles.tagline}>Synchroniseer hier jouw muziek. De app maakt gebruik van UTC-tijd</Text>
        <View style={styles.lineRow}>
          <View style={styles.dot} />
          <Text style={styles.lineText}>UTC · ±ms PRECISIE · OFFLINE</Text>
        </View>
      </Animated.View>

      <Animated.View entering={FadeInDown.delay(100).duration(500)}>
        <HowItWorks />
      </Animated.View>

      <Animated.View entering={FadeInDown.delay(150).duration(500)} style={styles.actions}>
        {error && (
          <Text testID="login-error" style={styles.error}>
            {error}
          </Text>
        )}
        {busy && <ActivityIndicator testID="login-loading" color={colors.onSurface} style={{ marginBottom: spacing.md }} />}
        {appleAvailable && (
          <AppleAuthentication.AppleAuthenticationButton
            testID="apple-signin-button"
            buttonType={AppleAuthentication.AppleAuthenticationButtonType.SIGN_IN}
            buttonStyle={AppleAuthentication.AppleAuthenticationButtonStyle.WHITE}
            cornerRadius={radius.md}
            style={styles.appleBtn}
            onPress={onApple}
          />
        )}
        {!appleAvailable && Platform.OS === "ios" ? null : null}
        <Pressable
          testID="guest-login-button"
          disabled={busy}
          onPress={onGuest}
          style={({ pressed }) => [appleAvailable ? styles.guestText : styles.guestBtn, pressed && { opacity: 0.6 }]}
        >
          <Text style={appleAvailable ? styles.guestLabel : styles.guestBtnLabel}>Doorgaan als gast</Text>
        </Pressable>
        {!appleAvailable && (
          <Text style={styles.hint}>Aanmelden met Apple is beschikbaar op iPhone.</Text>
        )}
        <Pressable testID="login-offline-button" onPress={() => router.push("/offline")} style={styles.offlineLink} hitSlop={6}>
          <Text style={styles.offlineLinkText}>
            Offline modus <Text style={{ color: colors.accent }}>· zonder server</Text>
          </Text>
        </Pressable>
        <Text testID="login-credits" style={styles.credits}>
          Ontwikkeld door Jörn De Smedt{"\n"}Zonder winstgevende doeleinden zal gebruikt worden.
        </Text>
      </Animated.View>
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface, paddingHorizontal: spacing.xl, justifyContent: "space-between", gap: spacing.lg },
  brand: { gap: spacing.xs },
  markRow: { flexDirection: "row", alignItems: "center", gap: spacing.lg },
  abbr: { color: c.onSurface, fontFamily: fonts.display, fontSize: 64, letterSpacing: 4, lineHeight: 70 },
  offlineLink: { height: 40, alignItems: "center", justifyContent: "center" },
  offlineLinkText: { color: c.onSurface, fontFamily: fonts.textSemi, fontSize: 14 },
  credits: { color: c.muted, fontFamily: fonts.text, fontSize: 11, lineHeight: 16, textAlign: "center", marginTop: spacing.xs },
  wordmark: { color: c.onSurface, fontFamily: fonts.display, fontSize: 52, letterSpacing: 1, lineHeight: 58, marginTop: spacing.md },
  tagline: { color: c.onSurface, fontFamily: fonts.text, fontSize: 16 },
  lineRow: { flexDirection: "row", alignItems: "center", gap: spacing.sm, marginTop: spacing.md },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: c.accent },
  lineText: { color: c.muted, fontFamily: fonts.displaySemi, fontSize: 14, letterSpacing: 2 },
  actions: { gap: spacing.md },
  appleBtn: { width: "100%", height: 52 },
  guestBtn: {
    height: 52,
    borderRadius: radius.md,
    backgroundColor: c.accent,
    alignItems: "center",
    justifyContent: "center",
  },
  guestBtnLabel: { color: c.onAccent, fontFamily: fonts.textSemi, fontSize: 16 },
  guestText: { height: 48, alignItems: "center", justifyContent: "center" },
  guestLabel: { color: c.onSurface, fontFamily: fonts.textMedium, fontSize: 15 },
  hint: { color: c.muted, fontFamily: fonts.text, fontSize: 12, textAlign: "center" },
  error: { color: c.error, fontFamily: fonts.textMedium, fontSize: 14, textAlign: "center" },
}));
