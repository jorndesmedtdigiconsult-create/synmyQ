"""JynQue backend API tests - auth, songs, sync state."""
import os
import time
import pytest
import requests

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL", "https://jynque-sync.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"
TONE_PATH = "/tmp/tone.wav"


# ---------- Profile name update ----------
class TestProfileName:
    def test_patch_me_updates_name(self):
        tok = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
        h = {"Authorization": f"Bearer {tok}"}
        r = requests.patch(f"{API}/auth/me", headers=h, json={"name": "  Test  User  "}, timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert d["name"] == "Test User"  # whitespace collapsed
        # verify persisted via GET
        g = requests.get(f"{API}/auth/me", headers=h, timeout=10).json()
        assert g["name"] == "Test User"

    def test_patch_me_empty_400(self):
        tok = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
        h = {"Authorization": f"Bearer {tok}"}
        r = requests.patch(f"{API}/auth/me", headers=h, json={"name": "   "}, timeout=10)
        assert r.status_code == 400

    def test_patch_me_requires_auth(self):
        r = requests.patch(f"{API}/auth/me", json={"name": "Someone"}, timeout=10)
        assert r.status_code == 401


# ---------- Remote volume ----------
class TestVolume:
    def _upload(self, headers):
        with open(TONE_PATH, "rb") as f:
            r = requests.post(f"{API}/songs/upload", headers=headers,
                              files={"file": ("tone.wav", f, "audio/wav")}, timeout=180)
        assert r.status_code == 200
        return r.json()

    def test_owner_sets_volume_no_version_bump(self):
        tok = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
        h = {"Authorization": f"Bearer {tok}"}
        song = self._upload(h)
        sid = song["song_id"]
        st0 = requests.get(f"{API}/songs/{sid}/state", headers=h, timeout=10).json()
        v0 = st0["version"]
        r = requests.post(f"{API}/songs/{sid}/volume", headers=h, json={"volume": 0.4}, timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert d["volume"] == 0.4
        # Version MUST NOT be incremented
        assert d["version"] == v0, f"volume bumped version from {v0} to {d['version']}"
        # verify persistence
        g = requests.get(f"{API}/songs/{sid}/state", headers=h, timeout=10).json()
        assert g["volume"] == 0.4
        assert g["version"] == v0

    def test_non_controller_cannot_set_volume_403(self):
        tok = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
        h = {"Authorization": f"Bearer {tok}"}
        song = self._upload(h)
        tok2 = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
        h2 = {"Authorization": f"Bearer {tok2}", "X-Device-Id": "dev_vol_other"}
        r = requests.post(f"{API}/songs/{song['song_id']}/volume", headers=h2,
                          json={"volume": 0.5}, timeout=10)
        assert r.status_code == 403

    def test_volume_clamped_to_0_1(self):
        tok = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
        h = {"Authorization": f"Bearer {tok}"}
        song = self._upload(h)
        sid = song["song_id"]
        hi = requests.post(f"{API}/songs/{sid}/volume", headers=h, json={"volume": 5.0}, timeout=10)
        assert hi.status_code == 200
        assert hi.json()["volume"] == 1.0
        lo = requests.post(f"{API}/songs/{sid}/volume", headers=h, json={"volume": -2.0}, timeout=10)
        assert lo.status_code == 200
        assert lo.json()["volume"] == 0.0

    def test_presence_response_includes_volume(self):
        tok = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
        h = {"Authorization": f"Bearer {tok}"}
        song = self._upload(h)
        sid = song["song_id"]
        requests.post(f"{API}/songs/{sid}/volume", headers=h, json={"volume": 0.6}, timeout=10)
        r = requests.post(f"{API}/songs/{sid}/presence", headers=h,
                          json={"device_id": "dev_vol_p", "name": "Owner",
                                "drift_ms": 0, "in_sync": True, "playing": False}, timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert "volume" in d
        assert d["volume"] == 0.6

    def test_volume_requires_auth(self):
        tok = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
        h = {"Authorization": f"Bearer {tok}"}
        song = self._upload(h)
        r = requests.post(f"{API}/songs/{song['song_id']}/volume", json={"volume": 0.3}, timeout=10)
        assert r.status_code == 401


@pytest.fixture(scope="module")
def guest_token():
    r = requests.post(f"{API}/auth/guest", timeout=30)
    assert r.status_code == 200, r.text
    data = r.json()
    assert "session_token" in data and "user_id" in data
    return data["session_token"]


@pytest.fixture(scope="module")
def auth_headers(guest_token):
    return {"Authorization": f"Bearer {guest_token}"}


@pytest.fixture(scope="module")
def uploaded_song(auth_headers):
    with open(TONE_PATH, "rb") as f:
        files = {"file": ("tone.wav", f, "audio/wav")}
        r = requests.post(f"{API}/songs/upload", headers=auth_headers, files=files, timeout=180)
    assert r.status_code == 200, r.text
    data = r.json()
    assert len(data["song_id"]) == 6
    return data


# ---------- Time ----------
class TestTime:
    def test_time_server_ms(self):
        r = requests.get(f"{API}/time", timeout=10)
        assert r.status_code == 200
        data = r.json()
        assert "server_ms" in data
        assert isinstance(data["server_ms"], int)
        # within 60s of local
        assert abs(data["server_ms"] - int(time.time() * 1000)) < 60000


# ---------- Auth ----------
class TestAuth:
    def test_guest_login_returns_token(self):
        r = requests.post(f"{API}/auth/guest", timeout=30)
        assert r.status_code == 200
        d = r.json()
        assert d["user_id"].startswith("guest_")
        assert len(d["session_token"]) > 10

    def test_multiple_guests_distinct(self):
        a = requests.post(f"{API}/auth/guest", timeout=30).json()
        b = requests.post(f"{API}/auth/guest", timeout=30).json()
        assert a["user_id"] != b["user_id"]
        assert a["session_token"] != b["session_token"]

    def test_me_without_token_401(self):
        r = requests.get(f"{API}/auth/me", timeout=10)
        assert r.status_code == 401

    def test_me_with_bearer(self, auth_headers):
        r = requests.get(f"{API}/auth/me", headers=auth_headers, timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert d["is_guest"] is True
        assert d["user_id"].startswith("guest_")

    def test_logout_invalidates(self):
        tok = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
        h = {"Authorization": f"Bearer {tok}"}
        assert requests.get(f"{API}/auth/me", headers=h, timeout=10).status_code == 200
        r = requests.post(f"{API}/auth/logout", headers=h, timeout=10)
        assert r.status_code == 200
        assert requests.get(f"{API}/auth/me", headers=h, timeout=10).status_code == 401

    def test_apple_invalid_token_401(self):
        r = requests.post(f"{API}/auth/apple", json={"identity_token": "not-a-real-token"}, timeout=15)
        assert r.status_code == 401


# ---------- Songs ----------
class TestSongs:
    def test_upload_requires_auth(self):
        with open(TONE_PATH, "rb") as f:
            r = requests.post(f"{API}/songs/upload", files={"file": ("tone.wav", f, "audio/wav")}, timeout=60)
        assert r.status_code == 401

    def test_upload_and_metadata(self, uploaded_song, auth_headers):
        sid = uploaded_song["song_id"]
        assert len(sid) == 6
        assert uploaded_song["size"] > 0
        r = requests.get(f"{API}/songs/{sid}", headers=auth_headers, timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert d["song_id"] == sid
        assert d["size"] == uploaded_song["size"]

    def test_song_lookup_case_insensitive(self, uploaded_song, auth_headers):
        sid = uploaded_song["song_id"].lower()
        r = requests.get(f"{API}/songs/{sid}", headers=auth_headers, timeout=10)
        assert r.status_code == 200

    def test_unknown_song_404(self, auth_headers):
        r = requests.get(f"{API}/songs/ZZZZZZ", headers=auth_headers, timeout=10)
        assert r.status_code == 404

    def test_download_file_bearer(self, uploaded_song, auth_headers):
        r = requests.get(f"{API}/songs/{uploaded_song['song_id']}/file", headers=auth_headers, timeout=60)
        assert r.status_code == 200
        assert len(r.content) == uploaded_song["size"]
        assert r.headers.get("Content-Type", "").startswith("audio/")

    def test_download_file_query_token_rejected(self, uploaded_song, guest_token):
        # Veilige downloads: ?token= must NO LONGER be accepted.
        r = requests.get(f"{API}/songs/{uploaded_song['song_id']}/file?token={guest_token}", timeout=60)
        assert r.status_code == 401

    def test_download_file_no_auth(self, uploaded_song):
        r = requests.get(f"{API}/songs/{uploaded_song['song_id']}/file", timeout=10)
        assert r.status_code == 401


# ---------- Sync state ----------
class TestSyncState:
    def test_initial_state_stopped(self, uploaded_song, auth_headers):
        r = requests.get(f"{API}/songs/{uploaded_song['song_id']}/state", headers=auth_headers, timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert d["status"] == "stopped"
        assert d["start_at_ms"] is None
        assert "server_ms" in d

    def test_start_sets_playing_with_lead(self, uploaded_song, auth_headers):
        sid = uploaded_song["song_id"]
        before = int(time.time() * 1000)
        r = requests.post(f"{API}/songs/{sid}/start", headers=auth_headers, timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert d["status"] == "playing"
        assert d["start_at_ms"] is not None
        # lead ~5000ms (new countdown lead)
        lead = d["start_at_ms"] - before
        assert 3500 < lead < 7000, f"lead was {lead}ms"
        assert d["version"] >= 1
        v1 = d["version"]
        # start again increments version
        r2 = requests.post(f"{API}/songs/{sid}/start", headers=auth_headers, timeout=10)
        assert r2.json()["version"] > v1

    def test_state_persists(self, uploaded_song, auth_headers):
        sid = uploaded_song["song_id"]
        r = requests.get(f"{API}/songs/{sid}/state", headers=auth_headers, timeout=10)
        assert r.json()["status"] == "playing"

    def test_stop_resets(self, uploaded_song, auth_headers):
        sid = uploaded_song["song_id"]
        r = requests.post(f"{API}/songs/{sid}/stop", headers=auth_headers, timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert d["status"] == "stopped"
        assert d["start_at_ms"] is None
        # verify via GET
        g = requests.get(f"{API}/songs/{sid}/state", headers=auth_headers, timeout=10).json()
        assert g["status"] == "stopped"
        assert g["start_at_ms"] is None


# ---------- Ownership / Control ----------
class TestOwnership:
    def test_song_metadata_includes_owner_fields(self, uploaded_song, auth_headers):
        sid = uploaded_song["song_id"]
        r = requests.get(f"{API}/songs/{sid}", headers=auth_headers, timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert "owner_id" in d and d["owner_id"].startswith("guest_")
        assert d["is_owner"] is True

    def test_other_guest_is_not_owner(self, uploaded_song, auth_headers):
        # Owner reveals the password, guest joins, then can see metadata
        pw = requests.get(f"{API}/songs/{uploaded_song['song_id']}/password",
                          headers=auth_headers, timeout=10).json()["password"]
        tok = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
        h = {"Authorization": f"Bearer {tok}"}
        # Without joining -> 403 WACHTWOORD_VEREIST
        rb = requests.get(f"{API}/songs/{uploaded_song['song_id']}", headers=h, timeout=10)
        assert rb.status_code == 403
        assert rb.json()["detail"] == "WACHTWOORD_VEREIST"
        # Join with correct password
        jr = requests.post(f"{API}/songs/{uploaded_song['song_id']}/join",
                           headers=h, json={"password": pw}, timeout=10)
        assert jr.status_code == 200
        r = requests.get(f"{API}/songs/{uploaded_song['song_id']}", headers=h, timeout=10)
        assert r.status_code == 200
        assert r.json()["is_owner"] is False

    def test_non_owner_cannot_start(self, uploaded_song):
        tok = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
        h = {"Authorization": f"Bearer {tok}", "X-Device-Id": "dev_nonowner_a"}
        r = requests.post(f"{API}/songs/{uploaded_song['song_id']}/start", headers=h, timeout=10)
        assert r.status_code == 403
        assert "beheer" in r.json().get("detail", "").lower()

    def test_non_owner_cannot_stop(self, uploaded_song):
        tok = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
        h = {"Authorization": f"Bearer {tok}", "X-Device-Id": "dev_nonowner_b"}
        r = requests.post(f"{API}/songs/{uploaded_song['song_id']}/stop", headers=h, timeout=10)
        assert r.status_code == 403

    def test_start_requires_auth(self, uploaded_song):
        r = requests.post(f"{API}/songs/{uploaded_song['song_id']}/start", timeout=10)
        assert r.status_code == 401


# ---------- Start/Pause/Stop/Loop lifecycle ----------
@pytest.fixture
def fresh_song(auth_headers):
    """Upload a dedicated song per test class instance to avoid state bleed."""
    with open(TONE_PATH, "rb") as f:
        files = {"file": ("tone.wav", f, "audio/wav")}
        r = requests.post(f"{API}/songs/upload", headers=auth_headers, files=files, timeout=180)
    assert r.status_code == 200
    return r.json()


class TestLifecycle:
    def test_start_sets_lead_and_loop_default(self, fresh_song, auth_headers):
        sid = fresh_song["song_id"]
        before = int(time.time() * 1000)
        r = requests.post(f"{API}/songs/{sid}/start",
                          headers=auth_headers, json={"duration_ms": 30000}, timeout=10)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["status"] == "playing"
        assert d["loop"] is True
        assert d["gap_s"] == 5
        assert d["track_gap_s"] == 5
        assert d["duration_ms"] == 30000
        lead = d["start_at_ms"] - before
        assert 3500 < lead < 7000, f"lead={lead}"
        assert d["start_at_ms"] == d["resume_at_ms"]

    def test_pause_then_resume(self, fresh_song, auth_headers):
        sid = fresh_song["song_id"]
        # start
        requests.post(f"{API}/songs/{sid}/start", headers=auth_headers,
                      json={"duration_ms": 30000}, timeout=10)
        # let play begin (lead is now 5s) and a bit of audible time elapse
        time.sleep(6.5)
        r = requests.post(f"{API}/songs/{sid}/pause", headers=auth_headers, timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert d["status"] == "paused"
        assert d["paused_pos_ms"] > 0
        paused_pos = d["paused_pos_ms"]

        before = int(time.time() * 1000)
        r2 = requests.post(f"{API}/songs/{sid}/start", headers=auth_headers, timeout=10)
        assert r2.status_code == 200
        d2 = r2.json()
        assert d2["status"] == "playing"
        # resume lead ~5000ms (new resume countdown)
        lead = d2["resume_at_ms"] - before
        assert 3500 < lead < 7000, f"resume lead={lead}"
        # start_at_ms = resume_at_ms - paused_pos_ms (within small tolerance)
        assert abs((d2["resume_at_ms"] - d2["start_at_ms"]) - paused_pos) < 50

    def test_stop_resets_paused_pos(self, fresh_song, auth_headers):
        sid = fresh_song["song_id"]
        requests.post(f"{API}/songs/{sid}/start", headers=auth_headers,
                      json={"duration_ms": 30000}, timeout=10)
        time.sleep(6.0)
        requests.post(f"{API}/songs/{sid}/pause", headers=auth_headers, timeout=10)
        r = requests.post(f"{API}/songs/{sid}/stop", headers=auth_headers, timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert d["status"] == "stopped"
        assert d["paused_pos_ms"] == 0
        assert d["start_at_ms"] is None

    def test_loop_always_true(self, fresh_song, auth_headers):
        sid = fresh_song["song_id"]
        # Loop is forced true regardless of request body
        r = requests.post(f"{API}/songs/{sid}/loop", headers=auth_headers,
                         json={"loop": False}, timeout=10)
        assert r.status_code == 200
        assert r.json()["loop"] is True
        r2 = requests.post(f"{API}/songs/{sid}/loop", headers=auth_headers,
                          json={"loop": True}, timeout=10)
        assert r2.json()["loop"] is True

    def test_non_controller_cannot_loop(self, fresh_song):
        tok = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
        h = {"Authorization": f"Bearer {tok}", "X-Device-Id": "dev_other"}
        r = requests.post(f"{API}/songs/{fresh_song['song_id']}/loop",
                          headers=h, json={"loop": False}, timeout=10)
        assert r.status_code == 403


# ---------- Control transfer ----------
class TestControlTransfer:
    def test_owner_transfers_to_device_then_reclaims(self, fresh_song, auth_headers, guest_token):
        sid = fresh_song["song_id"]
        # second guest, with device id. New SEC-001 rule: target device must send presence
        # from its own authenticated session before control can be transferred to it.
        tok2 = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
        dev2 = "dev_guest2_abcd"
        owner_dev = "dev_owner_zzzz"
        h_other = {"Authorization": f"Bearer {tok2}", "X-Device-Id": dev2}

        # Owner reveals password; guest joins to become a member and send presence
        pw = requests.get(f"{API}/songs/{sid}/password", headers=auth_headers, timeout=10).json()["password"]
        assert requests.post(f"{API}/songs/{sid}/join", headers=h_other,
                             json={"password": pw}, timeout=10).status_code == 200
        assert requests.post(f"{API}/songs/{sid}/presence", headers=h_other,
                             json={"device_id": dev2, "name": "Guest Two Phone",
                                   "drift_ms": 0, "in_sync": True, "playing": False},
                             timeout=10).status_code == 200

        # owner transfers control to dev2
        r = requests.post(f"{API}/songs/{sid}/control", headers=auth_headers,
                          json={"device_id": dev2, "name": "Guest Two Phone"}, timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert d["controller_device_id"] == dev2
        assert d["controller_name"] == "Guest Two Phone"

        # dev2 can now start
        rs = requests.post(f"{API}/songs/{sid}/start", headers=h_other,
                           json={"duration_ms": 30000}, timeout=10)
        assert rs.status_code == 200
        assert rs.json()["status"] == "playing"

        # owner's other device (different X-Device-Id) is NOT allowed while controller is set to dev2
        h_owner_other = {"Authorization": f"Bearer {guest_token}", "X-Device-Id": owner_dev}
        r_blk = requests.post(f"{API}/songs/{sid}/pause", headers=h_owner_other, timeout=10)
        assert r_blk.status_code == 403

        # but owner can always reclaim via /control. Target device_id must be bound
        # to an authenticated presence (SEC-001) or match the request's X-Device-Id.
        rc = requests.post(f"{API}/songs/{sid}/control", headers=h_owner_other,
                           json={"device_id": owner_dev, "name": "Owner Phone"}, timeout=10)
        assert rc.status_code == 200
        assert rc.json()["controller_device_id"] == owner_dev

        # dev2 can no longer control after reclaim
        r_blk2 = requests.post(f"{API}/songs/{sid}/stop", headers=h_other, timeout=10)
        assert r_blk2.status_code == 403

        # owner (new device) can stop
        rst = requests.post(f"{API}/songs/{sid}/stop", headers=h_owner_other, timeout=10)
        assert rst.status_code == 200

    def test_non_owner_non_controller_cannot_transfer(self, fresh_song):
        tok = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
        h = {"Authorization": f"Bearer {tok}", "X-Device-Id": "dev_random"}
        r = requests.post(f"{API}/songs/{fresh_song['song_id']}/control",
                          headers=h, json={"device_id": "dev_random", "name": "x"}, timeout=10)
        assert r.status_code == 403


# ---------- Presence / listeners ----------
class TestPresence:
    def test_presence_lists_recent_devices(self, fresh_song, auth_headers):
        sid = fresh_song["song_id"]
        # owner presence
        r1 = requests.post(f"{API}/songs/{sid}/presence", headers=auth_headers,
                           json={"device_id": "dev_owner_p", "name": "Owner Web",
                                 "drift_ms": 2, "in_sync": True, "playing": False}, timeout=10)
        assert r1.status_code == 200
        d1 = r1.json()
        assert "listeners" in d1
        own = [x for x in d1["listeners"] if x["device_id"] == "dev_owner_p"]
        assert len(own) == 1
        assert own[0]["is_controller"] is True  # owner, no controller set

        # second guest joins first (new password gate)
        pw = requests.get(f"{API}/songs/{sid}/password", headers=auth_headers, timeout=10).json()["password"]
        tok2 = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
        h2 = {"Authorization": f"Bearer {tok2}"}
        requests.post(f"{API}/songs/{sid}/join", headers=h2, json={"password": pw}, timeout=10)
        # Refresh owner heartbeat (8s TTL could expire due to preview-infra latency)
        requests.post(f"{API}/songs/{sid}/presence", headers=auth_headers,
                      json={"device_id": "dev_owner_p", "name": "Owner Web",
                            "drift_ms": 2, "in_sync": True, "playing": False}, timeout=10)
        r2 = requests.post(f"{API}/songs/{sid}/presence", headers=h2,
                           json={"device_id": "dev_g2_p", "name": "Guest2",
                                 "drift_ms": 25, "in_sync": True, "playing": True}, timeout=10)
        assert r2.status_code == 200
        ids = {x["device_id"] for x in r2.json()["listeners"]}
        assert "dev_owner_p" in ids and "dev_g2_p" in ids

        # after control transfer, listener flags update
        requests.post(f"{API}/songs/{sid}/control", headers=auth_headers,
                      json={"device_id": "dev_g2_p", "name": "Guest2"}, timeout=10)
        r3 = requests.post(f"{API}/songs/{sid}/presence", headers=auth_headers,
                           json={"device_id": "dev_owner_p", "name": "Owner Web",
                                 "drift_ms": 2, "in_sync": True, "playing": False}, timeout=10)
        listeners = r3.json()["listeners"]
        g2 = [x for x in listeners if x["device_id"] == "dev_g2_p"][0]
        own = [x for x in listeners if x["device_id"] == "dev_owner_p"][0]
        assert g2["is_controller"] is True
        assert own["is_controller"] is False
        # controller listed first due to sort
        assert listeners[0]["is_controller"] is True

    def test_presence_requires_auth(self, fresh_song):
        r = requests.post(f"{API}/songs/{fresh_song['song_id']}/presence",
                          json={"device_id": "dev_x", "name": "x"}, timeout=10)
        assert r.status_code == 401
