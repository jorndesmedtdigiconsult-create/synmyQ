"""Tests for Veilige Downloads (signed links) + Wachtwoord Vernieuwen (rotate/kick)."""
import os
import hmac
import hashlib
import time
import pytest
import requests

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL", "https://jynque-sync.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"
TONE_PATH = "/tmp/tone.wav"
SIGNING_SECRET = b"edf4c37184bb488e82fd51f8db9bb50242121708444d6dc6fe3b3f197c98375d"


def _sign(song_id: str, uid: str, exp: int) -> str:
    return hmac.new(SIGNING_SECRET, f"{song_id}:{uid}:{exp}".encode(), hashlib.sha256).hexdigest()


def _guest():
    r = requests.post(f"{API}/auth/guest", timeout=30).json()
    return r["session_token"], r["user_id"]


def _upload(headers):
    with open(TONE_PATH, "rb") as f:
        r = requests.post(f"{API}/songs/upload", headers=headers,
                          files={"file": ("tone.wav", f, "audio/wav")}, timeout=180)
    assert r.status_code == 200, r.text
    return r.json()


# ---------------- Veilige downloads ----------------
class TestSignedLinks:
    def test_file_link_returns_signed_path(self):
        tok, uid = _guest()
        h = {"Authorization": f"Bearer {tok}"}
        song = _upload(h)
        r = requests.post(f"{API}/songs/{song['song_id']}/file-link", headers=h, timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert "path" in d and "expires_at_ms" in d
        assert d["path"].startswith(f"/api/songs/{song['song_id']}/file?uid=")
        assert "sig=" in d["path"] and "exp=" in d["path"]
        assert "token=" not in d["path"]  # session token must never be in URL

    def test_signed_link_download_200(self):
        tok, uid = _guest()
        h = {"Authorization": f"Bearer {tok}"}
        song = _upload(h)
        link = requests.post(f"{API}/songs/{song['song_id']}/file-link", headers=h, timeout=10).json()
        r = requests.get(f"{BASE_URL}{link['path']}", timeout=60)
        assert r.status_code == 200
        assert len(r.content) == song["size"]

    def test_tampered_sig_401(self):
        tok, uid = _guest()
        h = {"Authorization": f"Bearer {tok}"}
        song = _upload(h)
        exp = int(time.time() * 1000) + 60_000
        bad = "0" * 64
        r = requests.get(f"{API}/songs/{song['song_id']}/file?uid={uid}&exp={exp}&sig={bad}", timeout=10)
        assert r.status_code == 401

    def test_expired_exp_401(self):
        tok, uid = _guest()
        h = {"Authorization": f"Bearer {tok}"}
        song = _upload(h)
        exp = int(time.time() * 1000) - 1000  # already past
        sig = _sign(song["song_id"], uid, exp)
        r = requests.get(f"{API}/songs/{song['song_id']}/file?uid={uid}&exp={exp}&sig={sig}", timeout=10)
        assert r.status_code == 401

    def test_non_member_uid_403(self):
        # Owner uploads
        tok_o, uid_o = _guest()
        h_o = {"Authorization": f"Bearer {tok_o}"}
        song = _upload(h_o)
        # Other guest exists but never joined -> not a member
        _tok, uid_g = _guest()
        exp = int(time.time() * 1000) + 60_000
        sig = _sign(song["song_id"], uid_g, exp)
        r = requests.get(f"{API}/songs/{song['song_id']}/file?uid={uid_g}&exp={exp}&sig={sig}", timeout=10)
        assert r.status_code == 403
        assert r.json()["detail"] == "WACHTWOORD_VEREIST"

    def test_query_token_rejected_401(self):
        tok, _ = _guest()
        h = {"Authorization": f"Bearer {tok}"}
        song = _upload(h)
        r = requests.get(f"{API}/songs/{song['song_id']}/file?token={tok}", timeout=10)
        assert r.status_code == 401

    def test_bearer_member_200(self):
        tok, _ = _guest()
        h = {"Authorization": f"Bearer {tok}"}
        song = _upload(h)
        r = requests.get(f"{API}/songs/{song['song_id']}/file", headers=h, timeout=60)
        assert r.status_code == 200
        assert len(r.content) == song["size"]


# ---------------- Wachtwoord Vernieuwen (rotate) ----------------
class TestRotatePassword:
    def test_owner_can_rotate_old_rejected_new_accepted(self):
        tok_o, _ = _guest()
        h_o = {"Authorization": f"Bearer {tok_o}"}
        song = _upload(h_o)
        sid = song["song_id"]
        old_pw = requests.get(f"{API}/songs/{sid}/password", headers=h_o, timeout=10).json()["password"]
        # rotate
        r = requests.post(f"{API}/songs/{sid}/password/rotate", headers=h_o, timeout=10)
        assert r.status_code == 200
        new_pw = r.json()["password"]
        assert new_pw and new_pw != old_pw
        # new guest tries old password -> 400
        tok_g, _ = _guest()
        h_g = {"Authorization": f"Bearer {tok_g}"}
        r_old = requests.post(f"{API}/songs/{sid}/join", headers=h_g, json={"password": old_pw}, timeout=10)
        assert r_old.status_code == 400
        # new password -> 200
        r_new = requests.post(f"{API}/songs/{sid}/join", headers=h_g, json={"password": new_pw}, timeout=10)
        assert r_new.status_code == 200

    def test_non_owner_non_controller_cannot_rotate_403(self):
        tok_o, _ = _guest()
        h_o = {"Authorization": f"Bearer {tok_o}"}
        song = _upload(h_o)
        sid = song["song_id"]
        tok_g, _ = _guest()
        h_g = {"Authorization": f"Bearer {tok_g}", "X-Device-Id": "dev_rot_x"}
        r = requests.post(f"{API}/songs/{sid}/password/rotate", headers=h_g, timeout=10)
        assert r.status_code == 403


# ---------------- Kick listener ----------------
def _join_and_presence(sid, headers_guest, pw, device_id, name="Guest"):
    hdr = {**headers_guest, "X-Device-Id": device_id}
    assert requests.post(f"{API}/songs/{sid}/join", headers=hdr,
                         json={"password": pw}, timeout=10).status_code == 200
    r = requests.post(f"{API}/songs/{sid}/presence", headers=hdr,
                      json={"device_id": device_id, "name": name,
                            "drift_ms": 0, "in_sync": True, "playing": False}, timeout=10)
    assert r.status_code == 200
    return hdr


class TestKick:
    def test_kick_happy_path(self):
        tok_o, uid_o = _guest()
        h_o = {"Authorization": f"Bearer {tok_o}", "X-Device-Id": "dev_owner_k"}
        song = _upload(h_o)
        sid = song["song_id"]
        pw = requests.get(f"{API}/songs/{sid}/password", headers=h_o, timeout=10).json()["password"]
        tok_g, uid_g = _guest()
        h_g = _join_and_presence(sid, {"Authorization": f"Bearer {tok_g}"}, pw, "dev_victim_1", "Victim")
        # kick
        r = requests.post(f"{API}/songs/{sid}/kick", headers=h_o,
                          json={"device_id": "dev_victim_1"}, timeout=10)
        assert r.status_code == 200
        new_pw = r.json()["password"]
        assert new_pw and new_pw != pw
        # kicked user /state -> 403 WACHTWOORD_VEREIST
        rs = requests.get(f"{API}/songs/{sid}/state", headers=h_g, timeout=10)
        assert rs.status_code == 403
        assert rs.json()["detail"] == "WACHTWOORD_VEREIST"
        # kicked user /presence -> 403 WACHTWOORD_VEREIST
        rp = requests.post(f"{API}/songs/{sid}/presence", headers=h_g,
                           json={"device_id": "dev_victim_1", "name": "Victim",
                                 "drift_ms": 0, "in_sync": True, "playing": False}, timeout=10)
        assert rp.status_code == 403
        assert rp.json()["detail"] == "WACHTWOORD_VEREIST"

    def test_kick_owner_or_self_400(self):
        tok_o, uid_o = _guest()
        h_o = {"Authorization": f"Bearer {tok_o}", "X-Device-Id": "dev_owner_k2"}
        song = _upload(h_o)
        sid = song["song_id"]
        # Owner presence first (so there's a presence row for owner's device)
        requests.post(f"{API}/songs/{sid}/presence", headers=h_o,
                      json={"device_id": "dev_owner_k2", "name": "Owner",
                            "drift_ms": 0, "in_sync": True, "playing": False}, timeout=10)
        # kicking yourself (owner) -> 400
        r = requests.post(f"{API}/songs/{sid}/kick", headers=h_o,
                         json={"device_id": "dev_owner_k2"}, timeout=10)
        assert r.status_code == 400

    def test_kick_unknown_device_404(self):
        tok_o, _ = _guest()
        h_o = {"Authorization": f"Bearer {tok_o}"}
        song = _upload(h_o)
        r = requests.post(f"{API}/songs/{song['song_id']}/kick", headers=h_o,
                         json={"device_id": "dev_does_not_exist"}, timeout=10)
        assert r.status_code == 404

    def test_non_controller_cannot_kick_403(self):
        tok_o, _ = _guest()
        h_o = {"Authorization": f"Bearer {tok_o}"}
        song = _upload(h_o)
        sid = song["song_id"]
        pw = requests.get(f"{API}/songs/{sid}/password", headers=h_o, timeout=10).json()["password"]
        # Victim + attacker
        tok_v, _ = _guest()
        _join_and_presence(sid, {"Authorization": f"Bearer {tok_v}"}, pw, "dev_victim_2", "Victim")
        tok_a, _ = _guest()
        h_a = _join_and_presence(sid, {"Authorization": f"Bearer {tok_a}"}, pw, "dev_attacker", "Attacker")
        r = requests.post(f"{API}/songs/{sid}/kick", headers=h_a,
                         json={"device_id": "dev_victim_2"}, timeout=10)
        assert r.status_code == 403

    def test_kicked_controller_loses_control(self):
        tok_o, uid_o = _guest()
        h_o = {"Authorization": f"Bearer {tok_o}", "X-Device-Id": "dev_owner_kc"}
        song = _upload(h_o)
        sid = song["song_id"]
        pw = requests.get(f"{API}/songs/{sid}/password", headers=h_o, timeout=10).json()["password"]
        tok_g, _ = _guest()
        h_g = _join_and_presence(sid, {"Authorization": f"Bearer {tok_g}"}, pw, "dev_ctl", "Ctrl Guest")
        # transfer control to the guest
        rc = requests.post(f"{API}/songs/{sid}/control", headers=h_o,
                           json={"device_id": "dev_ctl", "name": "Ctrl Guest"}, timeout=10)
        assert rc.status_code == 200
        assert rc.json()["controller_device_id"] == "dev_ctl"
        # kick the controller
        rk = requests.post(f"{API}/songs/{sid}/kick", headers=h_o,
                           json={"device_id": "dev_ctl"}, timeout=10)
        assert rk.status_code == 200
        # state (owner view) must show controller cleared
        st = requests.get(f"{API}/songs/{sid}/state", headers=h_o, timeout=10).json()
        assert st["controller_device_id"] is None
        assert st["controller_name"] is None
