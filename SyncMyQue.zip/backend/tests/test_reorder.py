"""Iteration 7 — PUT /api/playlists/{pid}/items (reorder/remove) + bug regression.

Covers:
- Reorder keeps items/durations updated and current playing song's audible position (same offset).
- Remove non-current item keeps audible position.
- Remove current item -> 5s countdown to next (fade_end_ms set, resume_at_ms ≈ now+5000).
- Invalid order (duplicates, out of range, empty) -> 400.
- Non-controller -> 403.
- BUG regression: /api/songs/{id}/start, /pause, /stop, /loop, /volume must succeed (not /api/start/...).
"""
import os
import time
import pytest
import requests

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL", "https://jynque-sync.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"
TONE_PATH = "/tmp/tone.wav"

SKIP_LEAD_MS = 5000  # server constant; 5s countdown when the current song is removed


def _guest():
    tok = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
    return {"Authorization": f"Bearer {tok}"}


def _upload(h):
    with open(TONE_PATH, "rb") as f:
        r = requests.post(f"{API}/songs/upload", headers=h, files={"file": ("tone.wav", f, "audio/wav")}, timeout=180)
    assert r.status_code == 200, r.text
    return r.json()


@pytest.fixture(scope="module")
def owner():
    h = _guest()
    h["X-Device-Id"] = "dev_owner_reord"
    return h


@pytest.fixture(scope="module")
def three_songs(owner):
    return [_upload(owner)["song_id"] for _ in range(3)]


def _new_playlist(owner, ids, title="R"):
    r = requests.post(f"{API}/playlists", headers=owner, json={"title": title, "items": ids}, timeout=30)
    assert r.status_code == 200, r.text
    return r.json()["playlist_id"]


# ---------- BUG regression: single-song and playlist endpoints never route via /api/start/... ----------
class TestBugUrlShape:
    def test_song_lifecycle_endpoints_200(self, owner):
        sid = _upload(owner)["song_id"]
        # start -> playing, correct URL /api/songs/{id}/start, not /api/start/{id}/start
        r = requests.post(f"{API}/songs/{sid}/start", headers=owner, timeout=10)
        assert r.status_code == 200, f"POST /api/songs/{sid}/start -> {r.status_code} {r.text}"
        assert r.json()["status"] == "playing"
        # pause
        time.sleep(5.5)
        r = requests.post(f"{API}/songs/{sid}/pause", headers=owner, timeout=10)
        assert r.status_code == 200
        assert r.json()["status"] == "paused"
        # resume
        r = requests.post(f"{API}/songs/{sid}/start", headers=owner, timeout=10)
        assert r.status_code == 200
        # stop
        r = requests.post(f"{API}/songs/{sid}/stop", headers=owner, timeout=10)
        assert r.status_code == 200 and r.json()["status"] == "stopped"
        # loop / volume
        assert requests.post(f"{API}/songs/{sid}/loop", headers=owner, json={"loop": False}, timeout=10).status_code == 200
        assert requests.post(f"{API}/songs/{sid}/volume", headers=owner, json={"volume": 0.5}, timeout=10).status_code == 200

    def test_bad_path_api_start_is_404(self, owner):
        """The previously-bugged URL /api/start/<ID>/start must not exist."""
        sid = _upload(owner)["song_id"]
        r = requests.post(f"{API}/start/{sid}/start", headers=owner, timeout=10)
        assert r.status_code == 404, f"/api/start/<id>/start should be 404, got {r.status_code}"

    def test_playlist_lifecycle_endpoints_200(self, owner, three_songs):
        pid = _new_playlist(owner, three_songs, "L")
        for ep in ("start", "pause", "stop"):
            r = requests.post(f"{API}/playlists/{pid}/{ep}", headers=owner, timeout=10)
            assert r.status_code == 200, f"POST /api/playlists/{pid}/{ep} -> {r.status_code}"


# ---------- Reorder/remove ----------
class TestReorder:
    def test_simple_reverse(self, owner, three_songs):
        pid = _new_playlist(owner, three_songs, "rev")
        r = requests.put(f"{API}/playlists/{pid}/items", headers=owner, json={"order": [2, 1, 0]}, timeout=10)
        assert r.status_code == 200, r.text
        d = r.json()
        assert [i for i in d["items"]] == list(reversed(three_songs))
        assert len(d["durations_ms"]) == 3

    def test_remove_one_item_200(self, owner, three_songs):
        pid = _new_playlist(owner, three_songs, "rm")
        r = requests.put(f"{API}/playlists/{pid}/items", headers=owner, json={"order": [0, 2]}, timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert d["items"] == [three_songs[0], three_songs[2]]
        assert len(d["durations_ms"]) == 2

    def test_reorder_while_playing_keeps_position(self, owner, three_songs):
        """Current playing track 0 moved to end: start_at_ms shifts so audible position stays."""
        pid = _new_playlist(owner, three_songs, "mv")
        s = requests.post(f"{API}/playlists/{pid}/start", headers=owner, timeout=10).json()
        start0 = s["start_at_ms"]
        time.sleep(7.0)  # 5s lead + ~2s audible
        before = int(time.time() * 1000)
        # Move track 0 (currently playing) to the end
        r = requests.put(f"{API}/playlists/{pid}/items", headers=owner, json={"order": [1, 2, 0]}, timeout=10)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["status"] == "playing"
        # Track 0 is now at index 2 => offset = 30+5+30+5 = 70s. Audible pos at reorder ≈ 2s.
        # So (now - start_at_ms) should be ≈ 70_000 + 2_000 = 72_000 ms.
        now_elapsed = before - d["start_at_ms"]
        assert 65000 <= now_elapsed <= 78000, f"elapsed since start_at={now_elapsed}, expected ~72000"
        # fade_end_ms should NOT be set (the audible track did not change)
        assert d.get("fade_end_ms") is None or d["fade_end_ms"] < before

    def test_remove_current_track_triggers_5s_countdown(self, owner, three_songs):
        pid = _new_playlist(owner, three_songs, "rmcur")
        requests.post(f"{API}/playlists/{pid}/start", headers=owner, timeout=10)
        time.sleep(7.0)  # playing track 0 for a bit
        before = int(time.time() * 1000)
        # Remove index 0 — the currently playing track
        r = requests.put(f"{API}/playlists/{pid}/items", headers=owner, json={"order": [1, 2]}, timeout=10)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["status"] == "playing"
        assert d["items"] == [three_songs[1], three_songs[2]]
        # resume_at should be ≈ now + 5000 ms
        lead = d["resume_at_ms"] - before
        assert 3500 < lead < 7000, f"resume lead after removing current={lead}"
        # fade_end_ms set (≈ now+1200)
        assert d["fade_end_ms"] is not None
        fade = d["fade_end_ms"] - before
        assert 800 < fade < 2000, f"fade_end offset={fade}"

    def test_invalid_order_empty_400(self, owner, three_songs):
        pid = _new_playlist(owner, three_songs, "e")
        r = requests.put(f"{API}/playlists/{pid}/items", headers=owner, json={"order": []}, timeout=10)
        assert r.status_code == 400

    def test_invalid_order_duplicates_400(self, owner, three_songs):
        pid = _new_playlist(owner, three_songs, "d")
        r = requests.put(f"{API}/playlists/{pid}/items", headers=owner, json={"order": [0, 0, 1]}, timeout=10)
        assert r.status_code == 400

    def test_invalid_order_out_of_range_400(self, owner, three_songs):
        pid = _new_playlist(owner, three_songs, "o")
        r = requests.put(f"{API}/playlists/{pid}/items", headers=owner, json={"order": [0, 1, 7]}, timeout=10)
        assert r.status_code == 400

    def test_non_controller_403(self, owner, three_songs):
        pid = _new_playlist(owner, three_songs, "f")
        other = _guest()
        other["X-Device-Id"] = "dev_other_reorder"
        r = requests.put(f"{API}/playlists/{pid}/items", headers=other, json={"order": [1, 0]}, timeout=10)
        assert r.status_code == 403

    def test_reorder_requires_auth(self, owner, three_songs):
        pid = _new_playlist(owner, three_songs, "a")
        r = requests.put(f"{API}/playlists/{pid}/items", json={"order": [0, 1, 2]}, timeout=10)
        assert r.status_code == 401

    def test_second_guest_sees_new_order_via_state(self, owner, three_songs):
        pid = _new_playlist(owner, three_songs, "guest")
        pw = requests.get(f"{API}/playlists/{pid}/password", headers=owner, timeout=10).json()["password"]
        other = _guest()
        # Guest must join first (new password gate)
        assert requests.post(f"{API}/playlists/{pid}/join", headers=other,
                             json={"password": pw}, timeout=10).status_code == 200
        # before reorder
        st0 = requests.get(f"{API}/playlists/{pid}/state", headers=other, timeout=10).json()
        assert st0["items"] == three_songs
        requests.put(f"{API}/playlists/{pid}/items", headers=owner, json={"order": [2, 0, 1]}, timeout=10)
        st1 = requests.get(f"{API}/playlists/{pid}/state", headers=other, timeout=10).json()
        assert st1["items"] == [three_songs[2], three_songs[0], three_songs[1]]
