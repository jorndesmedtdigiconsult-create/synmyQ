"""Iteration 8: join-password gate on songs/playlists + SEC-001 (controller bound to account)."""
import os
import pytest
import requests

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL", "https://jynque-sync.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"
TONE_PATH = "/tmp/tone.wav"


def _guest():
    tok = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
    return tok


def _upload(h):
    with open(TONE_PATH, "rb") as f:
        r = requests.post(f"{API}/songs/upload", headers=h,
                          files={"file": ("tone.wav", f, "audio/wav")}, timeout=180)
    assert r.status_code == 200, r.text
    return r.json()


@pytest.fixture
def owner_song():
    tok = _guest()
    h = {"Authorization": f"Bearer {tok}", "X-Device-Id": "dev_owner_pw"}
    s = _upload(h)
    return tok, h, s


# ---------- Non-member gated with WACHTWOORD_VEREIST ----------
class TestPasswordGate:
    def test_non_member_song_meta_403(self, owner_song):
        _, _, s = owner_song
        h = {"Authorization": f"Bearer {_guest()}"}
        r = requests.get(f"{API}/songs/{s['song_id']}", headers=h, timeout=10)
        assert r.status_code == 403
        assert r.json()["detail"] == "WACHTWOORD_VEREIST"

    def test_non_member_song_file_403(self, owner_song):
        _, _, s = owner_song
        h = {"Authorization": f"Bearer {_guest()}"}
        r = requests.get(f"{API}/songs/{s['song_id']}/file", headers=h, timeout=10)
        assert r.status_code == 403
        assert r.json()["detail"] == "WACHTWOORD_VEREIST"

    def test_non_member_state_403(self, owner_song):
        _, _, s = owner_song
        h = {"Authorization": f"Bearer {_guest()}"}
        r = requests.get(f"{API}/songs/{s['song_id']}/state", headers=h, timeout=10)
        assert r.status_code == 403
        assert r.json()["detail"] == "WACHTWOORD_VEREIST"

    def test_non_member_presence_403(self, owner_song):
        _, _, s = owner_song
        h = {"Authorization": f"Bearer {_guest()}"}
        r = requests.post(f"{API}/songs/{s['song_id']}/presence", headers=h,
                          json={"device_id": "dev_nm", "name": "Nm",
                                "drift_ms": 0, "in_sync": True, "playing": False}, timeout=10)
        assert r.status_code == 403
        assert r.json()["detail"] == "WACHTWOORD_VEREIST"

    def test_owner_meta_ok(self, owner_song):
        _, h, s = owner_song
        r = requests.get(f"{API}/songs/{s['song_id']}", headers=h, timeout=10)
        assert r.status_code == 200
        assert r.json()["is_owner"] is True

    def test_non_member_playlist_403(self, owner_song):
        _, h, s = owner_song
        pid = requests.post(f"{API}/playlists", headers=h,
                            json={"title": "P", "items": [s["song_id"]]}, timeout=30).json()["playlist_id"]
        h2 = {"Authorization": f"Bearer {_guest()}"}
        r = requests.get(f"{API}/playlists/{pid}", headers=h2, timeout=10)
        assert r.status_code == 403
        assert r.json()["detail"] == "WACHTWOORD_VEREIST"


# ---------- Password endpoint + join flow ----------
class TestJoin:
    def test_owner_sees_password(self, owner_song):
        _, h, s = owner_song
        r = requests.get(f"{API}/songs/{s['song_id']}/password", headers=h, timeout=10)
        assert r.status_code == 200
        pw = r.json()["password"]
        assert isinstance(pw, str) and len(pw) == 6
        assert pw.isupper() or all(c in "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" for c in pw)

    def test_non_member_cannot_see_password(self, owner_song):
        _, _, s = owner_song
        h = {"Authorization": f"Bearer {_guest()}"}
        r = requests.get(f"{API}/songs/{s['song_id']}/password", headers=h, timeout=10)
        assert r.status_code == 403

    def test_wrong_password_400(self, owner_song):
        _, _, s = owner_song
        h = {"Authorization": f"Bearer {_guest()}"}
        r = requests.post(f"{API}/songs/{s['song_id']}/join", headers=h,
                          json={"password": "ZZZZZZ"}, timeout=10)
        assert r.status_code == 400
        assert r.json()["detail"] == "Wachtwoord klopt niet"

    def test_right_password_makes_member(self, owner_song):
        _, h, s = owner_song
        pw = requests.get(f"{API}/songs/{s['song_id']}/password", headers=h, timeout=10).json()["password"]
        tok = _guest()
        g = {"Authorization": f"Bearer {tok}"}
        jr = requests.post(f"{API}/songs/{s['song_id']}/join", headers=g,
                           json={"password": pw}, timeout=10)
        assert jr.status_code == 200
        # Now meta + state + file all accessible
        assert requests.get(f"{API}/songs/{s['song_id']}", headers=g, timeout=10).status_code == 200
        assert requests.get(f"{API}/songs/{s['song_id']}/state", headers=g, timeout=10).status_code == 200
        assert requests.get(f"{API}/songs/{s['song_id']}/file", headers=g, timeout=60).status_code == 200

    def test_more_than_8_wrong_attempts_429(self, owner_song):
        _, _, s = owner_song
        h = {"Authorization": f"Bearer {_guest()}"}
        last = None
        for _ in range(10):
            last = requests.post(f"{API}/songs/{s['song_id']}/join", headers=h,
                                 json={"password": "AAAAAA"}, timeout=10)
            if last.status_code == 429:
                break
        assert last.status_code == 429
        assert "pogingen" in last.json()["detail"].lower()


# ---------- Playlist members inherit access to songs ----------
class TestPlaylistMemberAccessesSongs:
    def test_playlist_member_can_fetch_item_song_and_file(self, owner_song):
        _, h, s = owner_song
        pid = requests.post(f"{API}/playlists", headers=h,
                            json={"title": "PL", "items": [s["song_id"]]}, timeout=30).json()["playlist_id"]
        pw = requests.get(f"{API}/playlists/{pid}/password", headers=h, timeout=10).json()["password"]
        tok = _guest()
        g = {"Authorization": f"Bearer {tok}"}
        requests.post(f"{API}/playlists/{pid}/join", headers=g, json={"password": pw}, timeout=10)
        # Member of the playlist did NOT join the song, but should access it
        assert requests.get(f"{API}/songs/{s['song_id']}", headers=g, timeout=10).status_code == 200
        assert requests.get(f"{API}/songs/{s['song_id']}/file", headers=g, timeout=60).status_code == 200

    def test_create_playlist_requires_access_to_each_song(self, owner_song):
        # Another owner uploads; a different guest cannot include that song in a playlist
        tok_other = _guest()
        h_other = {"Authorization": f"Bearer {tok_other}", "X-Device-Id": "dev_other_pl"}
        s2 = _upload(h_other)
        tok = _guest()
        h = {"Authorization": f"Bearer {tok}"}
        r = requests.post(f"{API}/playlists", headers=h,
                          json={"title": "X", "items": [s2["song_id"]]}, timeout=30)
        assert r.status_code == 403
        assert r.json()["detail"] == "WACHTWOORD_VEREIST"

    def test_add_item_requires_access(self, owner_song):
        _, h, s = owner_song
        pid = requests.post(f"{API}/playlists", headers=h,
                            json={"title": "A", "items": [s["song_id"]]}, timeout=30).json()["playlist_id"]
        # Stranger uploads another song
        tok_other = _guest()
        h_other = {"Authorization": f"Bearer {tok_other}", "X-Device-Id": "dev_stranger"}
        s2 = _upload(h_other)
        # Owner tries to add stranger's song => owner is not a member => 403 WACHTWOORD_VEREIST
        r = requests.post(f"{API}/playlists/{pid}/items", headers=h,
                          json={"song_id": s2["song_id"]}, timeout=10)
        assert r.status_code == 403


# ---------- SEC-001: control bound to account AND device ----------
class TestSEC001:
    def test_other_member_cannot_impersonate_controllers_device(self, owner_song):
        """After transfer to guest G (devG), member X sending X-Device-Id devG gets 403;
           presence from X with devG -> 409; G (own token+devG) stays authorised."""
        _, owner_h, s = owner_song
        sid = s["song_id"]

        # Reveal password to onboard two guests
        pw = requests.get(f"{API}/songs/{sid}/password", headers=owner_h, timeout=10).json()["password"]

        tok_g = _guest()
        devG = "dev_target_sec001"
        h_g = {"Authorization": f"Bearer {tok_g}", "X-Device-Id": devG}
        assert requests.post(f"{API}/songs/{sid}/join", headers=h_g,
                             json={"password": pw}, timeout=10).status_code == 200

        tok_x = _guest()
        devX = "dev_x_sec001"
        h_x = {"Authorization": f"Bearer {tok_x}", "X-Device-Id": devX}
        assert requests.post(f"{API}/songs/{sid}/join", headers=h_x,
                             json={"password": pw}, timeout=10).status_code == 200

        # G sends presence from devG so transfer target can be bound
        pr = requests.post(f"{API}/songs/{sid}/presence", headers=h_g,
                           json={"device_id": devG, "name": "G",
                                 "drift_ms": 0, "in_sync": True, "playing": False}, timeout=10)
        assert pr.status_code == 200

        # Owner transfers control to devG
        tr = requests.post(f"{API}/songs/{sid}/control", headers=owner_h,
                           json={"device_id": devG, "name": "GPhone"}, timeout=10)
        assert tr.status_code == 200
        d = tr.json()
        assert d["controller_device_id"] == devG

        # G with own token + devG succeeds (start/pause/stop/loop/volume)
        for ep, body in (("start", {}), ("pause", {}), ("stop", {}),
                        ("loop", {"loop": False}), ("volume", {"volume": 0.5})):
            r = requests.post(f"{API}/songs/{sid}/{ep}", headers=h_g, json=body, timeout=10)
            assert r.status_code == 200, f"G should be allowed on {ep}, got {r.status_code} {r.text}"

        # X spoofing devG -> 403 on every controller endpoint
        h_x_spoof = {"Authorization": f"Bearer {tok_x}", "X-Device-Id": devG}
        for ep, body in (("start", {}), ("pause", {}), ("stop", {}),
                        ("loop", {"loop": True}), ("volume", {"volume": 0.3})):
            r = requests.post(f"{API}/songs/{sid}/{ep}", headers=h_x_spoof, json=body, timeout=10)
            assert r.status_code == 403, f"X spoofing devG must 403 on {ep}, got {r.status_code}"
        # control transfer attempt by X spoofing devG
        rc = requests.post(f"{API}/songs/{sid}/control", headers=h_x_spoof,
                           json={"device_id": devX, "name": "hijack"}, timeout=10)
        assert rc.status_code == 403

        # X presence with devG -> 409 (device id already in use within TTL).
        # Refresh G's heartbeat first because the preceding 10+ requests may exceed PRESENCE_TTL_MS=8s on preview infra.
        requests.post(f"{API}/songs/{sid}/presence", headers=h_g,
                      json={"device_id": devG, "name": "G",
                            "drift_ms": 0, "in_sync": True, "playing": False}, timeout=10)
        rp = requests.post(f"{API}/songs/{sid}/presence", headers=h_x_spoof,
                           json={"device_id": devG, "name": "X",
                                 "drift_ms": 0, "in_sync": True, "playing": False}, timeout=10)
        assert rp.status_code == 409
