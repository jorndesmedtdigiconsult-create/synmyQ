"""Playlist (shared queue) + fade + state additions - iteration 6."""
import os
import time
import pytest
import requests

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL", "https://jynque-sync.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"
TONE_PATH = "/tmp/tone.wav"


def _upload(h):
    with open(TONE_PATH, "rb") as f:
        r = requests.post(f"{API}/songs/upload", headers=h, files={"file": ("tone.wav", f, "audio/wav")}, timeout=180)
    assert r.status_code == 200, r.text
    return r.json()


@pytest.fixture(scope="module")
def owner_headers():
    tok = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
    return {"Authorization": f"Bearer {tok}", "X-Device-Id": "dev_owner_pl"}


@pytest.fixture(scope="module")
def three_songs(owner_headers):
    return [_upload(owner_headers) for _ in range(3)]


# ---------- Song: durations_ms + duration_ms stored on upload ----------
class TestSongDurationFromUpload:
    def test_state_durations_ms_populated(self, owner_headers):
        song = _upload(owner_headers)
        st = requests.get(f"{API}/songs/{song['song_id']}/state", headers=owner_headers, timeout=10).json()
        assert st["kind"] == "songs"
        assert isinstance(st["durations_ms"], list)
        assert len(st["durations_ms"]) == 1
        # /tmp/tone.wav is 30s
        d = st["durations_ms"][0]
        assert 29000 <= d <= 31000, f"durations_ms[0]={d}, expected ~30000"
        # duration_ms also exposed
        assert st["duration_ms"] is not None
        assert 29000 <= st["duration_ms"] <= 31000


# ---------- Playlist create / fetch ----------
class TestPlaylistCreate:
    def test_create_returns_7_char_id(self, owner_headers, three_songs):
        ids = [s["song_id"] for s in three_songs]
        r = requests.post(f"{API}/playlists", headers=owner_headers,
                          json={"title": "My Mix", "items": ids}, timeout=30)
        assert r.status_code == 200, r.text
        d = r.json()
        assert len(d["playlist_id"]) == 7
        assert d["title"] == "My Mix"
        assert d["is_owner"] is True
        assert [i["song_id"] for i in d["items"]] == ids

    def test_get_playlist_as_owner(self, owner_headers, three_songs):
        ids = [s["song_id"] for s in three_songs]
        pid = requests.post(f"{API}/playlists", headers=owner_headers,
                            json={"title": "T", "items": ids}, timeout=30).json()["playlist_id"]
        r = requests.get(f"{API}/playlists/{pid}", headers=owner_headers, timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert d["is_owner"] is True
        assert len(d["items"]) == 3

    def test_get_playlist_as_non_owner(self, three_songs, owner_headers):
        ids = [s["song_id"] for s in three_songs]
        pid = requests.post(f"{API}/playlists", headers=owner_headers,
                            json={"title": "T2", "items": ids}, timeout=30).json()["playlist_id"]
        pw = requests.get(f"{API}/playlists/{pid}/password", headers=owner_headers, timeout=10).json()["password"]
        tok = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
        h = {"Authorization": f"Bearer {tok}"}
        # Without joining -> 403 WACHTWOORD_VEREIST
        rb = requests.get(f"{API}/playlists/{pid}", headers=h, timeout=10)
        assert rb.status_code == 403
        assert rb.json()["detail"] == "WACHTWOORD_VEREIST"
        # Join with the password
        jr = requests.post(f"{API}/playlists/{pid}/join", headers=h, json={"password": pw}, timeout=10)
        assert jr.status_code == 200
        r = requests.get(f"{API}/playlists/{pid}", headers=h, timeout=10)
        assert r.status_code == 200
        assert r.json()["is_owner"] is False

    def test_empty_items_returns_400(self, owner_headers):
        r = requests.post(f"{API}/playlists", headers=owner_headers,
                          json={"title": "Empty", "items": []}, timeout=10)
        assert r.status_code == 400

    def test_unknown_song_returns_404(self, owner_headers):
        r = requests.post(f"{API}/playlists", headers=owner_headers,
                          json={"title": "Bad", "items": ["ZZZZZZ"]}, timeout=10)
        assert r.status_code == 404


# ---------- Playlist session endpoints ----------
@pytest.fixture
def fresh_playlist(owner_headers, three_songs):
    ids = [s["song_id"] for s in three_songs]
    pid = requests.post(f"{API}/playlists", headers=owner_headers,
                        json={"title": "Fresh", "items": ids}, timeout=30).json()["playlist_id"]
    return pid, ids


class TestPlaylistSession:
    def test_initial_state(self, owner_headers, fresh_playlist):
        pid, ids = fresh_playlist
        st = requests.get(f"{API}/playlists/{pid}/state", headers=owner_headers, timeout=10).json()
        assert st["kind"] == "playlists"
        assert st["status"] == "stopped"
        assert st["items"] == ids
        assert len(st["durations_ms"]) == len(ids)
        for d in st["durations_ms"]:
            assert 29000 <= d <= 31000

    def test_start_with_lead(self, owner_headers, fresh_playlist):
        pid, _ = fresh_playlist
        before = int(time.time() * 1000)
        r = requests.post(f"{API}/playlists/{pid}/start", headers=owner_headers, timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert d["status"] == "playing"
        lead = d["start_at_ms"] - before
        assert 3500 < lead < 7000

    def test_pause_sets_fade_end_ms(self, owner_headers, fresh_playlist):
        pid, _ = fresh_playlist
        requests.post(f"{API}/playlists/{pid}/start", headers=owner_headers, timeout=10)
        time.sleep(6.5)
        before = int(time.time() * 1000)
        r = requests.post(f"{API}/playlists/{pid}/pause", headers=owner_headers, timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert d["status"] == "paused"
        assert d["fade_end_ms"] is not None
        fade = d["fade_end_ms"] - before
        assert 800 < fade < 2000, f"fade_end offset = {fade}"

    def test_stop_and_loop_volume(self, owner_headers, fresh_playlist):
        pid, _ = fresh_playlist
        rs = requests.post(f"{API}/playlists/{pid}/stop", headers=owner_headers, timeout=10)
        assert rs.status_code == 200
        assert rs.json()["status"] == "stopped"
        rl = requests.post(f"{API}/playlists/{pid}/loop", headers=owner_headers,
                           json={"loop": False}, timeout=10)
        assert rl.status_code == 200
        # Loop is forced true (new spec)
        assert rl.json()["loop"] is True
        assert rl.json()["gap_s"] == 5
        assert rl.json()["track_gap_s"] == 5
        rv = requests.post(f"{API}/playlists/{pid}/volume", headers=owner_headers,
                           json={"volume": 0.3}, timeout=10)
        assert rv.status_code == 200
        assert rv.json()["volume"] == 0.3

    def test_non_controller_403(self, fresh_playlist):
        pid, _ = fresh_playlist
        tok = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
        h = {"Authorization": f"Bearer {tok}", "X-Device-Id": "dev_other"}
        for ep in ("start", "pause", "stop"):
            r = requests.post(f"{API}/playlists/{pid}/{ep}", headers=h, timeout=10)
            assert r.status_code == 403, f"{ep} should 403"
        r = requests.post(f"{API}/playlists/{pid}/loop", headers=h, json={"loop": False}, timeout=10)
        assert r.status_code == 403
        r = requests.post(f"{API}/playlists/{pid}/volume", headers=h, json={"volume": 0.5}, timeout=10)
        assert r.status_code == 403

    def test_presence_includes_listeners(self, owner_headers, fresh_playlist):
        pid, _ = fresh_playlist
        r = requests.post(f"{API}/playlists/{pid}/presence", headers=owner_headers,
                          json={"device_id": "dev_pl_p", "name": "Owner",
                                "drift_ms": 0, "in_sync": True, "playing": False}, timeout=10)
        assert r.status_code == 200
        assert "listeners" in r.json()


# ---------- Skip ----------
class TestPlaylistSkip:
    def test_skip_to_track_offset(self, owner_headers, fresh_playlist):
        pid, ids = fresh_playlist
        # Each tone is 30s; gap is 5s between tracks.
        # offsets: 0, 35, 70
        before = int(time.time() * 1000)
        r = requests.post(f"{API}/playlists/{pid}/skip", headers=owner_headers,
                          json={"index": 1}, timeout=10)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["status"] == "playing"
        resume_lead = d["resume_at_ms"] - before
        assert 3500 < resume_lead < 7000, f"resume lead={resume_lead}"
        # track 1 offset = dur0 + 5s gap = 30 + 5 = 35s
        offset = d["resume_at_ms"] - d["start_at_ms"]
        assert 34000 <= offset <= 36000, f"offset for index=1 was {offset}"

    def test_skip_to_track_2(self, owner_headers, fresh_playlist):
        pid, _ = fresh_playlist
        r = requests.post(f"{API}/playlists/{pid}/skip", headers=owner_headers,
                          json={"index": 2}, timeout=10)
        assert r.status_code == 200
        d = r.json()
        # offset for index 2 = 30+5 + 30+5 = 70s
        offset = d["resume_at_ms"] - d["start_at_ms"]
        assert 69000 <= offset <= 71000, f"offset for index=2 was {offset}"

    def test_skip_wraps_modulo(self, owner_headers, fresh_playlist):
        pid, _ = fresh_playlist
        # index 3 should wrap to 0
        r = requests.post(f"{API}/playlists/{pid}/skip", headers=owner_headers,
                          json={"index": 3}, timeout=10)
        assert r.status_code == 200
        d = r.json()
        offset = d["resume_at_ms"] - d["start_at_ms"]
        assert 0 <= offset <= 100, f"wrap offset was {offset}"

    def test_skip_non_controller_403(self, fresh_playlist):
        pid, _ = fresh_playlist
        tok = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
        h = {"Authorization": f"Bearer {tok}", "X-Device-Id": "dev_sk"}
        r = requests.post(f"{API}/playlists/{pid}/skip", headers=h, json={"index": 1}, timeout=10)
        assert r.status_code == 403


# ---------- Append items ----------
class TestPlaylistAppend:
    def test_owner_appends(self, owner_headers, three_songs):
        ids = [s["song_id"] for s in three_songs[:2]]
        pid = requests.post(f"{API}/playlists", headers=owner_headers,
                            json={"title": "App", "items": ids}, timeout=30).json()["playlist_id"]
        extra = three_songs[2]["song_id"]
        r = requests.post(f"{API}/playlists/{pid}/items", headers=owner_headers,
                          json={"song_id": extra}, timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert d["items"] == ids + [extra]
        assert len(d["durations_ms"]) == 3
        # verify persisted
        g = requests.get(f"{API}/playlists/{pid}", headers=owner_headers, timeout=10).json()
        assert [i["song_id"] for i in g["items"]] == ids + [extra]

    def test_non_owner_append_403(self, owner_headers, three_songs):
        ids = [s["song_id"] for s in three_songs]
        pid = requests.post(f"{API}/playlists", headers=owner_headers,
                            json={"title": "B", "items": ids}, timeout=30).json()["playlist_id"]
        tok = requests.post(f"{API}/auth/guest", timeout=30).json()["session_token"]
        h = {"Authorization": f"Bearer {tok}", "X-Device-Id": "dev_ap"}
        r = requests.post(f"{API}/playlists/{pid}/items", headers=h,
                          json={"song_id": ids[0]}, timeout=10)
        assert r.status_code == 403

    def test_append_unknown_song_404(self, owner_headers, three_songs):
        ids = [s["song_id"] for s in three_songs]
        pid = requests.post(f"{API}/playlists", headers=owner_headers,
                            json={"title": "C", "items": ids}, timeout=30).json()["playlist_id"]
        r = requests.post(f"{API}/playlists/{pid}/items", headers=owner_headers,
                          json={"song_id": "ZZZZZZ"}, timeout=10)
        assert r.status_code == 404


# ---------- Fade on single song pause ----------
class TestSongFade:
    def test_pause_returns_fade_end_ms(self, owner_headers):
        song = _upload(owner_headers)
        sid = song["song_id"]
        requests.post(f"{API}/songs/{sid}/start", headers=owner_headers, timeout=10)
        time.sleep(6.0)
        before = int(time.time() * 1000)
        r = requests.post(f"{API}/songs/{sid}/pause", headers=owner_headers, timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert d["status"] == "paused"
        assert d["fade_end_ms"] is not None
        fade = d["fade_end_ms"] - before
        assert 800 < fade < 2000, f"fade_end offset={fade}"

    def test_stop_returns_fade_end_ms(self, owner_headers):
        song = _upload(owner_headers)
        sid = song["song_id"]
        requests.post(f"{API}/songs/{sid}/start", headers=owner_headers, timeout=10)
        time.sleep(0.5)
        before = int(time.time() * 1000)
        r = requests.post(f"{API}/songs/{sid}/stop", headers=owner_headers, timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert d["status"] == "stopped"
        assert d["fade_end_ms"] is not None
        fade = d["fade_end_ms"] - before
        assert 800 < fade < 2000
