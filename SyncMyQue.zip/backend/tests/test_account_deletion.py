"""Tests for DELETE /api/auth/me, guest-login with name, and sliding sessions."""
import os
import time
import pytest
import requests

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL", "https://jynque-sync.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"
TONE_PATH = "/tmp/tone.wav"


def _guest(name=None):
    body = {"name": name} if name is not None else None
    r = requests.post(f"{API}/auth/guest", json=body, timeout=30)
    assert r.status_code == 200, r.text
    return r.json()


def _upload(headers):
    with open(TONE_PATH, "rb") as f:
        r = requests.post(f"{API}/songs/upload", headers=headers,
                          files={"file": ("tone.wav", f, "audio/wav")}, timeout=180)
    assert r.status_code == 200, r.text
    return r.json()


# ------ POST /auth/guest body ------
class TestGuestLoginWithName:
    def test_guest_no_body_still_works(self):
        r = requests.post(f"{API}/auth/guest", timeout=30)
        assert r.status_code == 200
        d = r.json()
        assert d["user_id"].startswith("guest_")
        me = requests.get(f"{API}/auth/me",
                          headers={"Authorization": f"Bearer {d['session_token']}"}, timeout=10).json()
        assert me["name"] in (None, "")

    def test_guest_with_name_in_body(self):
        d = _guest("Alice")
        me = requests.get(f"{API}/auth/me",
                          headers={"Authorization": f"Bearer {d['session_token']}"}, timeout=10).json()
        assert me["name"] == "Alice"
        assert me["is_guest"] is True

    def test_guest_name_trimmed_and_whitespace_collapsed(self):
        d = _guest("  Bob    van   Dale  ")
        me = requests.get(f"{API}/auth/me",
                          headers={"Authorization": f"Bearer {d['session_token']}"}, timeout=10).json()
        assert me["name"] == "Bob van Dale"

    def test_guest_name_max_40(self):
        long = "x" * 100
        d = _guest(long)
        me = requests.get(f"{API}/auth/me",
                          headers={"Authorization": f"Bearer {d['session_token']}"}, timeout=10).json()
        assert me["name"] == "x" * 40

    def test_guest_name_empty_is_null(self):
        d = _guest("   ")
        me = requests.get(f"{API}/auth/me",
                          headers={"Authorization": f"Bearer {d['session_token']}"}, timeout=10).json()
        assert me["name"] in (None, "")

    def test_guest_empty_json_body(self):
        r = requests.post(f"{API}/auth/guest", json={}, timeout=30)
        assert r.status_code == 200


# ------ DELETE /auth/me ------
class TestDeleteAccount:
    def test_delete_requires_auth(self):
        r = requests.delete(f"{API}/auth/me", timeout=10)
        assert r.status_code == 401

    def test_delete_removes_user_and_sessions(self):
        d = _guest("Carol")
        tok = d["session_token"]
        h = {"Authorization": f"Bearer {tok}"}
        # Create a second session for same user
        # (login a second guest? That is a different user. Instead just verify current session is 401 after delete.)
        r = requests.delete(f"{API}/auth/me", headers=h, timeout=15)
        assert r.status_code == 200
        body = r.json()
        assert body.get("ok") is True
        # Old token now invalid
        r2 = requests.get(f"{API}/auth/me", headers=h, timeout=10)
        assert r2.status_code == 401

    def test_delete_removes_owned_songs_and_other_data_untouched(self):
        # Owner uploads song, second user joins & uploads own song
        owner = _guest("Owner")
        ho = {"Authorization": f"Bearer {owner['session_token']}"}
        s_own = _upload(ho)
        sid_own = s_own["song_id"]

        other = _guest("Other")
        hother = {"Authorization": f"Bearer {other['session_token']}"}
        s_other = _upload(hother)
        sid_other = s_other["song_id"]

        # Other user joins owner's song via password -> becomes member
        pw = requests.get(f"{API}/songs/{sid_own}/password", headers=ho, timeout=10).json()["password"]
        jr = requests.post(f"{API}/songs/{sid_own}/join", headers=hother,
                           json={"password": pw}, timeout=10)
        assert jr.status_code == 200
        # Also owner joins other user's song -> member
        pw2 = requests.get(f"{API}/songs/{sid_other}/password", headers=hother, timeout=10).json()["password"]
        requests.post(f"{API}/songs/{sid_other}/join", headers=ho, json={"password": pw2}, timeout=10)

        # Owner creates a playlist including his own song and other's song
        pl = requests.post(f"{API}/playlists", headers=ho,
                          json={"title": "Mix", "items": [sid_own, sid_other]}, timeout=30).json()
        pid_own = pl["playlist_id"]

        # Other user creates a playlist including BOTH songs too
        pl2 = requests.post(f"{API}/playlists", headers=hother,
                           json={"title": "Mix2", "items": [sid_own, sid_other]}, timeout=30).json()
        pid_other = pl2["playlist_id"]

        # Owner presence on own song
        requests.post(f"{API}/songs/{sid_own}/presence", headers=ho,
                      json={"device_id": "dev_del_owner", "name": "Owner",
                            "drift_ms": 0, "in_sync": True, "playing": False}, timeout=10)

        # DELETE owner account
        rd = requests.delete(f"{API}/auth/me", headers=ho, timeout=20)
        assert rd.status_code == 200
        res = rd.json()
        assert res["deleted_songs"] >= 1
        assert res["deleted_playlists"] >= 1

        # Owner's song is gone (404 for other user)
        r_gone = requests.get(f"{API}/songs/{sid_own}", headers=hother, timeout=10)
        assert r_gone.status_code == 404

        # Owner's playlist is gone
        r_gone2 = requests.get(f"{API}/playlists/{pid_own}", headers=hother, timeout=10)
        assert r_gone2.status_code == 404

        # Other user's song still exists
        r_ok = requests.get(f"{API}/songs/{sid_other}", headers=hother, timeout=10)
        assert r_ok.status_code == 200

        # Other user's playlist: deleted song id should be removed from items
        r_pl = requests.get(f"{API}/playlists/{pid_other}", headers=hother, timeout=10)
        assert r_pl.status_code == 200
        items_ids = [i["song_id"] for i in r_pl.json()["items"]]
        assert sid_own not in items_ids
        assert sid_other in items_ids

    def test_delete_removes_user_from_members(self):
        owner = _guest("Own2")
        ho = {"Authorization": f"Bearer {owner['session_token']}"}
        s = _upload(ho)
        sid = s["song_id"]

        joiner = _guest("Join")
        hj = {"Authorization": f"Bearer {joiner['session_token']}"}
        pw = requests.get(f"{API}/songs/{sid}/password", headers=ho, timeout=10).json()["password"]
        requests.post(f"{API}/songs/{sid}/join", headers=hj, json={"password": pw}, timeout=10)
        # Joiner can now get the song
        assert requests.get(f"{API}/songs/{sid}", headers=hj, timeout=10).status_code == 200

        # Joiner deletes own account
        rd = requests.delete(f"{API}/auth/me", headers=hj, timeout=10)
        assert rd.status_code == 200

        # New session for owner can still access
        assert requests.get(f"{API}/songs/{sid}", headers=ho, timeout=10).status_code == 200

        # Also owner's membership list should no longer include joiner's user_id.
        # Create a NEW guest with same previous flow should get 403 (not member).
        new_guest = _guest()
        hng = {"Authorization": f"Bearer {new_guest['session_token']}"}
        r = requests.get(f"{API}/songs/{sid}", headers=hng, timeout=10)
        assert r.status_code == 403  # password required

    def test_delete_old_token_401_everywhere(self):
        d = _guest("Dave")
        tok = d["session_token"]
        h = {"Authorization": f"Bearer {tok}"}
        requests.delete(f"{API}/auth/me", headers=h, timeout=10)
        # Try multiple endpoints with the stale token
        # auth/logout is intentionally idempotent (returns 200 even with stale token)
        for method, url, kwargs in [
            ("GET", f"{API}/auth/me", {}),
            ("PATCH", f"{API}/auth/me", {"json": {"name": "x"}}),
            ("DELETE", f"{API}/auth/me", {}),
        ]:
            r = requests.request(method, url, headers=h, timeout=10, **kwargs)
            assert r.status_code == 401, f"{method} {url} -> {r.status_code}"


# ------ Sliding session ------
class TestSlidingSession:
    def test_fresh_guest_session_valid_for_long_period(self):
        """We cannot wait 29 days in the test; verify session works and that `user_from_token`
        does not accidentally delete still-valid sessions. Also check the DB-level expires_at >= now+29d."""
        d = _guest("Eve")
        tok = d["session_token"]
        h = {"Authorization": f"Bearer {tok}"}
        # Multiple calls over a short window all succeed (no premature expiry)
        for _ in range(5):
            assert requests.get(f"{API}/auth/me", headers=h, timeout=10).status_code == 200
            time.sleep(0.2)
