from fastapi import FastAPI, APIRouter, HTTPException, Request, UploadFile, File, Query
from fastapi.responses import Response
from fastapi.concurrency import run_in_threadpool
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field, BeforeValidator, ConfigDict
from typing import Annotated, List, Optional
from pathlib import Path
from datetime import datetime, timezone, timedelta
import os
import time
import uuid
import secrets
import logging
import io
import hmac
import hashlib
import requests
from mutagen import File as MutagenFile
import jwt
from jwt import PyJWKClient

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

app = FastAPI()
api_router = APIRouter(prefix="/api")

# ---------------- Models ----------------
PyObjectId = Annotated[str, BeforeValidator(lambda v: str(v))]


class BaseDocument(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: Optional[PyObjectId] = Field(default=None, alias="_id")

    @classmethod
    def from_mongo(cls, doc):
        return cls(**doc) if doc else None

    def to_mongo(self):
        data = self.model_dump(by_alias=True, exclude_none=False)
        if data.get("_id") is None:
            data.pop("_id", None)
        return data


class User(BaseDocument):
    user_id: str
    apple_sub: Optional[str] = None
    email: Optional[str] = None
    name: Optional[str] = None
    is_guest: bool = False
    created_at: str


class Session(BaseDocument):
    session_token: str
    user_id: str
    expires_at: datetime


class Playable(BaseDocument):
    """Shared UTC playback state (song or playlist)."""
    status: str = "stopped"  # stopped | playing | paused
    start_at_ms: Optional[int] = None
    resume_at_ms: Optional[int] = None
    paused_pos_ms: int = 0
    loop: bool = True
    fade_end_ms: Optional[int] = None
    controller_device_id: Optional[str] = None
    controller_name: Optional[str] = None
    controller_user_id: Optional[str] = None
    join_code: Optional[str] = None
    members: List[str] = []
    volume: float = 1.0
    version: int = 0
    updated_at_ms: int = 0


class Song(Playable):
    song_id: str
    title: str
    owner_id: str
    storage_path: str
    content_type: str
    size: int
    created_at: str
    duration_ms: Optional[int] = None


class Playlist(Playable):
    playlist_id: str
    title: str
    owner_id: str
    items: List[str] = []
    created_at: str


class Presence(BaseDocument):
    song_id: str
    device_id: str
    user_id: str
    name: str
    drift_ms: int = 0
    in_sync: bool = True
    playing: bool = False
    last_seen_ms: int


def now_ms() -> int:
    return int(time.time() * 1000)


def song_public(s: Song, user: Optional["User"] = None) -> dict:
    return {
        "song_id": s.song_id,
        "title": s.title,
        "size": s.size,
        "content_type": s.content_type,
        "created_at": s.created_at,
        "owner_id": s.owner_id,
        "is_owner": bool(user and user.user_id == s.owner_id),
    }


# ---------------- Object storage ----------------
STORAGE_BASE = (os.environ.get("INTEGRATION_PROXY_URL") or "").strip() or "https://integrations.emergentagent.com"
STORAGE_URL = STORAGE_BASE.rstrip("/") + "/objstore/api/v1/storage"
EMERGENT_KEY = os.environ.get("EMERGENT_LLM_KEY")
APP_NAME = "jynque"
storage_key = None


def init_storage():
    global storage_key
    if storage_key:
        return storage_key
    resp = requests.post(f"{STORAGE_URL}/init", json={"emergent_key": EMERGENT_KEY}, timeout=30)
    resp.raise_for_status()
    storage_key = resp.json()["storage_key"]
    return storage_key


def put_object(path: str, data: bytes, content_type: str) -> dict:
    global storage_key
    key = init_storage()
    resp = requests.put(f"{STORAGE_URL}/objects/{path}",
                        headers={"X-Storage-Key": key, "Content-Type": content_type}, data=data, timeout=180)
    if resp.status_code == 503:
        storage_key = None
        key = init_storage()
        resp = requests.put(f"{STORAGE_URL}/objects/{path}",
                            headers={"X-Storage-Key": key, "Content-Type": content_type}, data=data, timeout=180)
    if resp.status_code == 402:
        raise HTTPException(status_code=402, detail="Opslagtegoed op. Probeer later opnieuw.")
    resp.raise_for_status()
    return resp.json()


def get_object(path: str):
    global storage_key
    key = init_storage()
    resp = requests.get(f"{STORAGE_URL}/objects/{path}", headers={"X-Storage-Key": key}, timeout=120)
    if resp.status_code == 503:
        storage_key = None
        key = init_storage()
        resp = requests.get(f"{STORAGE_URL}/objects/{path}", headers={"X-Storage-Key": key}, timeout=120)
    resp.raise_for_status()
    return resp.content, resp.headers.get("Content-Type", "audio/mpeg")


# ---------------- Auth ----------------
APPLE_ISSUER = "https://appleid.apple.com"
APPLE_AUDIENCES = [a.strip() for a in os.environ["APPLE_AUDIENCES"].split(",") if a.strip()]
apple_jwk_client = PyJWKClient("https://appleid.apple.com/auth/keys")


SESSION_DAYS = 30  # sliding: every use (at most once a day) extends the session again


async def create_session(user_id: str) -> str:
    token = secrets.token_urlsafe(32)
    sess = Session(session_token=token, user_id=user_id,
                   expires_at=datetime.now(timezone.utc) + timedelta(days=SESSION_DAYS))
    await db.sessions.insert_one(sess.to_mongo())
    return token


async def user_from_token(token: Optional[str]) -> User:
    if not token:
        raise HTTPException(status_code=401, detail="Niet aangemeld")
    doc = await db.sessions.find_one({"session_token": token})
    if not doc:
        raise HTTPException(status_code=401, detail="Sessie ongeldig")
    sess = Session.from_mongo(doc)
    exp = sess.expires_at if sess.expires_at.tzinfo else sess.expires_at.replace(tzinfo=timezone.utc)
    now = datetime.now(timezone.utc)
    if exp < now:
        await db.sessions.delete_one({"session_token": token})
        raise HTTPException(status_code=401, detail="Sessie verlopen")
    if exp - now < timedelta(days=SESSION_DAYS - 1):
        await db.sessions.update_one({"session_token": token},
                                     {"$set": {"expires_at": now + timedelta(days=SESSION_DAYS)}})
    user = User.from_mongo(await db.users.find_one({"user_id": sess.user_id}))
    if not user:
        raise HTTPException(status_code=401, detail="Gebruiker niet gevonden")
    return user


def bearer(request: Request) -> Optional[str]:
    auth = request.headers.get("Authorization", "")
    if auth.lower().startswith("bearer "):
        return auth[7:].strip()
    return None


async def get_current_user(request: Request) -> User:
    return await user_from_token(bearer(request))


def user_public(u: User) -> dict:
    return {"user_id": u.user_id, "email": u.email, "name": u.name, "is_guest": u.is_guest}


class AppleAuthIn(BaseModel):
    identity_token: str
    full_name: Optional[str] = None
    email: Optional[str] = None


@api_router.post("/auth/apple")
async def auth_apple(body: AppleAuthIn):
    try:
        signing_key = await run_in_threadpool(apple_jwk_client.get_signing_key_from_jwt, body.identity_token)
        claims = jwt.decode(body.identity_token, signing_key.key, algorithms=["RS256"],
                            audience=APPLE_AUDIENCES, issuer=APPLE_ISSUER)
    except Exception as e:
        logger.warning(f"Apple token invalid: {e}")
        raise HTTPException(status_code=401, detail="Apple token ongeldig")
    sub = claims["sub"]
    existing = User.from_mongo(await db.users.find_one({"apple_sub": sub}))
    if existing:
        updates = {}
        if body.full_name and not existing.name:
            updates["name"] = body.full_name
        email = body.email or claims.get("email")
        if email and not existing.email:
            updates["email"] = email
        if updates:
            await db.users.update_one({"apple_sub": sub}, {"$set": updates})
        user_id = existing.user_id
    else:
        user = User(user_id=f"user_{uuid.uuid4().hex[:12]}", apple_sub=sub,
                    email=body.email or claims.get("email"), name=body.full_name,
                    created_at=datetime.now(timezone.utc).isoformat())
        await db.users.insert_one(user.to_mongo())
        user_id = user.user_id
    token = await create_session(user_id)
    return {"session_token": token, "user_id": user_id}


class NameIn(BaseModel):
    name: str


class GuestIn(BaseModel):
    name: Optional[str] = None


@api_router.post("/auth/guest")
async def auth_guest(body: Optional[GuestIn] = None):
    # Auto-login: the client may pass the last profile name it used
    name = " ".join(((body.name if body else None) or "").split())[:40] or None
    user = User(user_id=f"guest_{uuid.uuid4().hex[:12]}", name=name, is_guest=True,
                created_at=datetime.now(timezone.utc).isoformat())
    await db.users.insert_one(user.to_mongo())
    token = await create_session(user.user_id)
    return {"session_token": token, "user_id": user.user_id}


@api_router.patch("/auth/me")
async def update_me(body: NameIn, request: Request):
    user = await get_current_user(request)
    name = " ".join(body.name.split())[:40]
    if not name:
        raise HTTPException(status_code=400, detail="Vul je naam in")
    await db.users.update_one({"user_id": user.user_id}, {"$set": {"name": name}})
    user.name = name
    return user_public(user)


@api_router.get("/auth/me")
async def auth_me(request: Request):
    return user_public(await get_current_user(request))


@api_router.delete("/auth/me")
async def delete_me(request: Request):
    """Account deletion (App Store 5.1.1): removes the user, all sessions and all owned data."""
    user = await get_current_user(request)
    uid = user.user_id
    song_ids = [d["song_id"] async for d in db.songs.find({"owner_id": uid}, {"song_id": 1})]
    pl_ids = [d["playlist_id"] async for d in db.playlists.find({"owner_id": uid}, {"playlist_id": 1})]
    await db.songs.delete_many({"owner_id": uid})
    await db.playlists.delete_many({"owner_id": uid})
    if song_ids:
        await db.playlists.update_many({"items": {"$in": song_ids}}, {"$pull": {"items": {"$in": song_ids}}})
    await db.presence.delete_many({"$or": [{"user_id": uid}, {"song_id": {"$in": song_ids + pl_ids}}]})
    await db.songs.update_many({"members": uid}, {"$pull": {"members": uid}})
    await db.playlists.update_many({"members": uid}, {"$pull": {"members": uid}})
    await db.sessions.delete_many({"user_id": uid})
    await db.users.delete_one({"user_id": uid})
    return {"ok": True, "deleted_songs": len(song_ids), "deleted_playlists": len(pl_ids)}


@api_router.post("/auth/logout")
async def auth_logout(request: Request):
    token = bearer(request)
    if token:
        await db.sessions.delete_one({"session_token": token})
    return {"ok": True}


# ---------------- Time (UTC) ----------------
@api_router.get("/time")
async def server_time():
    return {"server_ms": now_ms()}


# ---------------- Songs ----------------
ID_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
MAX_SIZE = 40 * 1024 * 1024


async def new_song_id() -> str:
    while True:
        sid = "".join(secrets.choice(ID_ALPHABET) for _ in range(6))
        if not await db.songs.find_one({"song_id": sid}):
            return sid


async def find_song(song_id: str) -> Song:
    song = Song.from_mongo(await db.songs.find_one({"song_id": song_id.strip().upper()}))
    if not song:
        raise HTTPException(status_code=404, detail="Nummer niet gevonden")
    return song


PASSWORD_REQUIRED = "WACHTWOORD_VEREIST"


def new_join_code() -> str:
    return "".join(secrets.choice(ID_ALPHABET) for _ in range(6))


async def require_member(doc, user: User):
    """Only the owner, users who joined with the password (or QR) and playlist members may access a session."""
    if user.user_id == doc.owner_id or user.user_id in (doc.members or []):
        return
    if isinstance(doc, Song) and await db.playlists.find_one(
            {"items": doc.song_id, "$or": [{"owner_id": user.user_id}, {"members": user.user_id}]}):
        return
    raise HTTPException(status_code=403, detail=PASSWORD_REQUIRED)


SIGNING_SECRET = os.environ["DOWNLOAD_SIGNING_SECRET"].encode()
LINK_TTL_MS = 30 * 60 * 1000  # 30 minutes


def sign_link(song_id: str, uid: str, exp: int) -> str:
    return hmac.new(SIGNING_SECRET, f"{song_id}:{uid}:{exp}".encode(), hashlib.sha256).hexdigest()


@api_router.post("/songs/{song_id}/file-link")
async def file_link(song_id: str, request: Request):
    """Short-lived, per-file, per-user link (no session token inside)."""
    user = await get_current_user(request)
    song = await find_song(song_id)
    await require_member(song, user)
    exp = now_ms() + LINK_TTL_MS
    return {"path": f"/api/songs/{song.song_id}/file?uid={user.user_id}&exp={exp}&sig={sign_link(song.song_id, user.user_id, exp)}",
            "expires_at_ms": exp}


@api_router.post("/songs/upload")
async def upload_song(request: Request, file: UploadFile = File(...)):
    user = await get_current_user(request)
    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="Leeg bestand")
    if len(data) > MAX_SIZE:
        raise HTTPException(status_code=413, detail="Bestand te groot (max 40MB)")
    name = file.filename or "nummer.mp3"
    ext = name.rsplit(".", 1)[-1].lower() if "." in name else "mp3"
    content_type = file.content_type or "audio/mpeg"
    if content_type == "application/octet-stream":
        content_type = "audio/mpeg"
    path = f"{APP_NAME}/uploads/{user.user_id}/{uuid.uuid4()}.{ext}"
    result = await run_in_threadpool(put_object, path, data, content_type)
    title = name.rsplit(".", 1)[0] if "." in name else name
    song = Song(song_id=await new_song_id(), title=title, owner_id=user.user_id, join_code=new_join_code(),
                storage_path=result["path"], content_type=content_type, size=len(data),
                created_at=datetime.now(timezone.utc).isoformat(), updated_at_ms=now_ms(),
                duration_ms=audio_duration_ms(data))
    await db.songs.insert_one(song.to_mongo())
    return song_public(song, user)


@api_router.get("/songs/{song_id}")
async def get_song(song_id: str, request: Request):
    user = await get_current_user(request)
    song = await find_song(song_id)
    await require_member(song, user)
    return song_public(song, user)


@api_router.get("/songs/{song_id}/file")
async def get_song_file(song_id: str, request: Request, uid: Optional[str] = Query(None),
                        exp: Optional[int] = Query(None), sig: Optional[str] = Query(None)):
    """Download with the Bearer header (native) or a short-lived signed link (web streaming).
    The session token is never accepted in the URL."""
    song = await find_song(song_id)
    if bearer(request):
        user = await user_from_token(bearer(request))
    elif uid and exp and sig:
        if exp < now_ms() or not hmac.compare_digest(sig, sign_link(song.song_id, uid, exp)):
            raise HTTPException(status_code=401, detail="Downloadlink verlopen")
        user = User.from_mongo(await db.users.find_one({"user_id": uid}))
        if not user:
            raise HTTPException(status_code=401, detail="Downloadlink ongeldig")
    else:
        raise HTTPException(status_code=401, detail="Niet aangemeld")
    await require_member(song, user)
    data, ctype = await run_in_threadpool(get_object, song.storage_path)
    return Response(content=data, media_type=song.content_type or ctype,
                    headers={"Accept-Ranges": "none", "Cache-Control": "private, max-age=86400"})


# ---------------- Sessions: a song or a playlist share one UTC timeline ----------------
START_LEAD_MS = 5000  # 5 s countdown so every device has time to sync
RESUME_LEAD_MS = 5000
SKIP_LEAD_MS = 5000
GAP_S = 5  # 5 s silence before every (re)start of the song / queue
TRACK_GAP_S = 5  # 5 s silence before every next song in a playlist
FADE_MS = 1200  # fade-out time for pause / stop / skip
NO_CONTROL = "Je hebt geen beheer over deze sessie"
PRESENCE_TTL_MS = 8000
KINDS = {"songs": ("songs", "song_id"), "playlists": ("playlists", "playlist_id")}


def device_header(request: Request) -> Optional[str]:
    return request.headers.get("X-Device-Id")


def can_control(doc, user: User, device_id: Optional[str]) -> bool:
    """Control is bound to the logged-in account; the device id alone proves nothing."""
    if doc.controller_device_id and doc.controller_user_id:
        return user.user_id == doc.controller_user_id and device_id == doc.controller_device_id
    return user.user_id == doc.owner_id


def sid_of(doc) -> str:
    return doc.song_id if isinstance(doc, Song) else doc.playlist_id


async def find_session(kind: str, sid: str):
    if kind not in KINDS:
        raise HTTPException(status_code=404, detail="Niet gevonden")
    coll, key = KINDS[kind]
    raw = await db[coll].find_one({key: sid.strip().upper()})
    if not raw:
        raise HTTPException(status_code=404, detail="Nummer niet gevonden" if kind == "songs" else "Afspeellijst niet gevonden")
    return (Song if kind == "songs" else Playlist).from_mongo(raw)


async def find_controlled(kind: str, sid: str, request: Request):
    user = await get_current_user(request)
    doc = await find_session(kind, sid)
    if not can_control(doc, user, device_header(request)):
        raise HTTPException(status_code=403, detail=NO_CONTROL)
    return doc, user


def audio_duration_ms(data: bytes) -> Optional[int]:
    try:
        f = MutagenFile(io.BytesIO(data))
        if f is not None and f.info and f.info.length:
            return int(f.info.length * 1000)
    except Exception as e:
        logger.warning(f"duration parse failed: {e}")
    return None


async def ensure_duration(song: Song) -> Optional[int]:
    if song.duration_ms:
        return song.duration_ms
    data, _ = await run_in_threadpool(get_object, song.storage_path)
    dur = audio_duration_ms(data)
    if dur:
        await db.songs.update_one({"song_id": song.song_id}, {"$set": {"duration_ms": dur}})
    return dur


async def durations_s(doc) -> list:
    if isinstance(doc, Song):
        return [doc.duration_ms / 1000] if doc.duration_ms else []
    rows = await db.songs.find({"song_id": {"$in": doc.items}}, {"song_id": 1, "duration_ms": 1}).to_list(1000)
    m = {r["song_id"]: (r.get("duration_ms") or 0) for r in rows}
    return [m.get(i, 0) / 1000 for i in doc.items]


def layout(durs: list):
    offsets, acc = [], 0.0
    for i, d in enumerate(durs):
        offsets.append(acc)
        acc += d + (TRACK_GAP_S if i < len(durs) - 1 else 0)
    return offsets, acc


def phase(doc, t: int, durs: list):
    """Global timeline (seconds). For gaps it returns the position where playback resumes."""
    if doc.status == "stopped" or (doc.status == "playing" and not doc.start_at_ms):
        return "stopped", 0.0
    if doc.status == "paused":
        return "paused", (doc.paused_pos_ms or 0) / 1000
    resume_at = doc.resume_at_ms or doc.start_at_ms
    if t < resume_at:
        return "countdown", (resume_at - doc.start_at_ms) / 1000
    g = (t - doc.start_at_ms) / 1000
    if not durs or min(durs) <= 0:
        return "play", g
    offsets, total = layout(durs)
    g = g % (total + GAP_S)  # always loops (for every device, automatically)
    if g >= total:
        return "gap", 0.0
    for o, d in zip(offsets, durs):
        if g < o:
            return "gap", o
        if g < o + d:
            return "play", g
    return "gap", 0.0


async def state_out(doc) -> dict:
    durs = await durations_s(doc)
    is_song = isinstance(doc, Song)
    return {
        "kind": "songs" if is_song else "playlists",
        "song_id": sid_of(doc),
        "title": doc.title,
        "status": doc.status,
        "start_at_ms": doc.start_at_ms,
        "resume_at_ms": doc.resume_at_ms,
        "paused_pos_ms": doc.paused_pos_ms,
        "loop": True,
        "duration_ms": doc.duration_ms if is_song else None,
        "durations_ms": [int(d * 1000) for d in durs],
        "items": None if is_song else doc.items,
        "gap_s": GAP_S,
        "track_gap_s": TRACK_GAP_S,
        "fade_end_ms": doc.fade_end_ms,
        "owner_id": doc.owner_id,
        "controller_device_id": doc.controller_device_id,
        "controller_name": doc.controller_name,
        "volume": doc.volume,
        "version": doc.version,
        "updated_at_ms": doc.updated_at_ms,
        "server_ms": now_ms(),
    }


async def bump(doc, fields: dict, inc: bool = True) -> dict:
    fields["updated_at_ms"] = now_ms()
    coll, key = KINDS["songs" if isinstance(doc, Song) else "playlists"]
    update = {"$set": fields}
    if inc:
        update["$inc"] = {"version": 1}
    await db[coll].update_one({key: sid_of(doc)}, update)
    return await state_out(await find_session("songs" if isinstance(doc, Song) else "playlists", sid_of(doc)))


@api_router.get("/{kind}/{sid}/state")
async def get_state(kind: str, sid: str, request: Request):
    user = await get_current_user(request)
    doc = await find_session(kind, sid)
    await require_member(doc, user)
    return await state_out(doc)


class JoinIn(BaseModel):
    password: str


JOIN_ATTEMPTS: dict = {}
JOIN_MAX, JOIN_WINDOW_MS = 8, 10 * 60 * 1000


@api_router.post("/{kind}/{sid}/join")
async def join_session(kind: str, sid: str, body: JoinIn, request: Request):
    user = await get_current_user(request)
    doc = await find_session(kind, sid)
    key = f"{user.user_id}:{kind}:{sid_of(doc)}"
    t = now_ms()
    tries = [x for x in JOIN_ATTEMPTS.get(key, []) if x > t - JOIN_WINDOW_MS]
    if len(tries) >= JOIN_MAX:
        raise HTTPException(status_code=429, detail="Te veel pogingen. Probeer het over 10 minuten opnieuw.")
    if not doc.join_code or not secrets.compare_digest(body.password.strip().upper(), doc.join_code):
        JOIN_ATTEMPTS[key] = tries + [t]
        raise HTTPException(status_code=400, detail="Wachtwoord klopt niet")
    JOIN_ATTEMPTS.pop(key, None)
    coll, k = KINDS[kind]
    await db[coll].update_one({k: sid_of(doc)}, {"$addToSet": {"members": user.user_id}})
    return {"ok": True}


@api_router.post("/{kind}/{sid}/password/rotate")
async def rotate_password(kind: str, sid: str, request: Request):
    user = await get_current_user(request)
    doc = await find_session(kind, sid)
    if not (user.user_id == doc.owner_id or can_control(doc, user, device_header(request))):
        raise HTTPException(status_code=403, detail=NO_CONTROL)
    code = new_join_code()
    coll, k = KINDS[kind]
    await db[coll].update_one({k: sid_of(doc)}, {"$set": {"join_code": code}})
    return {"password": code}


class KickIn(BaseModel):
    device_id: str


@api_router.post("/{kind}/{sid}/kick")
async def kick_listener(kind: str, sid: str, body: KickIn, request: Request):
    """Remove a listener: drop membership, end their presence, rotate the password so they cannot rejoin."""
    user = await get_current_user(request)
    doc = await find_session(kind, sid)
    if not (user.user_id == doc.owner_id or can_control(doc, user, device_header(request))):
        raise HTTPException(status_code=403, detail=NO_CONTROL)
    pr = await db.presence.find_one({"song_id": sid_of(doc), "device_id": body.device_id})
    if not pr:
        raise HTTPException(status_code=404, detail="Toestel niet gevonden")
    target = pr["user_id"]
    if target in (doc.owner_id, user.user_id):
        raise HTTPException(status_code=400, detail="Deze luisteraar kan niet verwijderd worden")
    code = new_join_code()
    coll, k = KINDS[kind]
    fields = {"join_code": code}
    if doc.controller_user_id == target:
        fields.update(controller_device_id=None, controller_user_id=None, controller_name=None)
    await db[coll].update_one({k: sid_of(doc)}, {"$set": fields, "$pull": {"members": target}, "$inc": {"version": 1}})
    await db.presence.delete_many({"song_id": sid_of(doc), "user_id": target})
    return {"password": code}


@api_router.get("/{kind}/{sid}/password")
async def get_password(kind: str, sid: str, request: Request):
    user = await get_current_user(request)
    doc = await find_session(kind, sid)
    if not (user.user_id == doc.owner_id or can_control(doc, user, device_header(request))):
        raise HTTPException(status_code=403, detail=NO_CONTROL)
    return {"password": doc.join_code}


class StartIn(BaseModel):
    duration_ms: Optional[int] = None


@api_router.post("/{kind}/{sid}/start")
async def start_session(kind: str, sid: str, request: Request, body: Optional[StartIn] = None):
    doc, _ = await find_controlled(kind, sid, request)
    t = now_ms()
    fields = {"status": "playing", "paused_pos_ms": 0, "fade_end_ms": None}
    if isinstance(doc, Song) and not doc.duration_ms and body and body.duration_ms and body.duration_ms > 0:
        fields["duration_ms"] = int(body.duration_ms)
    if doc.status == "paused":
        resume = t + RESUME_LEAD_MS
        fields.update(resume_at_ms=resume, start_at_ms=resume - int(doc.paused_pos_ms or 0))
    else:
        fields.update(resume_at_ms=t + START_LEAD_MS, start_at_ms=t + START_LEAD_MS)
    return await bump(doc, fields)


@api_router.post("/{kind}/{sid}/pause")
async def pause_session(kind: str, sid: str, request: Request):
    doc, _ = await find_controlled(kind, sid, request)
    t = now_ms()
    durs = await durations_s(doc)
    mode, g = phase(doc, t, durs)
    if mode in ("stopped", "paused"):
        return await state_out(doc)
    if mode == "play":  # devices fade out for FADE_MS, so pause where the fade ends
        mode2, g2 = phase(doc, t + FADE_MS, durs)
        g = g2 if mode2 == "play" else g
    return await bump(doc, {"status": "paused", "paused_pos_ms": int(g * 1000), "start_at_ms": None,
                            "resume_at_ms": None, "fade_end_ms": t + FADE_MS})


@api_router.post("/{kind}/{sid}/stop")
async def stop_session(kind: str, sid: str, request: Request):
    doc, _ = await find_controlled(kind, sid, request)
    return await bump(doc, {"status": "stopped", "start_at_ms": None, "resume_at_ms": None,
                            "paused_pos_ms": 0, "fade_end_ms": now_ms() + FADE_MS})


class VolumeIn(BaseModel):
    volume: float


@api_router.post("/{kind}/{sid}/volume")
async def set_volume(kind: str, sid: str, body: VolumeIn, request: Request):
    """Remote volume for all devices. No version bump: it must not disturb playback sync."""
    doc, _ = await find_controlled(kind, sid, request)
    return await bump(doc, {"volume": max(0.0, min(1.0, round(body.volume, 2)))}, inc=False)


class LoopIn(BaseModel):
    loop: bool


def reanchor(doc, t: int, durs: list, new_loop: bool) -> dict:
    """Keep the audible position continuous when the timeline layout changes."""
    if doc.status != "playing":
        return {}
    mode, g = phase(doc, t, durs)
    if mode == "play":
        return {"start_at_ms": t - int(g * 1000), "resume_at_ms": t}
    if mode == "gap" and g > 0:
        resume = t + TRACK_GAP_S * 1000
        return {"start_at_ms": resume - int(g * 1000), "resume_at_ms": resume}
    if mode in ("gap", "ended"):
        return {"start_at_ms": t + GAP_S * 1000, "resume_at_ms": t + GAP_S * 1000}
    return {}


@api_router.post("/{kind}/{sid}/loop")
async def set_loop(kind: str, sid: str, body: LoopIn, request: Request):
    doc, _ = await find_controlled(kind, sid, request)
    # Loop is always on; kept for compatibility with older clients
    fields = {"loop": True, **reanchor(doc, now_ms(), await durations_s(doc), True)}
    return await bump(doc, fields)


class ControlIn(BaseModel):
    device_id: str
    name: Optional[str] = None


@api_router.post("/{kind}/{sid}/control")
async def transfer_control(kind: str, sid: str, body: ControlIn, request: Request):
    user = await get_current_user(request)
    doc = await find_session(kind, sid)
    if not (user.user_id == doc.owner_id or can_control(doc, user, device_header(request))):
        raise HTTPException(status_code=403, detail="Je mag het beheer niet doorgeven")
    # Bind control to the account behind that (authenticated) device heartbeat
    pr = await db.presence.find_one({"song_id": sid_of(doc), "device_id": body.device_id,
                                     "last_seen_ms": {"$gte": now_ms() - PRESENCE_TTL_MS}})
    if pr:
        target_user = pr["user_id"]
    elif body.device_id == device_header(request):
        target_user = user.user_id
    else:
        raise HTTPException(status_code=400, detail="Dat toestel is niet verbonden")
    return await bump(doc, {"controller_device_id": body.device_id, "controller_user_id": target_user,
                            "controller_name": (body.name or "Toestel")[:60]})


class PresenceIn(BaseModel):
    device_id: str
    name: Optional[str] = None
    drift_ms: int = 0
    in_sync: bool = True
    playing: bool = False




@api_router.post("/{kind}/{sid}/presence")
async def presence(kind: str, sid: str, body: PresenceIn, request: Request):
    user = await get_current_user(request)
    doc = await find_session(kind, sid)
    await require_member(doc, user)
    key = sid_of(doc)
    t = now_ms()
    existing = await db.presence.find_one({"song_id": key, "device_id": body.device_id})
    if existing and existing["user_id"] != user.user_id and existing["last_seen_ms"] >= t - PRESENCE_TTL_MS:
        raise HTTPException(status_code=409, detail="Toestel-ID al in gebruik")
    p = Presence(song_id=key, device_id=body.device_id, user_id=user.user_id,
                 name=(body.name or "Toestel")[:60], drift_ms=body.drift_ms, in_sync=body.in_sync,
                 playing=body.playing, last_seen_ms=t)
    await db.presence.update_one({"song_id": key, "device_id": body.device_id}, {"$set": p.to_mongo()}, upsert=True)
    docs = await db.presence.find({"song_id": key, "last_seen_ms": {"$gte": t - PRESENCE_TTL_MS}}).to_list(200)
    controller = doc.controller_device_id
    listeners = []
    for d in docs:
        pr = Presence.from_mongo(d)
        is_ctrl = (pr.device_id == controller and pr.user_id == doc.controller_user_id) if (
            controller and doc.controller_user_id) else pr.user_id == doc.owner_id
        listeners.append({"device_id": pr.device_id, "name": pr.name, "drift_ms": pr.drift_ms,
                          "in_sync": pr.in_sync, "playing": pr.playing, "is_controller": is_ctrl})
    listeners.sort(key=lambda x: (not x["is_controller"], x["name"]))
    return {**(await state_out(doc)), "listeners": listeners}


# ---------------- Playlists (shared queue) ----------------
class PlaylistIn(BaseModel):
    title: str
    items: List[str]


class ItemIn(BaseModel):
    song_id: str


class SkipIn(BaseModel):
    index: int


async def new_playlist_id() -> str:
    while True:
        pid = "".join(secrets.choice(ID_ALPHABET) for _ in range(7))
        if not await db.playlists.find_one({"playlist_id": pid}):
            return pid


async def checked_song(song_id: str, user: User) -> Song:
    song = await find_song(song_id)
    await require_member(song, user)
    if not await ensure_duration(song):
        raise HTTPException(status_code=400, detail=f"Duur van {song.song_id} onbekend")
    return song


async def playlist_public(pl: Playlist, user: User) -> dict:
    rows = await db.songs.find({"song_id": {"$in": pl.items}}).to_list(1000)
    by_id = {r["song_id"]: Song.from_mongo(r) for r in rows}
    return {"playlist_id": pl.playlist_id, "title": pl.title, "owner_id": pl.owner_id,
            "is_owner": user.user_id == pl.owner_id,
            "items": [song_public(by_id[i], user) for i in pl.items if i in by_id]}


@api_router.post("/playlists")
async def create_playlist(body: PlaylistIn, request: Request):
    user = await get_current_user(request)
    ids = [i.strip().upper() for i in body.items if i.strip()]
    if not ids:
        raise HTTPException(status_code=400, detail="Kies minstens één nummer")
    for i in ids:
        await checked_song(i, user)
    pl = Playlist(playlist_id=await new_playlist_id(), title=(body.title.strip() or "Afspeellijst")[:60],
                  owner_id=user.user_id, items=ids, join_code=new_join_code(), created_at=datetime.now(timezone.utc).isoformat(),
                  updated_at_ms=now_ms())
    await db.playlists.insert_one(pl.to_mongo())
    return await playlist_public(pl, user)


@api_router.get("/playlists/{pid}")
async def get_playlist(pid: str, request: Request):
    user = await get_current_user(request)
    pl = await find_session("playlists", pid)
    await require_member(pl, user)
    return await playlist_public(pl, user)


@api_router.post("/playlists/{pid}/items")
async def add_item(pid: str, body: ItemIn, request: Request):
    user = await get_current_user(request)
    pl = await find_session("playlists", pid)
    if not (user.user_id == pl.owner_id or can_control(pl, user, device_header(request))):
        raise HTTPException(status_code=403, detail=NO_CONTROL)
    song = await checked_song(body.song_id, user)
    t = now_ms()
    fields = {"items": pl.items + [song.song_id], **reanchor(pl, t, await durations_s(pl), pl.loop)}
    return await bump(pl, fields)


class OrderIn(BaseModel):
    order: List[int]


def locate_track(durs: list, g: float):
    offsets, _ = layout(durs)
    for i, (o, d) in enumerate(zip(offsets, durs)):
        if g < o + d:
            return i, max(0.0, g - o)
    return 0, 0.0


def remap_pos(old_durs: list, new_durs: list, order: list, g: float):
    """Map a global position to the new queue order. Returns (new_g, same_track_kept)."""
    i, p = locate_track(old_durs, g)
    new_off, _ = layout(new_durs)
    if i in order:
        return new_off[order.index(i)] + p, True
    j = min(sum(1 for k in order if k < i), len(order) - 1)
    return new_off[j], False


@api_router.put("/playlists/{pid}/items")
async def reorder_items(pid: str, body: OrderIn, request: Request):
    """Reorder and/or remove queue items while playing; the current song keeps playing seamlessly."""
    user = await get_current_user(request)
    pl = await find_session("playlists", pid)
    if not (user.user_id == pl.owner_id or can_control(pl, user, device_header(request))):
        raise HTTPException(status_code=403, detail=NO_CONTROL)
    n = len(pl.items)
    order = body.order
    if not order or len(set(order)) != len(order) or any(k < 0 or k >= n for k in order):
        raise HTTPException(status_code=400, detail="Ongeldige volgorde")
    old_durs = await durations_s(pl)
    new_durs = [old_durs[k] for k in order]
    t = now_ms()
    fields = {"items": [pl.items[k] for k in order]}
    if pl.status == "paused":
        g2, _ = remap_pos(old_durs, new_durs, order, (pl.paused_pos_ms or 0) / 1000)
        fields["paused_pos_ms"] = int(g2 * 1000)
    elif pl.status == "playing":
        mode, g = phase(pl, t, old_durs)
        if mode == "play":
            g2, kept = remap_pos(old_durs, new_durs, order, g)
            if kept:
                fields.update(start_at_ms=t - int(g2 * 1000), resume_at_ms=t)
            else:  # the playing song was removed: fade out, count down, start the next one
                resume = t + SKIP_LEAD_MS
                fields.update(start_at_ms=resume - int(g2 * 1000), resume_at_ms=resume, fade_end_ms=t + FADE_MS)
        elif mode == "countdown":
            g2, _ = remap_pos(old_durs, new_durs, order, g)
            resume = pl.resume_at_ms or pl.start_at_ms
            fields.update(start_at_ms=resume - int(g2 * 1000))
        elif mode == "gap":
            resume = t + (TRACK_GAP_S if g > 0 else 3) * 1000
            g2 = remap_pos(old_durs, new_durs, order, g)[0] if g > 0 else 0.0
            fields.update(start_at_ms=resume - int(g2 * 1000), resume_at_ms=resume)
    return await bump(pl, fields)


@api_router.post("/playlists/{pid}/skip")
async def skip_to(pid: str, body: SkipIn, request: Request):
    pl, _ = await find_controlled("playlists", pid, request)
    durs = await durations_s(pl)
    offsets, _total = layout(durs)
    idx = body.index % len(offsets)
    t = now_ms()
    resume = t + SKIP_LEAD_MS
    return await bump(pl, {"status": "playing", "paused_pos_ms": 0, "resume_at_ms": resume,
                           "start_at_ms": resume - int(offsets[idx] * 1000), "fade_end_ms": t + FADE_MS})


@api_router.get("/")
async def root():
    return {"message": "JynQue API"}


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup():
    await db.users.create_index("user_id", unique=True)
    try:
        await db.users.drop_index("apple_sub_1")
    except Exception:
        pass
    await db.users.create_index("apple_sub", name="apple_sub_unique", unique=True,
                                partialFilterExpression={"apple_sub": {"$type": "string"}})
    await db.sessions.create_index("session_token", unique=True)
    await db.sessions.create_index("expires_at", expireAfterSeconds=0)
    await db.songs.create_index("song_id", unique=True)
    await db.playlists.create_index("playlist_id", unique=True)
    # Migration: every session gets a join password; earlier listeners stay members
    for coll, key in KINDS.values():
        async for d in db[coll].find({"join_code": None}):
            members = await db.presence.distinct("user_id", {"song_id": d[key]})
            await db[coll].update_one({"_id": d["_id"]}, {"$set": {"join_code": new_join_code()},
                                                          "$addToSet": {"members": {"$each": members}}})
    await db.presence.create_index([("song_id", 1), ("device_id", 1)], unique=True)
    try:
        await run_in_threadpool(init_storage)
        logger.info("Object storage ready")
    except Exception as e:
        logger.error(f"Storage init failed: {e}")


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
